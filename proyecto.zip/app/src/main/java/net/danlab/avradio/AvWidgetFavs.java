package net.danlab.avradio;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;

/** Widget de favoritas: 6 logos para cambiar de emisora con un toque. */
public class AvWidgetFavs extends AppWidgetProvider {
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        RadioService.start(c);
        Widgets.update(c);
    }
}
