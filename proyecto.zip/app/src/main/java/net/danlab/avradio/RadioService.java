package net.danlab.avradio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.os.IBinder;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/**
 * Mantiene AVRadio viva en segundo plano: volante, notificación, widget,
 * aviso emergente al cambiar de emisora y apertura al encender el coche.
 */
public class RadioService extends Service implements RadioHub.StationListener, LogoStore.Listener {

    public static final String ACTION_NEXT = "net.danlab.avradio.NEXT";
    public static final String ACTION_PREV = "net.danlab.avradio.PREV";
    public static final String ACTION_START = "net.danlab.avradio.START";
    private static final String CHANNEL = "avradio";
    private static final int NOTIF_ID = 7;

    private RadioHub hub;
    private LogoStore logos;
    private long screenOffAt;

    private final BroadcastReceiver screen = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            if (Intent.ACTION_SCREEN_OFF.equals(i.getAction())) {
                screenOffAt = SystemClock.elapsedRealtime();
            } else if (Intent.ACTION_SCREEN_ON.equals(i.getAction())) {
                // Al volver a encender el coche (la pantalla estuvo apagada un rato)
                if (screenOffAt > 0 && SystemClock.elapsedRealtime() - screenOffAt > 60_000) {
                    if (hub.isOpen()) hub.link().requestRadioSource();
                    if (autostartEnabled(c)) openApp(c);
                }
            }
        }
    };

    public static void start(Context c) {
        try {
            c.startForegroundService(new Intent(c, RadioService.class).setAction(ACTION_START));
        } catch (Exception ignored) { }
    }

    public static boolean autostartEnabled(Context c) {
        return c.getSharedPreferences("avradio", MODE_PRIVATE).getBoolean("autostart", true);
    }

    public static void openApp(Context c) {
        Intent i = new Intent(c, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        try { c.startActivity(i); } catch (Exception ignored) { }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel ch = new NotificationChannel(CHANNEL, "AVRadio", NotificationManager.IMPORTANCE_LOW);
        ch.setShowBadge(false);
        nm.createNotificationChannel(ch);
        startForeground(NOTIF_ID, buildNotification("AVRadio", "", null));

        hub = RadioHub.get(this);
        logos = new LogoStore(this, this);
        hub.start();
        hub.addStationListener(this);
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_SCREEN_ON);
        f.addAction(Intent.ACTION_SCREEN_OFF);
        registerReceiver(screen, f);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent != null ? intent.getAction() : null;
        if (ACTION_NEXT.equals(a)) hub.stepFavorite(+1);
        else if (ACTION_PREV.equals(a)) hub.stepFavorite(-1);
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        try { unregisterReceiver(screen); } catch (Exception ignored) { }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onLogoReady(String key) { refresh(false); }

    @Override
    public void onStationChanged(int freq, String name, String pi, boolean fromSteering) {
        refresh(true);
    }

    private void refresh(boolean popup) {
        int freq = hub.freq;
        if (freq == 0) return;
        String name = hub.displayName();
        String pi = hub.piFor(freq);
        String key = Favorites.keyFor(pi, name);
        Bitmap logo = name.isEmpty() ? null : logos.get(key, name);
        String f = String.format(Locale.ROOT, "%.1f MHz", freq / 100.0);

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify(NOTIF_ID, buildNotification(name.isEmpty() ? f : name, name.isEmpty() ? "" : f, logo));
        AvWidget.updateAll(this, name.isEmpty() ? "AVRadio" : name, f, logo, key, name);
        if (popup && !MainActivity.visible) showPopup(name.isEmpty() ? f : name, name.isEmpty() ? "" : f, logo, key, name);
    }

    private Notification buildNotification(String title, String text, Bitmap logo) {
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent prev = PendingIntent.getService(this, 1,
                new Intent(this, RadioService.class).setAction(ACTION_PREV), PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent next = PendingIntent.getService(this, 2,
                new Intent(this, RadioService.class).setAction(ACTION_NEXT), PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(title)
                .setContentText(text)
                .setSubText("by DanLab")
                .setContentIntent(open)
                .setOngoing(true)
                .setShowWhen(false)
                .addAction(new Notification.Action.Builder(null, "◀ Anterior", prev).build())
                .addAction(new Notification.Action.Builder(null, "Siguiente ▶", next).build());
        if (logo != null) b.setLargeIcon(logo);
        return b.build();
    }

    /** Aviso en el centro de la pantalla con la emisora (estando en Waze, etc.). */
    private void showPopup(String title, String sub, Bitmap logo, String key, String name) {
        if (!getSharedPreferences("avradio", MODE_PRIVATE).getBoolean("popup", true)) return;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.HORIZONTAL);
        box.setGravity(Gravity.CENTER_VERTICAL);
        int p = Ui.dp(this, 18);
        box.setPadding(p, p, Ui.dp(this, 28), p);
        box.setBackground(Ui.rounded(0xEE141B2A, Ui.dp(this, 22), Ui.ACCENT, Ui.dp(this, 2)));
        LogoView lv = new LogoView(this, false);
        lv.setStation(name.isEmpty() ? "FM" : name, key);
        lv.setLogo(logo);
        box.addView(lv, new LinearLayout.LayoutParams(Ui.dp(this, 84), Ui.dp(this, 84)));
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setPadding(Ui.dp(this, 16), 0, 0, 0);
        TextView a = Ui.text(this, title, 30, Ui.TEXT, true);
        TextView b = Ui.text(this, sub, 18, Ui.ACCENT, false);
        b.setPadding(0, Ui.dp(this, 6), 0, 0);
        t.addView(a);
        t.addView(b);
        box.addView(t);
        Toast toast = new Toast(getApplicationContext());
        toast.setView(box);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();
    }

    public static boolean canDrawOverlays(Context c) { return Settings.canDrawOverlays(c); }
}
