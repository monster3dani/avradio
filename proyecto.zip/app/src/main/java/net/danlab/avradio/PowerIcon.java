package net.danlab.avradio;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Icono de encendido/apagado dibujado (algunas pantallas no tienen el símbolo en su letra). */
public class PowerIcon extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int color;

    public PowerIcon(Context c, int color) {
        super(c);
        this.color = color;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
    }

    public void setColor(int c) { color = c; invalidate(); }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), s = Math.min(w, h);
        float cx = w / 2f, cy = h / 2f, r = s * 0.32f;
        p.setColor(color);
        p.setStrokeWidth(Math.max(2f, s * 0.09f));
        c.drawArc(new RectF(cx - r, cy - r + s * 0.04f, cx + r, cy + r + s * 0.04f), -60, 300, false, p);
        c.drawLine(cx, cy - r - s * 0.06f, cx, cy - s * 0.02f, p);
    }
}
