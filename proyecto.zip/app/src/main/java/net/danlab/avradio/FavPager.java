package net.danlab.avradio;

import android.animation.ValueAnimator;
import android.content.Context;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;

/** Páginas de favoritas que se arrastran con el dedo, suaves como el carrusel. */
public class FavPager extends ViewGroup {

    public interface Listener { void onPage(int page); }

    private int page = 0;
    private float downX, downY, downScroll;
    private boolean dragging;
    private final int slop;
    private VelocityTracker vt;
    private ValueAnimator anim;
    private Listener listener;

    public FavPager(Context c) {
        super(c);
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
    }

    public void setListener(Listener l) { listener = l; }
    public int getPage() { return page; }
    public int pages() { return Math.max(1, getChildCount()); }

    public void setPage(int p, boolean animate) {
        p = Math.max(0, Math.min(pages() - 1, p));
        boolean changed = p != page;
        page = p;
        int target = p * getWidth();
        if (animate) animateTo(target); else { cancel(); scrollTo(target, 0); }
        if (changed && listener != null) listener.onPage(p);
    }

    private void cancel() { if (anim != null) anim.cancel(); }

    private void animateTo(int target) {
        cancel();
        anim = ValueAnimator.ofInt(getScrollX(), target);
        anim.setDuration(300);
        anim.setInterpolator(new DecelerateInterpolator(1.6f));
        anim.addUpdateListener(a -> scrollTo((int) a.getAnimatedValue(), 0));
        anim.start();
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        int h = 0;
        for (int i = 0; i < getChildCount(); i++) {
            View c = getChildAt(i);
            c.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY),
                    MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));
            h = Math.max(h, c.getMeasuredHeight());
        }
        setMeasuredDimension(w, h);
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int w = r - l;
        for (int i = 0; i < getChildCount(); i++) {
            View c = getChildAt(i);
            c.layout(i * w, 0, (i + 1) * w, c.getMeasuredHeight());
        }
        if (anim == null || !anim.isRunning()) scrollTo(Math.min(page, pages() - 1) * w, 0);
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getX();
                downY = e.getY();
                downScroll = getScrollX();
                dragging = false;
                if (vt == null) vt = VelocityTracker.obtain(); else vt.clear();
                vt.addMovement(e);
                cancel();
                return false;
            case MotionEvent.ACTION_MOVE:
                vt.addMovement(e);
                float dx = Math.abs(e.getX() - downX), dy = Math.abs(e.getY() - downY);
                if (dx > slop && dx > dy) {
                    dragging = true;
                    getParent().requestDisallowInterceptTouchEvent(true);
                    return true;
                }
                return false;
        }
        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (vt == null) vt = VelocityTracker.obtain();
        vt.addMovement(e);
        int w = Math.max(1, getWidth());
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getX();
                downScroll = getScrollX();
                return true;
            case MotionEvent.ACTION_MOVE: {
                float x = downScroll - (e.getX() - downX);
                float max = (pages() - 1) * w;
                if (x < 0) x = x * 0.35f;                 // resistencia en los bordes
                else if (x > max) x = max + (x - max) * 0.35f;
                scrollTo((int) x, 0);
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                vt.computeCurrentVelocity(1000);
                float v = vt.getXVelocity();
                float moved = getScrollX() - page * w;
                int target = page;
                if (v < -600 || moved > w * 0.2f) target = page + 1;
                else if (v > 600 || moved < -w * 0.2f) target = page - 1;
                dragging = false;
                setPage(target, true);
                return true;
            }
        }
        return true;
    }
}
