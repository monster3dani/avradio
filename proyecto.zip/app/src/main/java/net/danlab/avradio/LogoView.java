package net.danlab.avradio;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;

/** Círculo de la emisora con sus iniciales (más adelante, su logo). */
public class LogoView extends View {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt  = new Paint(Paint.ANTI_ALIAS_FLAG);
    private String label = "";
    private int color = Ui.ACCENT;
    private final boolean glow;

    public LogoView(Context c, boolean glow) {
        super(c);
        this.glow = glow;
        if (glow) setLayerType(LAYER_TYPE_SOFTWARE, null);
        ring.setStyle(Paint.Style.STROKE);
        txt.setColor(Color.WHITE);
        txt.setTextAlign(Paint.Align.CENTER);
        txt.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
    }

    public void setStation(String ps, String key) {
        label = Ui.initials(ps);
        color = Ui.stationColor(key == null || key.isEmpty() ? ps : key);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float cx = w / 2f, cy = h / 2f;
        float r = Math.min(w, h) / 2f * (glow ? 0.80f : 0.92f);

        if (glow) {
            Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);
            halo.setShader(new RadialGradient(cx, cy, r * 1.25f,
                    new int[]{withAlpha(color, 90), withAlpha(color, 0)},
                    new float[]{0.6f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, r * 1.25f, halo);
        }
        fill.setShader(new RadialGradient(cx - r * 0.3f, cy - r * 0.35f, r * 1.4f,
                new int[]{lighten(color), darken(color)}, null, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, r, fill);

        ring.setStrokeWidth(Math.max(2f, r * 0.03f));
        ring.setColor(withAlpha(Color.WHITE, 70));
        c.drawCircle(cx, cy, r, ring);

        if (!label.isEmpty()) {
            txt.setTextSize(r * (label.length() > 2 ? 0.62f : 0.78f));
            Paint.FontMetrics fm = txt.getFontMetrics();
            c.drawText(label, cx, cy - (fm.ascent + fm.descent) / 2f, txt);
        }
    }

    private static int withAlpha(int c, int a) {
        return Color.argb(a, Color.red(c), Color.green(c), Color.blue(c));
    }
    private static int darken(int c) {
        return Color.rgb((int) (Color.red(c) * 0.35f), (int) (Color.green(c) * 0.35f), (int) (Color.blue(c) * 0.45f));
    }
    private static int lighten(int c) {
        return Color.rgb(Math.min(255, Color.red(c) + 30), Math.min(255, Color.green(c) + 30), Math.min(255, Color.blue(c) + 30));
    }
}
