package net.danlab.avradio;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

/**
 * "Seguir la emisora por zona":
 *  - Va apuntando dónde se oye bien cada emisora (registro de recepción).
 *  - Si una favorita pierde la señal, busca otra frecuencia de la misma emisora cerca:
 *    primero en FMLIST (cuando esté disponible) y si no, en lo que ya hemos oído antes.
 */
public class FollowManager implements LocationListener {

    private static final long WEAK_MS = 20_000;      // tiempo en mono antes de considerar señal perdida
    private static final long COOLDOWN_MS = 90_000;  // no saltar más de una vez cada 90 s
    private static final double MAX_KM = 60;

    private final Context ctx;
    private final RadioHub hub;
    private final Handler main = new Handler(Looper.getMainLooper());
    private Location location;
    private boolean stereo;
    private long lastJump;

    private final Handler in = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message m) { onMessage(m); }
    };

    public FollowManager(Context c) {
        ctx = c.getApplicationContext();
        hub = RadioHub.get(ctx);
        hub.addListener(in);
        startLocation();
    }

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("avradio", Context.MODE_PRIVATE); }
    static boolean enabled(Context c) { return prefs(c).getBoolean("follow", true); }
    static boolean sharing(Context c) { return prefs(c).getBoolean("shareFmlist", false); }

    static boolean hasLocationPermission(Context c) {
        return c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || c.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    /** Se llama al conceder el permiso de ubicación. */
    public void startLocation() {
        if (!hasLocationPermission(ctx)) return;
        try {
            LocationManager lm = (LocationManager) ctx.getSystemService(Context.LOCATION_SERVICE);
            for (String p : new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER}) {
                if (!lm.getAllProviders().contains(p)) continue;
                Location l = lm.getLastKnownLocation(p);
                if (l != null && (location == null || l.getTime() > location.getTime())) location = l;
                lm.requestLocationUpdates(p, 30_000, 300, this, Looper.getMainLooper());
            }
        } catch (SecurityException ignored) { }
    }

    public Location lastLocation() { return location; }

    @Override public void onLocationChanged(Location l) { location = l; record(); }
    @Override public void onStatusChanged(String p, int s, Bundle b) { }
    @Override public void onProviderEnabled(String p) { }
    @Override public void onProviderDisabled(String p) { }

    private void onMessage(Message m) {
        if (m.what == RadioLink.MSG_RADIO_INFO && m.arg1 == 0) {
            boolean st = (m.arg2 & 16) == 16;
            if (st == stereo) return;
            stereo = st;
            main.removeCallbacks(weakCheck);
            if (stereo) record();
            else main.postDelayed(weakCheck, WEAK_MS);
        } else if (m.what == RadioLink.MSG_RDS && m.obj instanceof String) {
            record();
        } else if (m.what == RadioLink.MSG_RADIO_INFO && m.arg1 == 2) {
            main.removeCallbacks(weakCheck);
        }
    }

    /** Apunta que esta emisora se oye bien aquí. */
    private void record() {
        if (!stereo || location == null || hub.freq == 0 || hub.ps.isEmpty()) return;
        ReceptionLog.get(ctx).add(hub.freq, hub.piFor(hub.freq), hub.ps, location.getLatitude(), location.getLongitude());
    }

    /** Si seguimos en mono un buen rato en una favorita, intentamos seguirla. */
    private final Runnable weakCheck = this::checkWeak;

    private void checkWeak() {
        if (!enabled(ctx) || stereo || !hub.isPowered() || location == null) return;
        if (System.currentTimeMillis() - lastJump < COOLDOWN_MS) return;
        final int f = hub.freq;
        final String pi = hub.piFor(f);
        final Favorites.Station fav = Favorites.get(ctx).find(f, pi);
        if (fav == null) return;
        final String name = fav.name.isEmpty() ? hub.ps : fav.name;
        hub.log("Seguir emisora: " + name + " con señal débil en " + fmt(f));
        if (FmlistApi.available()) {
            FmlistApi.findFrequency(f, pi, name, location.getLatitude(), location.getLongitude(), nf -> {
                if (nf > 0 && nf != f) jump(fav, name, pi, nf, "FMLIST");
                else tryLocal(fav, name, pi, f);
            });
        } else {
            tryLocal(fav, name, pi, f);
        }
    }

    private void tryLocal(Favorites.Station fav, String name, String pi, int f) {
        ReceptionLog.Entry e = ReceptionLog.get(ctx).findAlternative(f, pi, name,
                location.getLatitude(), location.getLongitude(), MAX_KM);
        if (e != null) jump(fav, name, pi, e.freq, "historial");
        else hub.log("Seguir emisora: no hay otra frecuencia conocida cerca");
    }

    private void jump(Favorites.Station fav, String name, String pi, int nf, String source) {
        lastJump = System.currentTimeMillis();
        hub.log("Seguir emisora: " + name + " → " + fmt(nf) + " (" + source + ")");
        hub.link().tune(nf);
        fav.freq = nf;
        Favorites.get(ctx).add(nf, fav.name, pi);   // guarda la nueva frecuencia en la favorita
        showPopup(name, nf);
    }

    private void showPopup(String name, int f) {
        LinearLayout box = new LinearLayout(ctx);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(ctx, 18);
        box.setPadding(Ui.dp(ctx, 26), p, Ui.dp(ctx, 26), p);
        box.setBackground(Ui.rounded(0xF0141B2A, Ui.dp(ctx, 22), Ui.ACCENT, Ui.dp(ctx, 2)));
        TextView a = Ui.text(ctx, "Siguiendo la emisora", 13, Ui.TEXT_3, true);
        TextView b = Ui.text(ctx, name, 28, Ui.TEXT, true);
        TextView c = Ui.text(ctx, "Nueva frecuencia: " + fmt(f), 18, Ui.ACCENT, false);
        b.setPadding(0, Ui.dp(ctx, 4), 0, Ui.dp(ctx, 4));
        a.setGravity(Gravity.CENTER);
        b.setGravity(Gravity.CENTER);
        c.setGravity(Gravity.CENTER);
        box.addView(a);
        box.addView(b);
        box.addView(c);
        int h = ctx.getResources().getDisplayMetrics().heightPixels;
        Popup.show(ctx, box, 4500, (int) (h * 0.16f));
    }

    private static String fmt(int f) { return String.format(Locale.ROOT, "%.1f MHz", f / 100.0); }
}
