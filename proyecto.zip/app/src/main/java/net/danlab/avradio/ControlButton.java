package net.danlab.avradio;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;

/** Botón redondo con icono dibujado (buscar / paso). */
public class ControlButton extends View {
    public static final int SEEK_PREV = 0, STEP_PREV = 1, STEP_NEXT = 2, SEEK_NEXT = 3;
    private final int type;
    private final boolean big;
    private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint icon = new Paint(Paint.ANTI_ALIAS_FLAG);
    private boolean pressed;

    public ControlButton(Context c, int type, boolean big) {
        super(c);
        this.type = type;
        this.big = big;
        ring.setStyle(Paint.Style.STROKE);
        icon.setColor(Ui.TEXT);
        setClickable(true);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) { pressed = true; invalidate(); }
        if (e.getActionMasked() == MotionEvent.ACTION_UP || e.getActionMasked() == MotionEvent.ACTION_CANCEL) {
            pressed = false; invalidate();
        }
        return super.onTouchEvent(e);
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), cx = w / 2f, cy = h / 2f;
        float r = Math.min(w, h) / 2f * 0.92f;
        int top = pressed ? Ui.ACCENT : (big ? Ui.CARD_ON : Ui.CARD);
        bg.setShader(new RadialGradient(cx, cy - r * 0.4f, r * 1.3f,
                new int[]{top, Color.rgb(14, 18, 28)}, null, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, r, bg);
        ring.setStrokeWidth(Ui.dp(getContext(), 1.2f));
        ring.setColor(big ? Color.argb(110, Color.red(Ui.ACCENT), Color.green(Ui.ACCENT), Color.blue(Ui.ACCENT)) : Ui.LINE);
        c.drawCircle(cx, cy, r, ring);

        float s = r * 0.42f;
        switch (type) {
            case SEEK_PREV:
                bar(c, cx - s * 1.05f, cy, s);
                tri(c, cx + s * 0.05f, cy, s, false);
                tri(c, cx + s * 1.05f, cy, s, false);
                break;
            case SEEK_NEXT:
                tri(c, cx - s * 1.05f, cy, s, true);
                tri(c, cx - s * 0.05f, cy, s, true);
                bar(c, cx + s * 1.05f, cy, s);
                break;
            case STEP_PREV: tri(c, cx + s * 0.4f, cy, s, false); break;
            case STEP_NEXT: tri(c, cx - s * 0.4f, cy, s, true); break;
        }
    }

    /** Triángulo cuyo lado vertical está en x (apuntando a derecha o izquierda). */
    private void tri(Canvas c, float x, float cy, float s, boolean right) {
        Path p = new Path();
        float dx = right ? s * 0.9f : -s * 0.9f;
        p.moveTo(x, cy - s * 0.6f);
        p.lineTo(x + dx, cy);
        p.lineTo(x, cy + s * 0.6f);
        p.close();
        c.drawPath(p, icon);
    }

    private void bar(Canvas c, float x, float cy, float s) {
        c.drawRect(x - s * 0.09f, cy - s * 0.6f, x + s * 0.09f, cy + s * 0.6f, icon);
    }
}
