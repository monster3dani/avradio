package net.danlab.avradio;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Conexión única con el sintonizador, compartida por la pantalla, el servicio en
 * segundo plano y el widget. Sigue funcionando aunque AVRadio no esté abierta.
 */
public class RadioHub {

    public interface StationListener { void onStationChanged(int freq, String name, String pi, boolean fromSteering); }

    private static RadioHub instance;
    public static synchronized RadioHub get(Context c) {
        if (instance == null) instance = new RadioHub(c.getApplicationContext());
        return instance;
    }

    private final Context ctx;
    private final RadioLink link = new RadioLink();
    private final List<Handler> listeners = new ArrayList<>();
    private final List<StationListener> stationListeners = new ArrayList<>();
    private final Handler main = new Handler(Looper.getMainLooper());
    private String openError;

    // Estado actual (para notificación, widget y aviso emergente)
    public int freq;
    public String ps = "";
    public String rt = "";
    /** frecuencia -> PI, de la lista del sintonizador */
    private final java.util.HashMap<Integer, String> piByFreq = new java.util.HashMap<>();
    private boolean lastFromSteering, restored;

    private final Handler in = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) { onMessage(msg); }
    };

    private RadioHub(Context c) { ctx = c; }

    /** Abre la conexión (solo la primera vez). Devuelve null si va bien. */
    public synchronized String start() {
        if (link.isOpen()) return null;
        openError = link.open(in);
        if (openError == null) {
            if (ctx.getSharedPreferences("avradio", Context.MODE_PRIVATE).getBoolean("poweredOff", false)) {
                powered = false;
                return null;
            }
            link.requestRadioSource();
            // Volver a la última emisora que sonaba
            final int last = ctx.getSharedPreferences("avradio", Context.MODE_PRIVATE).getInt("lastFreq", 0);
            main.postDelayed(() -> {
                if (last > 0 && last != freq) link.tune(last);
                restored = true;
            }, 1500);
        }
        return openError;
    }

    public RadioLink link() { return link; }

    // --- Volumen al arrancar ---
    public int volume = -1, volumeMax = 30;

    /**
     * Pone el volumen al nivel elegido. Prueba varias formas y recuerda la que funciona
     * en esta pantalla (lo comprueba con el aviso de volumen del propio sintonizador).
     */
    public void applyVolume(final int target) {
        if (target <= 0 || !link.isOpen()) return;
        final android.content.SharedPreferences p = ctx.getSharedPreferences("avradio", Context.MODE_PRIVATE);
        link.raw(515, 255, 0);                       // pedir el volumen actual
        main.postDelayed(() -> {
            if (volume == target) { p.edit().putString("volResult", "ya estaba en " + target).apply(); return; }
            String known = p.getString("volMethod", "");
            if (!known.isEmpty()) { useMethod(known, target); verify(known, target, null); return; }
            tryMethods(new String[]{"B", "A", "C"}, 0, target);
        }, 600);
    }

    private void tryMethods(final String[] m, final int i, final int target) {
        if (i >= m.length) {
            ctx.getSharedPreferences("avradio", Context.MODE_PRIVATE).edit()
                    .putString("volResult", "no se ha podido (sigue en " + volume + ")").apply();
            return;
        }
        useMethod(m[i], target);
        verify(m[i], target, () -> tryMethods(m, i + 1, target));
    }

    private void verify(final String method, final int target, final Runnable onFail) {
        main.postDelayed(() -> {
            link.raw(515, 255, 0);
            main.postDelayed(() -> {
                android.content.SharedPreferences p = ctx.getSharedPreferences("avradio", Context.MODE_PRIVATE);
                log("Volumen: ahora está en " + volume);
                if (volume == target) {
                    p.edit().putString("volMethod", method)
                            .putString("volResult", "OK, puesto a " + target + " (método " + method + ")").apply();
                } else if (onFail != null) {
                    onFail.run();
                } else {
                    p.edit().remove("volMethod").apply();
                }
            }, 500);
        }, 1500);
    }

    /** Mensaje para el registro técnico de la pantalla. */
    public void log(String text) {
        for (Handler h : new ArrayList<>(listeners)) {
            Message m = Message.obtain();
            m.what = 99999;
            m.obj = text;
            h.sendMessage(m);
        }
    }

    private void useMethod(String m, int target) {
        log("Volumen: probando método " + m + " (de " + volume + " a " + target + ")");
        android.media.AudioManager am = (android.media.AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        switch (m) {
            case "A": // volumen de Android
                try {
                    int max = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC);
                    int v = Math.round(target * max / (float) Math.max(1, volumeMax));
                    am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, v, 0);
                } catch (Exception ignored) { }
                break;
            case "B": // orden directa al sintonizador (la misma que usa el reproductor de vídeo original)
                link.raw(515, 1, target);
                break;
            case "C": { // pulsaciones de volumen, una a una
                final int steps = Math.abs(volume - target);
                final int dir = volume > target ? android.media.AudioManager.ADJUST_LOWER : android.media.AudioManager.ADJUST_RAISE;
                for (int k = 0; k < Math.min(steps, 30); k++) {
                    main.postDelayed(() -> {
                        try { am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, dir, 0); } catch (Exception ignored) { }
                    }, k * 120L);
                }
                break;
            }
        }
    }

    // --- Encendido / apagado ---
    private boolean powered = true;
    private final List<Runnable> powerListeners = new ArrayList<>();
    public boolean isPowered() { return powered; }
    public void addPowerListener(Runnable r) { if (!powerListeners.contains(r)) powerListeners.add(r); }
    public void removePowerListener(Runnable r) { powerListeners.remove(r); }

    public void powerOn() {
        link.requestRadioSource();
        setPowered(true);
    }

    public void powerOff() {
        link.releaseRadioSource();
        setPowered(false);
    }

    private void setPowered(boolean p) {
        boolean changed = p != powered;
        powered = p;
        ctx.getSharedPreferences("avradio", Context.MODE_PRIVATE).edit().putBoolean("poweredOff", !p).apply();
        if (changed) for (Runnable r : new ArrayList<>(powerListeners)) r.run();
    }

    /** Vuelve a la última emisora guardada (al encender el coche). */
    public void restoreLast() {
        final int last = ctx.getSharedPreferences("avradio", Context.MODE_PRIVATE).getInt("lastFreq", 0);
        restored = false;
        main.postDelayed(() -> {
            if (last > 0 && last != freq) link.tune(last);
            restored = true;
        }, 1500);
    }
    public boolean isOpen() { return link.isOpen(); }

    public void addListener(Handler h) { if (!listeners.contains(h)) listeners.add(h); }
    public void removeListener(Handler h) { listeners.remove(h); }
    public void addStationListener(StationListener l) { if (!stationListeners.contains(l)) stationListeners.add(l); }

    public String piFor(int f) {
        String p = piByFreq.get(f);
        if (p != null && !p.isEmpty()) return p;
        Favorites.Station s = Favorites.get(ctx).find(f, "");
        return s != null ? s.pi : "";
    }

    /** Nombre a mostrar: RDS, o el de la favorita. */
    public String displayName() {
        Favorites.Station s = Favorites.get(ctx).find(freq, piFor(freq));
        if (s != null && s.custom) return s.name;
        if (!ps.isEmpty()) return ps;
        return s != null ? s.name : "";
    }

    private void onMessage(Message msg) {
        switch (msg.what) {
            case RadioLink.MSG_RADIO_INFO:
                if (msg.arg1 == 2 && msg.arg2 != freq) {
                    freq = msg.arg2;
                    ps = "";
                    rt = "";
                    if (restored) ctx.getSharedPreferences("avradio", Context.MODE_PRIVATE).edit().putInt("lastFreq", freq).apply();
                    scheduleStationEvent();
                }
                break;
            case RadioLink.MSG_RDS:
                if (msg.obj instanceof String) {
                    String n = ((String) msg.obj).trim();
                    if (!n.isEmpty() && !n.equals(ps)) { ps = n; scheduleStationEvent(); }
                }
                break;
            case RadioLink.MSG_RDS_TEXT:
                if (msg.obj instanceof String) rt = ((String) msg.obj).trim();
                break;
            case RadioLink.MSG_PRESET: {
                int pi = (msg.arg1 >> 16) & 0xFFFF;
                if (msg.arg2 > 0 && pi != 0) piByFreq.put(msg.arg2, String.format(Locale.ROOT, "%04X", pi));
                break;
            }
            case 515: // volumen: arg1 = nivel, arg2 = máximo (bit alto = silencio)
                volume = msg.arg1;
                volumeMax = msg.arg2 & 0x7FFFFFFF;
                break;
            case RadioLink.MSG_STEERING:
                if (msg.arg1 == 3) stepFavorite(+1);
                else if (msg.arg1 == 4) stepFavorite(-1);
                break;
        }
        for (Handler h : new ArrayList<>(listeners)) {
            Message m = Message.obtain();
            m.copyFrom(msg);
            h.sendMessage(m);
        }
    }

    /** Espera a que la emisora se "asiente" (no durante la búsqueda) antes de avisar. */
    private final Runnable stationEvent = () -> {
        String name = displayName();
        for (StationListener l : new ArrayList<>(stationListeners))
            l.onStationChanged(freq, name, piFor(freq), lastFromSteering);
        lastFromSteering = false;
    };

    private void scheduleStationEvent() {
        main.removeCallbacks(stationEvent);
        main.postDelayed(stationEvent, 1300);
    }

    /** Volante / widget: pasa a la favorita siguiente o anterior. */
    public void stepFavorite(int dir) {
        if (!powered) powerOn();
        List<Favorites.Station> l = Favorites.get(ctx).all();
        lastFromSteering = true;
        if (l.isEmpty()) { if (dir > 0) link.seekNext(); else link.seekPrev(); return; }
        Favorites.Station cur = Favorites.get(ctx).find(freq, piFor(freq));
        int idx = cur != null ? l.indexOf(cur) : -1;
        int n = l.size();
        int next = idx < 0 ? (dir > 0 ? 0 : n - 1) : ((idx + dir) % n + n) % n;
        Favorites.Station target = l.get(next);
        link.tune(target.freq);
    }
}
