package net.danlab.avradio;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

/** Fondo de AVRadio: degradado del tema con formas suaves (no un color plano). */
public class BackgroundView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int style = Ui.style;
    private int top = Ui.BG_TOP, bottom = Ui.BG_BOTTOM, a1 = Ui.ACCENT, a2 = Ui.ACCENT_2;

    public BackgroundView(Context c) { super(c); }

    /** Para la vista previa del selector de colores. */
    public void preview(int themeIdx, int styleIdx) {
        Object[] t = Ui.THEMES[themeIdx];
        top = (Integer) t[1];
        bottom = (Integer) t[2];
        a1 = (Integer) t[5];
        a2 = (Integer) t[6];
        style = styleIdx;
        invalidate();
    }

    private static int alpha(int c, int a) { return Color.argb(a, Color.red(c), Color.green(c), Color.blue(c)); }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        p.setShader(new LinearGradient(0, 0, 0, h, top, bottom, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);

        switch (style) {
            case 1: // Aurora: manchas de luz difuminadas
                blob(c, w * 0.15f, h * 0.18f, w * 0.75f, alpha(a1, 70));
                blob(c, w * 0.95f, h * 0.38f, w * 0.70f, alpha(a2, 60));
                blob(c, w * 0.30f, h * 0.85f, w * 0.80f, alpha(a1, 35));
                break;
            case 2: { // Ondas
                blob(c, w * 0.5f, h * 0.15f, w * 0.8f, alpha(a1, 40));
                p.setShader(null);
                p.setStyle(Paint.Style.STROKE);
                for (int i = 0; i < 7; i++) {
                    Path path = new Path();
                    float base = h * (0.45f + i * 0.07f);
                    float amp = h * (0.03f + i * 0.006f);
                    path.moveTo(0, base);
                    for (float x = 0; x <= w; x += w / 40f) {
                        path.lineTo(x, base + (float) Math.sin(x / w * Math.PI * 2 + i * 0.7) * amp);
                    }
                    p.setStrokeWidth(Ui.dp(getContext(), 1.5f));
                    p.setColor(alpha(i % 2 == 0 ? a1 : a2, 40 - i * 4));
                    c.drawPath(path, p);
                }
                p.setStyle(Paint.Style.FILL);
                break;
            }
            case 3: { // Líneas diagonales
                blob(c, w * 0.85f, h * 0.1f, w * 0.7f, alpha(a1, 55));
                p.setShader(null);
                p.setStrokeWidth(Ui.dp(getContext(), 1));
                float step = Ui.dp(getContext(), 26);
                for (float x = -h; x < w; x += step) {
                    p.setColor(alpha(a1, 14));
                    c.drawLine(x, h, x + h, 0, p);
                }
                break;
            }
            default: // Degradado con un brillo arriba
                blob(c, w * 0.5f, h * 0.2f, w * 0.85f, alpha(a1, 45));
        }
    }

    private void blob(Canvas c, float x, float y, float r, int color) {
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(x, y, r, color, alpha(color, 0), Shader.TileMode.CLAMP));
        c.drawCircle(x, y, r, p);
    }
}
