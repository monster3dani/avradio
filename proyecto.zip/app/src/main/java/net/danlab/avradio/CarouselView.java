package net.danlab.avradio;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

import java.util.ArrayList;
import java.util.List;

/** Carrusel de emisoras estilo coche moderno: la actual grande en el centro. */
public class CarouselView extends View {

    public static class Item {
        public int freq;
        public String name = "";
        public String key = "";
        public Bitmap logo;
        public boolean favorite;
    }

    public interface Listener {
        void onPick(Item item);
        void onLongPress(Item item);
    }

    private final List<Item> items = new ArrayList<>();
    private float pos = 0;              // posición mostrada (índice, con decimales)
    private int selected = 0;
    private Listener listener;
    private ValueAnimator anim;

    private final Paint card = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bmp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);

    private float downX, downPos;
    private long downTime;
    private boolean moved, longFired;
    private final Runnable longPress = () -> {
        if (!moved && listener != null && !items.isEmpty()) {
            longFired = true;
            listener.onLongPress(items.get(selected));
        }
    };

    public CarouselView(Context c) {
        super(c);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        stroke.setStyle(Paint.Style.STROKE);
        txt.setTextAlign(Paint.Align.CENTER);
        txt.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
    }

    public void setListener(Listener l) { listener = l; }

    public void setItems(List<Item> list, int sel) {
        items.clear();
        items.addAll(list);
        if (items.isEmpty()) { selected = 0; pos = 0; invalidate(); return; }
        sel = Math.max(0, Math.min(items.size() - 1, sel));
        boolean jump = Math.abs(sel - pos) > 3 || anim == null;
        selected = sel;
        if (jump) { cancelAnim(); pos = sel; invalidate(); }
        else animateTo(sel);
    }

    private void cancelAnim() { if (anim != null) anim.cancel(); }

    private void animateTo(float target) {
        cancelAnim();
        anim = ValueAnimator.ofFloat(pos, target);
        anim.setDuration(320);
        anim.setInterpolator(new DecelerateInterpolator());
        anim.addUpdateListener(a -> { pos = (float) a.getAnimatedValue(); invalidate(); });
        anim.start();
    }

    private float cardSize() { return getHeight() * 0.62f; }
    private float spacing() { return cardSize() * 0.78f; }

    @Override
    protected void onDraw(Canvas c) {
        if (items.isEmpty()) return;
        float cx = getWidth() / 2f, cy = getHeight() * 0.42f;
        // Dibujar de lejos a cerca para que la central quede encima
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < items.size(); i++) if (Math.abs(i - pos) <= 2.6f) order.add(i);
        order.sort((a, b) -> Float.compare(Math.abs(b - pos), Math.abs(a - pos)));
        for (int i : order) {
            float off = i - pos, a = Math.abs(off);
            float scale = a < 1 ? 1f - a * 0.42f : a < 2 ? 0.58f - (a - 1) * 0.2f : 0.38f - (a - 2) * 0.2f;
            float alpha = a < 1 ? 1f - a * 0.45f : a < 2 ? 0.55f - (a - 1) * 0.3f : Math.max(0f, 0.25f - (a - 2) * 0.4f);
            float x = cx + Math.signum(off) * (a < 1 ? a * spacing() : spacing() + (a - 1) * spacing() * 0.55f);
            drawCard(c, items.get(i), x, cy, cardSize() * scale, alpha, a < 0.5f);
        }
    }

    private void drawCard(Canvas c, Item it, float x, float cy, float s, float alpha, boolean center) {
        RectF r = new RectF(x - s / 2, cy - s / 2, x + s / 2, cy + s / 2);
        float rad = s * 0.12f;
        int a = (int) (255 * alpha);

        if (center) {
            glow.setColor(Ui.ACCENT);
            glow.setAlpha(150);
            glow.setShadowLayer(s * 0.12f, 0, 0, Ui.ACCENT);
            c.drawRoundRect(r, rad, rad, glow);
            glow.clearShadowLayer();
        }
        drawFace(c, it, r, rad, a);
        stroke.setStrokeWidth(center ? Ui.dp(getContext(), 2) : Ui.dp(getContext(), 1));
        stroke.setColor(center ? Ui.ACCENT : Color.argb(a / 3, 255, 255, 255));
        c.drawRoundRect(r, rad, rad, stroke);

        if (center) {
            // Reflejo suave bajo la tarjeta central
            float gap = s * 0.04f;
            int save = c.saveLayerAlpha(r.left, r.bottom + gap, r.right, r.bottom + gap + s * 0.35f, 60);
            c.translate(0, r.bottom * 2 + gap);
            c.scale(1, -1);
            drawFace(c, it, r, rad, 255);
            c.restoreToCount(save);
            Paint fade = new Paint();
            fade.setShader(new LinearGradient(0, r.bottom + gap, 0, r.bottom + gap + s * 0.35f,
                    Color.argb(0, 0, 0, 0), Color.argb(255, 6, 9, 16), Shader.TileMode.CLAMP));
            c.drawRect(r.left - 2, r.bottom + gap, r.right + 2, r.bottom + gap + s * 0.36f, fade);
            // Línea luminosa
            Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
            line.setColor(Ui.ACCENT);
            line.setStrokeWidth(Ui.dp(getContext(), 3));
            line.setShadowLayer(Ui.dp(getContext(), 8), 0, 0, Ui.ACCENT);
            c.drawLine(r.left + s * 0.1f, r.bottom + gap * 0.5f, r.right - s * 0.1f, r.bottom + gap * 0.5f, line);
        }
        if (!it.favorite && center) {
            txt.setTextSize(s * 0.09f);
            txt.setColor(Color.argb(200, 255, 255, 255));
            c.drawText("No guardada", x, r.top - s * 0.06f, txt);
        }
    }

    private void drawFace(Canvas c, Item it, RectF r, float rad, int a) {
        Path clip = new Path();
        clip.addRoundRect(r, rad, rad, Path.Direction.CW);
        c.save();
        c.clipPath(clip);
        if (it.logo != null) {
            card.setShader(null);
            card.setColor(Color.argb(a, 244, 246, 250));
            c.drawRect(r, card);
            float pad = r.width() * 0.1f;
            float bw = it.logo.getWidth(), bh = it.logo.getHeight();
            float k = Math.min((r.width() - 2 * pad) / bw, (r.height() - 2 * pad) / bh);
            float dw = bw * k, dh = bh * k;
            RectF dst = new RectF(r.centerX() - dw / 2, r.centerY() - dh / 2, r.centerX() + dw / 2, r.centerY() + dh / 2);
            bmp.setAlpha(a);
            c.drawBitmap(it.logo, new Rect(0, 0, (int) bw, (int) bh), dst, bmp);
        } else {
            int col = Ui.stationColor(it.key.isEmpty() ? it.name : it.key);
            card.setShader(new LinearGradient(r.left, r.top, r.right, r.bottom,
                    Color.argb(a, Math.min(255, Color.red(col) + 20), Math.min(255, Color.green(col) + 20), Math.min(255, Color.blue(col) + 20)),
                    Color.argb(a, Color.red(col) / 3, Color.green(col) / 3, Color.blue(col) / 3),
                    Shader.TileMode.CLAMP));
            c.drawRect(r, card);
            String lab = Ui.initials(it.name.isEmpty() ? "FM" : it.name);
            txt.setColor(Color.argb(a, 255, 255, 255));
            txt.setTextSize(r.width() * (lab.length() > 2 ? 0.28f : 0.36f));
            Paint.FontMetrics fm = txt.getFontMetrics();
            c.drawText(lab, r.centerX(), r.centerY() - (fm.ascent + fm.descent) / 2f, txt);
        }
        c.restore();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (items.isEmpty()) return false;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                cancelAnim();
                downX = e.getX();
                downPos = pos;
                downTime = System.currentTimeMillis();
                moved = false;
                longFired = false;
                getParent().requestDisallowInterceptTouchEvent(true);
                postDelayed(longPress, 600);
                return true;
            case MotionEvent.ACTION_MOVE: {
                float dx = e.getX() - downX;
                if (Math.abs(dx) > Ui.dp(getContext(), 8)) { moved = true; removeCallbacks(longPress); }
                if (moved) {
                    pos = Math.max(0, Math.min(items.size() - 1, downPos - dx / spacing()));
                    invalidate();
                }
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                removeCallbacks(longPress);
                if (longFired) { animateTo(selected); return true; }
                int target;
                if (!moved) {
                    // Toque: ¿en qué tarjeta?
                    float off = (e.getX() - getWidth() / 2f) / spacing();
                    target = Math.round(Math.max(0, Math.min(items.size() - 1, pos + (Math.abs(off) < 0.5f ? 0 : Math.signum(off) * (Math.abs(off) < 1.6f ? 1 : 2)))));
                } else {
                    float vel = (e.getX() - downX) / Math.max(1, System.currentTimeMillis() - downTime);
                    float fling = Math.abs(vel) > 1.2f ? -Math.signum(vel) : 0;
                    target = Math.round(Math.max(0, Math.min(items.size() - 1, pos + fling * 0.6f)));
                }
                animateTo(target);
                if (target != selected) {
                    selected = target;
                    if (listener != null) listener.onPick(items.get(target));
                }
                return true;
            }
        }
        return super.onTouchEvent(e);
    }
}
