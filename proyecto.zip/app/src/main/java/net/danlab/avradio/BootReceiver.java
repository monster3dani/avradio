package net.danlab.avradio;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Al arrancar la pantalla: pone en marcha AVRadio y, si está activado, la abre. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        RadioService.start(c);
        if (RadioService.autostartEnabled(c)) RadioService.openApp(c);
    }
}
