package net.danlab.avradio;

import android.app.Notification;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.text.TextUtils;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashSet;
import java.util.Set;

/**
 * Avisos de notificaciones en pantalla (WhatsApp, Telegram, llamadas…),
 * porque la barra superior de la TS10 no las muestra.
 */
public class NotifyService extends NotificationListenerService {

    /** Apps que se avisan por defecto si están instaladas. */
    static final String[] DEFAULT_APPS = {
            "com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger",
            "com.google.android.apps.messaging", "com.android.mms",
            "com.google.android.dialer", "com.android.dialer", "com.android.incallui"};

    private String lastKey = "";
    private long lastAt;

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("avradio", MODE_PRIVATE); }

    static boolean hasPermission(Context c) {
        String flat = Settings.Secure.getString(c.getContentResolver(), "enabled_notification_listeners");
        return flat != null && flat.contains(new ComponentName(c, NotifyService.class).flattenToString());
    }

    /** Apps marcadas para avisar. */
    static Set<String> enabledApps(Context c) {
        Set<String> def = new HashSet<>();
        for (String p : DEFAULT_APPS) def.add(p);
        return new HashSet<>(prefs(c).getStringSet("notifyApps", def));
    }

    /** Apps que han mandado alguna notificación (para poder elegirlas en Ajustes). */
    static Set<String> seenApps(Context c) {
        return new HashSet<>(prefs(c).getStringSet("seenApps", new HashSet<>()));
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || getPackageName().equals(sbn.getPackageName())) return;
        Notification n = sbn.getNotification();
        if (n == null) return;
        if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
        if ((n.flags & Notification.FLAG_ONGOING_EVENT) != 0 && !Notification.CATEGORY_CALL.equals(n.category)) return;

        String pkg = sbn.getPackageName();
        SharedPreferences p = prefs(this);
        Set<String> seen = seenApps(this);
        if (seen.add(pkg)) p.edit().putStringSet("seenApps", seen).apply();

        if (!p.getBoolean("notifyOn", true)) return;
        if (!enabledApps(this).contains(pkg)) return;

        Bundle ex = n.extras;
        CharSequence title = ex != null ? ex.getCharSequence(Notification.EXTRA_TITLE) : null;
        CharSequence text = ex != null ? ex.getCharSequence(Notification.EXTRA_TEXT) : null;
        if (TextUtils.isEmpty(title) && TextUtils.isEmpty(text)) return;

        // Evitar repetidos (algunas apps actualizan la misma notificación varias veces)
        String key = pkg + "|" + title + "|" + text;
        long now = System.currentTimeMillis();
        if (key.equals(lastKey) && now - lastAt < 8000) return;
        lastKey = key;
        lastAt = now;

        String app = label(this, pkg);
        boolean showText = p.getBoolean("notifyText", true);
        show(TextUtils.isEmpty(title) ? app : title.toString(),
                showText && !TextUtils.isEmpty(text) ? text.toString() : "Nuevo aviso",
                app, icon(this, pkg));
    }

    static String label(Context c, String pkg) {
        try {
            PackageManager pm = c.getPackageManager();
            return pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString();
        } catch (Exception e) { return pkg; }
    }

    static Bitmap icon(Context c, String pkg) {
        try {
            Drawable d = c.getPackageManager().getApplicationIcon(pkg);
            if (d instanceof BitmapDrawable) return ((BitmapDrawable) d).getBitmap();
            int s = 128;
            Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(b);
            d.setBounds(0, 0, s, s);
            d.draw(cv);
            return b;
        } catch (Exception e) { return null; }
    }

    /** Cartel emergente en la parte de arriba de la pantalla. */
    private void show(String title, String text, String app, Bitmap icon) {
        LinearLayout box = new LinearLayout(this);
        box.setGravity(Gravity.CENTER_VERTICAL);
        int p = Ui.dp(this, 16);
        box.setPadding(p, p, Ui.dp(this, 24), p);
        box.setBackground(Ui.rounded(0xF0141B2A, Ui.dp(this, 22), Ui.ACCENT, Ui.dp(this, 2)));
        if (icon != null) {
            ImageView iv = new ImageView(this);
            iv.setImageBitmap(icon);
            box.addView(iv, new LinearLayout.LayoutParams(Ui.dp(this, 64), Ui.dp(this, 64)));
        }
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setPadding(Ui.dp(this, 16), 0, 0, 0);
        TextView a = Ui.text(this, app, 13, Ui.TEXT_3, true);
        TextView b = Ui.text(this, title, 24, Ui.TEXT, true);
        b.setSingleLine(true);
        b.setEllipsize(TextUtils.TruncateAt.END);
        b.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 4));
        TextView c = Ui.text(this, text, 18, Ui.TEXT_2, false);
        c.setMaxLines(2);
        c.setEllipsize(TextUtils.TruncateAt.END);
        t.addView(a);
        t.addView(b);
        t.addView(c);
        box.addView(t, new LinearLayout.LayoutParams(Ui.dp(this, 460), LinearLayout.LayoutParams.WRAP_CONTENT));
        Toast toast = new Toast(getApplicationContext());
        toast.setView(box);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, Ui.dp(this, 40));
        toast.show();
    }
}
