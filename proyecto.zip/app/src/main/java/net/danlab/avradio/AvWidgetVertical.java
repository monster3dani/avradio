package net.danlab.avradio;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;

/** Widget vertical: logo arriba, botones abajo. */
public class AvWidgetVertical extends AppWidgetProvider {
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        RadioService.start(c);
        Widgets.update(c);
    }
}
