package net.danlab.avradio;

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

/** Carteles emergentes sobre cualquier app, con la duración que queramos. */
final class Popup {
    private Popup() { }

    private static View current;
    private static final Handler main = new Handler(Looper.getMainLooper());
    private static final Runnable hide = Popup::hideNow;

    static void show(Context c, View v, long ms, int yOffsetPx) {
        Context app = c.getApplicationContext();
        if (!Settings.canDrawOverlays(app)) {           // sin permiso: aviso normal de Android
            Toast t = new Toast(app);
            t.setView(v);
            t.setDuration(ms > 3000 ? Toast.LENGTH_LONG : Toast.LENGTH_SHORT);
            t.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, yOffsetPx);
            t.show();
            return;
        }
        hideNow();
        WindowManager wm = (WindowManager) app.getSystemService(Context.WINDOW_SERVICE);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.y = yOffsetPx;
        try {
            v.setAlpha(0f);
            wm.addView(v, lp);
            v.animate().alpha(1f).setDuration(220).start();
            current = v;
            main.removeCallbacks(hide);
            main.postDelayed(hide, ms);
        } catch (Exception e) {
            current = null;
        }
    }

    private static void hideNow() {
        main.removeCallbacks(hide);
        final View v = current;
        current = null;
        if (v == null) return;
        try {
            WindowManager wm = (WindowManager) v.getContext().getApplicationContext().getSystemService(Context.WINDOW_SERVICE);
            wm.removeView(v);
        } catch (Exception ignored) { }
    }
}
