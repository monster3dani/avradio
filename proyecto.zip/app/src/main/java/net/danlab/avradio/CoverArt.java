package net.danlab.avradio;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Busca la carátula de la canción a partir del texto RDS "Artista - Canción". */
public class CoverArt {

    public interface Callback { void onCover(String forText, Bitmap cover); }

    private final LruCache<String, Bitmap> cache = new LruCache<>(30);
    private final ExecutorService pool = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private String pending = "";

    /** Devuelve "artista - canción" limpio, o null si el texto no lo parece. */
    public static String songQuery(String rt) {
        if (rt == null) return null;
        String t = rt.trim();
        String[] seps = {" - ", " – ", " / ", " | "};
        for (String s : seps) {
            int i = t.indexOf(s);
            if (i > 1 && i < t.length() - 3) {
                String a = t.substring(0, i).trim(), b = t.substring(i + s.length()).trim();
                if (a.length() > 40 || b.length() > 60) return null;
                String low = t.toLowerCase();
                if (low.contains("www") || low.contains("http") || low.contains("@")) return null;
                return a + " " + b;
            }
        }
        return null;
    }

    public void find(final String rt, final Callback cb) {
        final String q = songQuery(rt);
        if (q == null) { cb.onCover(rt, null); return; }
        Bitmap c = cache.get(q);
        if (c != null) { cb.onCover(rt, c); return; }
        if (q.equals(pending)) return;
        pending = q;
        pool.execute(() -> {
            Bitmap b = null;
            try {
                String url = "https://itunes.apple.com/search?media=music&entity=song&limit=1&country=ES&term="
                        + URLEncoder.encode(q, "UTF-8");
                byte[] d = get(url, 200 * 1024);
                if (d != null) {
                    JSONArray r = new JSONObject(new String(d, "UTF-8")).optJSONArray("results");
                    if (r != null && r.length() > 0) {
                        String art = r.getJSONObject(0).optString("artworkUrl100", "");
                        if (!art.isEmpty()) {
                            byte[] img = get(art.replace("100x100", "400x400"), 2 * 1024 * 1024);
                            if (img != null) b = BitmapFactory.decodeByteArray(img, 0, img.length);
                        }
                    }
                }
            } catch (Exception ignored) { }
            final Bitmap res = b;
            if (res != null) cache.put(q, res);
            main.post(() -> { pending = ""; cb.onCover(rt, res); });
        });
    }

    private static byte[] get(String url, int max) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(7000);
        c.setReadTimeout(9000);
        c.setRequestProperty("User-Agent", "AVRadio (DanLab)");
        try {
            if (c.getResponseCode() != 200) return null;
            InputStream in = c.getInputStream();
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n, t = 0;
            while ((n = in.read(buf)) > 0) { t += n; if (t > max) return null; o.write(buf, 0, n); }
            return o.toByteArray();
        } finally { c.disconnect(); }
    }
}
