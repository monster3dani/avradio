package net.danlab.avradio;

import android.os.Handler;
import android.tw.john.TWUtil;

/** Comunicación con el sintonizador de la pantalla (MCU TopWay). */
public class RadioLink {

    // Mensajes (descubiertos en la app de radio original com.tw.radio)
    public static final int MSG_RADIO_INFO = 1025;  // estado: frecuencia, nombre, flags
    public static final int MSG_PRESET     = 1026;  // emisoras guardadas (con PI)
    public static final int MSG_RDS        = 1028;  // flags RDS (AF/TA/REG) + PI
    public static final int MSG_RDS_TEXT   = 1029;  // texto RDS
    public static final int MSG_REGION     = 1030;
    public static final int MSG_SOURCE     = 769;   // fuente de audio actual
    public static final int MSG_STEERING   = 40449; // botones del volante

    private static final short[] IDS = {265, 266, 274, 513, 515, 769,
            1025, 1026, 1028, 1029, 1030, (short) 40448, (short) 40449};

    private TWUtil tw;

    /** Devuelve null si va bien, o el texto del error. */
    public String open(Handler handler) {
        try {
            tw = new TWUtil(1);
            int r = tw.open(IDS);
            if (r != 0) {
                tw = null;
                return "open() devolvió " + r;
            }
            tw.start();
            tw.addHandler("AVRadio", handler);
            requestAll();
            return null;
        } catch (Throwable t) {
            tw = null;
            return t.toString();
        }
    }

    /** Pide el estado actual (igual que hace la radio original al arrancar). */
    public void requestAll() {
        if (tw == null) return;
        tw.write(265, 255);
        tw.write(266, 255);
        tw.write(769, 255);
        tw.write(274, 255);
        tw.write(1030, 0);
        tw.write(1025, 255);
        tw.write(1028, 255);
        tw.write(515, 255);
    }

    public boolean isOpen() { return tw != null; }

    public void close() {
        if (tw == null) return;
        try {
            tw.removeHandler("AVRadio");
            tw.stop();
            tw.close();
        } catch (Throwable ignored) { }
        tw = null;
    }

    private void w(int what, int a1, int a2) {
        if (tw != null) tw.write(what, a1, a2);
    }

    /** Pide que suene la radio (fuente de audio = radio). */
    public void requestRadioSource() {
        w(40448, 1, 0);
        w(40465, 192, 1);
    }

    /** Frecuencia en unidades de 10 kHz: 89.8 MHz = 8980 */
    public void tune(int freq)  { w(1026, 255, freq); }
    public void seekNext()      { w(1025, 1, 0); }
    public void seekPrev()      { w(1025, 1, 1); }
    public void stepNext()      { w(1025, 2, 0); }
    public void stepPrev()      { w(1025, 2, 1); }
    /** Búsqueda automática de todas las emisoras (las guarda en el sintonizador). */
    public void autoStore()     { w(1025, 0, 0); }
    /** on = true para activar AF */
    public void setAf(boolean on) { w(1028, 0, on ? 1 : 0); }
    /** on = true para activar TA (avisos de tráfico) */
    public void setTa(boolean on) { w(1028, 1, on ? 1 : 0); }
}
