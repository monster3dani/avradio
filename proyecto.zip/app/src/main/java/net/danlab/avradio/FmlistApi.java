package net.danlab.avradio;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * API de FMLIST / FMSCAN: frecuencias alternativas de una emisora según la posición.
 * Frequency data: FMLIST / FMSCAN.
 */
public final class FmlistApi {
    private FmlistApi() { }

    public static final String CREDIT = "Datos de frecuencias: FMLIST / FMSCAN";

    public static class Alt {
        public int freq;        // en unidades de 10 kHz (89.8 MHz = 8980)
        public int dbuv;        // señal prevista
        public String program = "";
        public boolean current;
    }

    public static class Answer {
        public String station = "", matchedBy = "", error;
        public double lat, lon, cacheKm;
        public long time;
        public final List<Alt> alts = new ArrayList<>();
    }

    public interface Callback { void onAnswer(Answer a); }
    public interface FreqResult { void onResult(int freq); }

    private static final ExecutorService pool = Executors.newSingleThreadExecutor();
    private static final Handler main = new Handler(Looper.getMainLooper());
    private static long blockedUntil;     // si FMLIST pide esperar (demasiadas consultas)
    private static Context app;

    public static void init(Context c) { app = c.getApplicationContext(); }

    public static boolean available() { return BuildConfig.FMLIST_KEY != null && !BuildConfig.FMLIST_KEY.isEmpty(); }

    /** Frecuencias de la misma emisora aquí. Usa la respuesta guardada si estamos cerca (sin cobertura). */
    public static void alternatives(final int freq, final String pi, final double lat, final double lon, final Callback cb) {
        final double rlat = Math.round(lat * 100) / 100.0, rlon = Math.round(lon * 100) / 100.0;
        Answer cached = fromCache(freq, pi, rlat, rlon);
        if (!available() || System.currentTimeMillis() < blockedUntil) {
            Answer a = cached != null ? cached : new Answer();
            if (cached == null) a.error = available() ? "Espera un poco (límite de consultas)" : "Sin clave de FMLIST";
            main.post(() -> cb.onAnswer(a));
            return;
        }
        pool.execute(() -> {
            Answer a;
            try {
                String url = BuildConfig.FMLIST_BASE + "alternatives.php?freq="
                        + String.format(Locale.ROOT, "%.1f", freq / 100.0)
                        + "&lat=" + rlat + "&lon=" + rlon
                        + (pi != null && pi.length() == 4 ? "&pi=" + pi : "");
                a = request(url);
                if (a.error == null) { a.lat = rlat; a.lon = rlon; a.time = System.currentTimeMillis(); toCache(freq, pi, a); }
                else if (cached != null) a = cached;
            } catch (Exception e) {
                a = cached != null ? cached : new Answer();
                if (cached == null) a.error = "Sin conexión";
            }
            final Answer res = a;
            main.post(() -> cb.onAnswer(res));
        });
    }

    /** La mejor frecuencia distinta de la actual (la de más señal prevista). */
    public static void findFrequency(int freq, String pi, String ps, double lat, double lon, FreqResult cb) {
        alternatives(freq, pi, lat, lon, a -> {
            int best = 0, bestDb = Integer.MIN_VALUE;
            for (Alt x : a.alts) if (!x.current && x.freq != freq && x.dbuv > bestDb) { bestDb = x.dbuv; best = x.freq; }
            cb.onResult(best);
        });
    }

    /** Envío de registros de recepción: pendiente de la parte 2 de la documentación. */
    public static boolean upload(List<ReceptionLog.Entry> entries) { return false; }

    private static Answer request(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(10000);
        c.setRequestProperty("X-API-Key", BuildConfig.FMLIST_KEY);
        c.setRequestProperty("User-Agent", "AVRadio/" + BuildConfig.VERSION_NAME + " (DanLab)");
        try {
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String body = "";
            if (in != null) {
                ByteArrayOutputStream o = new ByteArrayOutputStream();
                byte[] b = new byte[4096];
                int n;
                while ((n = in.read(b)) > 0) o.write(b, 0, n);
                body = o.toString("UTF-8");
            }
            Answer a = new Answer();
            if (code == 429) {
                int wait = 60;
                try { wait = Integer.parseInt(c.getHeaderField("Retry-After")); } catch (Exception ignored) { }
                blockedUntil = System.currentTimeMillis() + wait * 1000L;
                a.error = "Demasiadas consultas, espera " + wait + " s";
                return a;
            }
            if (code != 200) {
                String msg = "Error " + code;
                try { msg = new JSONObject(body).optString("message", msg); } catch (Exception ignored) { }
                a.error = code == 404 ? "FMLIST no conoce esta emisora aquí" : msg;
                return a;
            }
            parse(new JSONObject(body), a);
            return a;
        } finally { c.disconnect(); }
    }

    private static void parse(JSONObject o, Answer a) throws Exception {
        JSONObject st = o.optJSONObject("station");
        a.station = st != null ? st.optString("name") : "";
        a.matchedBy = o.optString("matched_by");
        a.cacheKm = o.optDouble("cache_radius_km", 10);
        JSONArray arr = o.optJSONArray("alternatives");
        if (arr != null) for (int i = 0; i < arr.length(); i++) {
            JSONObject x = arr.getJSONObject(i);
            Alt t = new Alt();
            t.freq = (int) Math.round(x.optDouble("freq") * 100);
            t.dbuv = x.optInt("dbuv");
            t.program = x.optString("program");
            t.current = x.optBoolean("current");
            a.alts.add(t);
        }
    }

    // ---------- Respuestas guardadas (para cuando no hay cobertura) ----------

    private static SharedPreferences cachePrefs() {
        return app == null ? null : app.getSharedPreferences("avradio_fmlist", Context.MODE_PRIVATE);
    }

    private static String key(int freq, String pi) { return (pi != null && !pi.isEmpty() ? pi : "F" + freq); }

    private static void toCache(int freq, String pi, Answer a) {
        SharedPreferences p = cachePrefs();
        if (p == null) return;
        try {
            JSONArray list = new JSONArray(p.getString(key(freq, pi), "[]"));
            JSONObject o = new JSONObject();
            o.put("la", a.lat); o.put("lo", a.lon); o.put("r", a.cacheKm); o.put("t", a.time);
            o.put("n", a.station); o.put("m", a.matchedBy);
            JSONArray alts = new JSONArray();
            for (Alt x : a.alts) {
                JSONObject j = new JSONObject();
                j.put("f", x.freq); j.put("d", x.dbuv); j.put("p", x.program);
                alts.put(j);
            }
            o.put("a", alts);
            JSONArray out = new JSONArray();
            out.put(o);
            for (int i = 0; i < list.length() && out.length() < 30; i++) out.put(list.get(i));
            p.edit().putString(key(freq, pi), out.toString()).apply();
        } catch (Exception ignored) { }
    }

    private static Answer fromCache(int freq, String pi, double lat, double lon) {
        SharedPreferences p = cachePrefs();
        if (p == null) return null;
        try {
            JSONArray list = new JSONArray(p.getString(key(freq, pi), "[]"));
            for (int i = 0; i < list.length(); i++) {
                JSONObject o = list.getJSONObject(i);
                double km = ReceptionLog.distanceKm(lat, lon, o.getDouble("la"), o.getDouble("lo"));
                if (km > o.optDouble("r", 10)) continue;
                Answer a = new Answer();
                a.lat = o.getDouble("la"); a.lon = o.getDouble("lo"); a.cacheKm = o.optDouble("r", 10);
                a.time = o.optLong("t"); a.station = o.optString("n"); a.matchedBy = o.optString("m") + " (guardado)";
                JSONArray alts = o.getJSONArray("a");
                for (int k = 0; k < alts.length(); k++) {
                    JSONObject j = alts.getJSONObject(k);
                    Alt t = new Alt();
                    t.freq = j.getInt("f"); t.dbuv = j.optInt("d"); t.program = j.optString("p");
                    t.current = t.freq == freq;
                    a.alts.add(t);
                }
                return a;
            }
        } catch (Exception ignored) { }
        return null;
    }
}
