package net.danlab.avradio;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Dial de frecuencias que se desliza con el dedo, con la aguja fija en el centro. */
public class TunerScaleView extends View {

    public interface Listener { void onTune(int freq); }

    private static final int MIN = 8750, MAX = 10800, HALF_WINDOW = 300; // ±3 MHz
    private int freq = 8980;
    private float shown = 8980;
    private final List<Integer> marks = new ArrayList<>();
    private Listener listener;

    private final Paint tick = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint needle = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mark = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float downX, downShown;
    private boolean dragging;

    public TunerScaleView(Context c) {
        super(c);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        label.setTextAlign(Paint.Align.CENTER);
        label.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        mark.setColor(Ui.ACCENT);
    }

    public void setListener(Listener l) { listener = l; }

    public void setFreq(int f) {
        freq = f;
        if (!dragging) { shown = f; invalidate(); }
    }

    public void setMarks(List<Integer> m) {
        marks.clear();
        marks.addAll(m);
        invalidate();
    }

    private float pxPerUnit() { return getWidth() / (2f * HALF_WINDOW); }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), cx = w / 2f;
        float base = h * 0.62f;
        float ppu = pxPerUnit();
        float d = Ui.dp(getContext(), 1);

        int start = (int) (shown - HALF_WINDOW) / 10 * 10;
        int end = (int) (shown + HALF_WINDOW) + 10;
        for (int f = Math.max(MIN, start); f <= Math.min(MAX, end); f += 10) {
            float x = cx + (f - shown) * ppu;
            float dist = Math.abs(x - cx) / cx;           // 0 centro … 1 borde
            int alpha = (int) (255 * Math.max(0f, 1f - dist * dist));
            boolean major = f % 100 == 0;
            boolean half = f % 50 == 0;
            float len = major ? h * 0.30f : half ? h * 0.18f : h * 0.10f;
            tick.setStrokeWidth(major ? 2.5f * d : 1.2f * d);
            tick.setColor(Color.argb(alpha, 200, 210, 230));
            c.drawLine(x, base - len, x, base, tick);
            if (major) {
                label.setTextSize(13 * d);
                label.setColor(Color.argb(alpha, 160, 170, 190));
                c.drawText(String.valueOf(f / 100), x, base + 18 * d, label);
            }
        }
        // Emisoras guardadas como puntitos
        for (int m : marks) {
            float x = cx + (m - shown) * ppu;
            if (x < 0 || x > w) continue;
            float dist = Math.abs(x - cx) / cx;
            mark.setAlpha((int) (255 * Math.max(0f, 1f - dist * dist)));
            c.drawCircle(x, base - h * 0.42f, 3 * d, mark);
        }
        // Aguja
        needle.setShader(new LinearGradient(0, h * 0.05f, 0, base + 4 * d,
                Ui.ACCENT_2, Ui.ACCENT, Shader.TileMode.CLAMP));
        needle.setStrokeWidth(3 * d);
        needle.setShadowLayer(10 * d, 0, 0, Ui.ACCENT);
        c.drawLine(cx, h * 0.05f, cx, base + 4 * d, needle);

        if (dragging) {
            label.setTextSize(15 * d);
            label.setColor(Ui.ACCENT);
            c.drawText(String.format(Locale.ROOT, "%.1f", Math.round(shown / 10f) / 10f), cx, h - 2 * d, label);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getX();
                downShown = shown;
                dragging = true;
                getParent().requestDisallowInterceptTouchEvent(true);
                return true;
            case MotionEvent.ACTION_MOVE:
                shown = Math.max(MIN, Math.min(MAX, downShown - (e.getX() - downX) / pxPerUnit()));
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false;
                int target = Math.round(shown / 10f) * 10;
                if (Math.abs(e.getX() - downX) < Ui.dp(getContext(), 6)) {
                    shown = freq;           // ha sido un toque, no un arrastre
                } else {
                    shown = target;
                    if (listener != null && target != freq) listener.onTune(target);
                }
                invalidate();
                return true;
        }
        return super.onTouchEvent(e);
    }
}
