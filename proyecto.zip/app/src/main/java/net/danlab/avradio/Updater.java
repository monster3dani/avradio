package net.danlab.avradio;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/** Busca en GitHub si hay una versión nueva de AVRadio y la instala. */
public class Updater {

    public interface CheckResult { void onResult(int remoteVersion, String error); }

    private static final String APK = "AVRadio.apk";
    private final Activity act;
    private final Handler main = new Handler(Looper.getMainLooper());
    private long downloadId = -1;
    private BroadcastReceiver receiver;

    public Updater(Activity a) { act = a; }

    public static int localVersion() { return BuildConfig.VERSION_CODE; }

    /** Canal elegido: "estable" (por defecto) o "pruebas". */
    public static boolean testChannel(Context c) {
        return c.getSharedPreferences("avradio", Context.MODE_PRIVATE).getBoolean("testChannel", false);
    }

    private String base() {
        return BuildConfig.UPDATE_BASE + (testChannel(act) ? "avradio-pruebas/" : "avradio/");
    }

    public void check(final CheckResult cb) {
        new Thread(() -> {
            int remote = -1;
            String err = null;
            try {
                HttpURLConnection con = (HttpURLConnection)
                        new URL(base() + "version.txt").openConnection();
                con.setConnectTimeout(8000);
                con.setReadTimeout(8000);
                con.setInstanceFollowRedirects(true);
                int code = con.getResponseCode();
                if (code == 200) {
                    BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    remote = Integer.parseInt(br.readLine().trim());
                    br.close();
                } else {
                    err = "GitHub respondió " + code;
                }
                con.disconnect();
            } catch (Exception e) {
                err = "Sin conexión o sin versión publicada";
            }
            final int r = remote;
            final String e2 = err;
            main.post(() -> cb.onResult(r, e2));
        }).start();
    }

    public void downloadAndInstall() {
        File dir = act.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        if (dir != null) {
            File old = new File(dir, APK);
            if (old.exists()) //noinspection ResultOfMethodCallIgnored
                old.delete();
        }
        final DownloadManager dm = (DownloadManager) act.getSystemService(Context.DOWNLOAD_SERVICE);
        DownloadManager.Request req = new DownloadManager.Request(Uri.parse(base() + APK));
        req.setTitle("AVRadio · actualización");
        req.setMimeType("application/vnd.android.package-archive");
        req.setDestinationInExternalFilesDir(act, Environment.DIRECTORY_DOWNLOADS, APK);
        downloadId = dm.enqueue(req);

        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context ctx, Intent intent) {
                long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
                if (id != downloadId) return;
                try { act.unregisterReceiver(this); } catch (Exception ignored) { }
                Uri uri = dm.getUriForDownloadedFile(id);
                if (uri == null) return;
                Intent install = new Intent(Intent.ACTION_VIEW);
                install.setDataAndType(uri, "application/vnd.android.package-archive");
                install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                act.startActivity(install);
            }
        };
        act.registerReceiver(receiver, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
    }
}
