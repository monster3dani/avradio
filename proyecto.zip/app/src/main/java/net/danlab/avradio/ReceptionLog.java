package net.danlab.avradio;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Registro de recepción: dónde se ha oído bien cada emisora (frecuencia, PI, nombre,
 * posición aproximada y hora). Se guarda solo en la pantalla y sirve para "seguir la emisora".
 * Si el usuario lo permite, más adelante se enviará de forma anónima a FMLIST.
 */
public class ReceptionLog {

    public static class Entry {
        public int freq;
        public String pi = "", ps = "";
        public double lat, lon;
        public long time;
        public boolean sent;
    }

    private static final int MAX = 3000;
    private static ReceptionLog instance;
    private final File file;
    private final List<Entry> list = new ArrayList<>();

    public static synchronized ReceptionLog get(Context c) {
        if (instance == null) instance = new ReceptionLog(c.getApplicationContext());
        return instance;
    }

    private ReceptionLog(Context c) {
        file = new File(c.getFilesDir(), "recepcion.json");
        load();
    }

    public synchronized int size() { return list.size(); }

    public synchronized int pending() {
        int n = 0;
        for (Entry e : list) if (!e.sent) n++;
        return n;
    }

    /** Añade un registro (posición redondeada a ~1 km para no guardar el sitio exacto). */
    public synchronized void add(int freq, String pi, String ps, double lat, double lon) {
        double rlat = Math.round(lat * 100) / 100.0, rlon = Math.round(lon * 100) / 100.0;
        long now = System.currentTimeMillis();
        // No repetir el mismo punto y frecuencia en 10 minutos
        for (int i = list.size() - 1; i >= 0 && i > list.size() - 40; i--) {
            Entry e = list.get(i);
            if (e.freq == freq && e.lat == rlat && e.lon == rlon && now - e.time < 600_000) return;
        }
        Entry e = new Entry();
        e.freq = freq;
        e.pi = pi == null ? "" : pi;
        e.ps = ps == null ? "" : ps;
        e.lat = rlat;
        e.lon = rlon;
        e.time = now;
        list.add(e);
        while (list.size() > MAX) list.remove(0);
        save();
    }

    /**
     * Busca otra frecuencia de la misma emisora oída cerca de aquí.
     * Coincide por PI si lo hay, o por nombre.
     */
    public synchronized Entry findAlternative(int currentFreq, String pi, String ps, double lat, double lon, double maxKm) {
        Entry best = null;
        double bestScore = Double.MAX_VALUE;
        for (Entry e : list) {
            if (e.freq == currentFreq) continue;
            boolean same = (!pi.isEmpty() && pi.equalsIgnoreCase(e.pi))
                    || (pi.isEmpty() && !ps.isEmpty() && ps.equalsIgnoreCase(e.ps));
            if (!same) continue;
            double km = distanceKm(lat, lon, e.lat, e.lon);
            if (km > maxKm) continue;
            double ageDays = (System.currentTimeMillis() - e.time) / 86_400_000.0;
            double score = km + ageDays * 0.5;
            if (score < bestScore) { bestScore = score; best = e; }
        }
        return best;
    }

    static double distanceKm(double la1, double lo1, double la2, double lo2) {
        double r = 6371, dLa = Math.toRadians(la2 - la1), dLo = Math.toRadians(lo2 - lo1);
        double a = Math.sin(dLa / 2) * Math.sin(dLa / 2) + Math.cos(Math.toRadians(la1))
                * Math.cos(Math.toRadians(la2)) * Math.sin(dLo / 2) * Math.sin(dLo / 2);
        return 2 * r * Math.asin(Math.sqrt(a));
    }

    /** Registros pendientes de enviar (para la futura API de FMLIST). */
    public synchronized List<Entry> pendingEntries(int max) {
        List<Entry> out = new ArrayList<>();
        for (Entry e : list) if (!e.sent && out.size() < max) out.add(e);
        return out;
    }

    public synchronized void markSent(List<Entry> sent) {
        for (Entry e : sent) e.sent = true;
        save();
    }

    private void load() {
        try {
            if (!file.exists()) return;
            byte[] d = java.nio.file.Files.readAllBytes(file.toPath());
            JSONArray a = new JSONArray(new String(d, "UTF-8"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Entry e = new Entry();
                e.freq = o.optInt("f");
                e.pi = o.optString("p");
                e.ps = o.optString("n");
                e.lat = o.optDouble("la");
                e.lon = o.optDouble("lo");
                e.time = o.optLong("t");
                e.sent = o.optBoolean("s");
                list.add(e);
            }
        } catch (Exception ignored) { }
    }

    private void save() {
        try {
            JSONArray a = new JSONArray();
            for (Entry e : list) {
                JSONObject o = new JSONObject();
                o.put("f", e.freq);
                o.put("p", e.pi);
                o.put("n", e.ps);
                o.put("la", e.lat);
                o.put("lo", e.lon);
                o.put("t", e.time);
                if (e.sent) o.put("s", true);
                a.put(o);
            }
            try (FileOutputStream out = new FileOutputStream(file)) { out.write(a.toString().getBytes("UTF-8")); }
        } catch (Exception ignored) { }
    }
}
