package net.danlab.avradio;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;
import android.widget.RemoteViews;

import java.util.List;
import java.util.Locale;

/** Dibuja los tres widgets de AVRadio con los colores del tema elegido. */
final class Widgets {
    private Widgets() { }

    private static LogoStore logos;

    private static LogoStore logos(Context c) {
        if (logos == null) { final Context app = c.getApplicationContext(); logos = LogoStore.shared(app, key -> update(app)); }
        return logos;
    }

    /** Actualiza todos los widgets puestos en la pantalla de inicio. */
    static void update(Context c) {
        Context app = c.getApplicationContext();
        Ui.loadTheme(app);
        AppWidgetManager m = AppWidgetManager.getInstance(app);
        int[] h = m.getAppWidgetIds(new ComponentName(app, AvWidget.class));
        int[] v = m.getAppWidgetIds(new ComponentName(app, AvWidgetVertical.class));
        int[] f = m.getAppWidgetIds(new ComponentName(app, AvWidgetFavs.class));
        if (h.length + v.length + f.length == 0) return;

        RadioHub hub = RadioHub.get(app);
        int freq = hub.freq != 0 ? hub.freq : app.getSharedPreferences("avradio", Context.MODE_PRIVATE).getInt("lastFreq", 0);
        boolean on = hub.isPowered();
        String name = hub.displayName();
        String pi = hub.piFor(freq);
        String key = Favorites.keyFor(pi, name);
        Bitmap logo = name.isEmpty() ? null : logos(app).get(key, name);
        String title = !on ? "Radio apagada" : name.isEmpty() ? "AVRadio" : name;
        String sub = !on || freq == 0 ? "" : String.format(Locale.ROOT, "%.1f MHz", freq / 100.0);

        if (h.length > 0) m.updateAppWidget(h, player(app, R.layout.widget, title, sub, name, key, logo, on));
        if (v.length > 0) m.updateAppWidget(v, player(app, R.layout.widget_vertical, title, sub, name, key, logo, on));
        if (f.length > 0) m.updateAppWidget(f, favs(app, freq, pi));
    }

    private static void frame(RemoteViews r) {
        r.setInt(R.id.w_bg, "setColorFilter", Ui.BG_TOP);
        r.setInt(R.id.w_bg, "setImageAlpha", 240);
        r.setInt(R.id.w_border, "setColorFilter", Ui.ACCENT);
        r.setInt(R.id.w_border, "setImageAlpha", 110);
    }

    private static RemoteViews player(Context c, int layout, String title, String sub, String name,
                                      String key, Bitmap logo, boolean on) {
        RemoteViews r = new RemoteViews(c.getPackageName(), layout);
        frame(r);
        r.setTextViewText(R.id.w_name, title);
        r.setTextColor(R.id.w_name, Ui.TEXT);
        r.setTextViewText(R.id.w_freq, sub);
        r.setTextColor(R.id.w_freq, Ui.ACCENT);
        r.setTextColor(R.id.w_by, Ui.TEXT_3);
        r.setImageViewBitmap(R.id.w_logo, card(c, on ? name : "", key, on ? logo : null, 300));
        button(r, R.id.w_prev_bg, R.id.w_prev_ic, icon(0, Ui.TEXT));
        button(r, R.id.w_next_bg, R.id.w_next_ic, icon(1, Ui.TEXT));
        button(r, R.id.w_power_bg, R.id.w_power_ic, icon(2, on ? Ui.TEXT_2 : Ui.ACCENT));
        r.setOnClickPendingIntent(R.id.w_logo, open(c));
        r.setOnClickPendingIntent(R.id.w_name, open(c));
        r.setOnClickPendingIntent(R.id.w_prev, service(c, RadioService.ACTION_PREV, 0, 11));
        r.setOnClickPendingIntent(R.id.w_next, service(c, RadioService.ACTION_NEXT, 0, 12));
        r.setOnClickPendingIntent(R.id.w_power, service(c, RadioService.ACTION_POWER, 0, 13));
        return r;
    }

    private static final int[] FAV = {R.id.fav0, R.id.fav1, R.id.fav2, R.id.fav3, R.id.fav4, R.id.fav5};
    private static final int[] FAV_LOGO = {R.id.fav0_logo, R.id.fav1_logo, R.id.fav2_logo, R.id.fav3_logo, R.id.fav4_logo, R.id.fav5_logo};
    private static final int[] FAV_NAME = {R.id.fav0_name, R.id.fav1_name, R.id.fav2_name, R.id.fav3_name, R.id.fav4_name, R.id.fav5_name};
    private static final int[] FAV_SEL = {R.id.fav0_sel, R.id.fav1_sel, R.id.fav2_sel, R.id.fav3_sel, R.id.fav4_sel, R.id.fav5_sel};

    private static RemoteViews favs(Context c, int freq, String pi) {
        RemoteViews r = new RemoteViews(c.getPackageName(), R.layout.widget_favs);
        frame(r);
        r.setTextColor(R.id.w_title, Ui.TEXT_2);
        r.setOnClickPendingIntent(R.id.w_title, open(c));
        List<Favorites.Station> l = Favorites.get(c).all();
        Favorites.Station cur = Favorites.get(c).find(freq, pi);
        for (int i = 0; i < 6; i++) {
            if (i < l.size()) {
                Favorites.Station s = l.get(i);
                r.setViewVisibility(FAV[i], View.VISIBLE);
                r.setImageViewBitmap(FAV_LOGO[i], card(c, s.name, s.key(), logos(c).get(s.key(), s.name), 200));
                r.setTextViewText(FAV_NAME[i], s.name.isEmpty() ? String.format(Locale.ROOT, "%.1f", s.freq / 100.0) : s.name);
                r.setTextColor(FAV_NAME[i], s == cur ? Ui.ACCENT : Ui.TEXT_2);
                r.setViewVisibility(FAV_SEL[i], s == cur ? View.VISIBLE : View.GONE);
                r.setInt(FAV_SEL[i], "setColorFilter", Ui.ACCENT);
                r.setOnClickPendingIntent(FAV[i], service(c, RadioService.ACTION_TUNE, s.freq, 20 + i));
            } else {
                r.setViewVisibility(FAV[i], View.INVISIBLE);
            }
        }
        return r;
    }

    private static void button(RemoteViews r, int bg, int ic, Bitmap icon) {
        r.setInt(bg, "setColorFilter", Ui.CARD_ON);
        r.setImageViewBitmap(ic, icon);
    }

    private static PendingIntent open(Context c) {
        return PendingIntent.getActivity(c, 10, new Intent(c, MainActivity.class), PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static PendingIntent service(Context c, String action, int freq, int code) {
        Intent i = new Intent(c, RadioService.class).setAction(action);
        if (freq > 0) i.putExtra("freq", freq);
        return PendingIntent.getForegroundService(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /** Tarjeta de la emisora: logo sobre blanco, o iniciales sobre su color (como en la app). */
    static Bitmap card(Context c, String name, String key, Bitmap logo, int size) {
        Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        RectF r = new RectF(0, 0, size, size);
        float rad = size * 0.14f;
        Path clip = new Path();
        clip.addRoundRect(r, rad, rad, Path.Direction.CW);
        cv.clipPath(clip);
        if (logo != null) {
            p.setColor(Color.rgb(244, 246, 250));
            cv.drawRect(r, p);
            float pad = size * 0.1f;
            float k = Math.min((size - 2 * pad) / logo.getWidth(), (size - 2 * pad) / logo.getHeight());
            float dw = logo.getWidth() * k, dh = logo.getHeight() * k;
            cv.drawBitmap(logo, null, new RectF((size - dw) / 2, (size - dh) / 2, (size + dw) / 2, (size + dh) / 2), p);
        } else {
            int col = name == null || name.isEmpty() ? Ui.ACCENT : Ui.stationColor(key == null || key.isEmpty() ? name : key);
            p.setShader(new LinearGradient(0, 0, size, size, col,
                    Color.rgb(Color.red(col) / 3, Color.green(col) / 3, Color.blue(col) / 3), Shader.TileMode.CLAMP));
            cv.drawRect(r, p);
            p.setShader(null);
            String lab = name == null || name.isEmpty() ? "FM" : Ui.initials(name);
            p.setColor(Color.WHITE);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            p.setTextSize(size * (lab.length() > 2 ? 0.3f : 0.38f));
            Paint.FontMetrics fm = p.getFontMetrics();
            cv.drawText(lab, size / 2f, size / 2f - (fm.ascent + fm.descent) / 2f, p);
        }
        return b;
    }

    /** Iconos dibujados: 0 anterior, 1 siguiente, 2 encendido. */
    static Bitmap icon(int type, int color) {
        int s = 96;
        Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color);
        float cx = s / 2f, cy = s / 2f, u = s * 0.18f;
        if (type == 2) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(s * 0.1f);
            p.setStrokeCap(Paint.Cap.ROUND);
            float r = s * 0.3f;
            c.drawArc(new RectF(cx - r, cy - r + 4, cx + r, cy + r + 4), -60, 300, false, p);
            c.drawLine(cx, cy - r - 6, cx, cy, p);
            return b;
        }
        boolean next = type == 1;
        for (int k = 0; k < 2; k++) {
            float x = next ? cx - u * 1.6f + k * u * 1.3f : cx + u * 1.6f - k * u * 1.3f;
            Path t = new Path();
            t.moveTo(x, cy - u * 1.2f);
            t.lineTo(next ? x + u * 1.5f : x - u * 1.5f, cy);
            t.lineTo(x, cy + u * 1.2f);
            t.close();
            c.drawPath(t, p);
        }
        float bx = next ? cx + u * 1.6f : cx - u * 1.6f;
        c.drawRect(bx - u * 0.18f, cy - u * 1.2f, bx + u * 0.18f, cy + u * 1.2f, p);
        return b;
    }
}
