package net.danlab.avradio;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Emisoras favoritas guardadas en la propia app (sin límite y ligadas a su PI). */
public class Favorites {

    public static class Station {
        public int freq;
        public String name = "";
        public String pi = "";
        /** true si el usuario le ha puesto nombre a mano (el RDS no lo cambia) */
        public boolean custom;

        public Station() { }
        public Station(int f, String n, String p) { freq = f; name = n == null ? "" : n; pi = p == null ? "" : p; }

        /** Clave para logos: el PI si lo hay, si no el nombre. */
        public String key() { return keyFor(pi, name); }
    }

    public static String keyFor(String pi, String name) {
        if (pi != null && !pi.isEmpty()) return "PI_" + pi.toUpperCase();
        String n = name == null ? "" : name.toUpperCase().replaceAll("[^A-Z0-9]", "");
        return n.isEmpty() ? "" : "N_" + n;
    }

    private final SharedPreferences prefs;
    private final List<Station> list = new ArrayList<>();

    private static Favorites instance;

    /** Una sola lista compartida por la app, el servicio y el widget. */
    public static synchronized Favorites get(Context c) {
        if (instance == null) instance = new Favorites(c.getApplicationContext());
        return instance;
    }

    private final Context app;

    private Favorites(Context c) {
        app = c;
        prefs = c.getSharedPreferences("avradio", Context.MODE_PRIVATE);
        load();
    }

    /** Copia de seguridad en texto (JSON). */
    public String toJson() {
        return prefs.getString("favs", "[]");
    }

    /** Añade las favoritas de una copia de seguridad. Devuelve cuántas se han añadido. */
    public int importJson(String json) throws Exception {
        JSONArray a = new JSONArray(json);
        int n = 0;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.getJSONObject(i);
            int f = o.optInt("f");
            if (f <= 0) continue;
            if (find(f, o.optString("p")) == null) n++;
            add(f, o.optString("n"), o.optString("p"));
        }
        return n;
    }

    public List<Station> all() { return Collections.unmodifiableList(list); }
    public boolean isEmpty() { return list.isEmpty(); }

    public boolean importedOnce() { return prefs.getBoolean("imported", false); }
    public void setImported() { prefs.edit().putBoolean("imported", true).apply(); }

    /** Busca la favorita que corresponde a lo que suena: primero por PI, luego por frecuencia. */
    public Station find(int freq, String pi) {
        if (pi != null && !pi.isEmpty()) {
            for (Station s : list) if (pi.equalsIgnoreCase(s.pi)) return s;
        }
        for (Station s : list) if (s.freq == freq) return s;
        return null;
    }

    public void add(int freq, String name, String pi) {
        Station s = find(freq, pi);
        if (s == null) { s = new Station(freq, name, pi); list.add(s); }
        else {
            s.freq = freq;
            if (!s.custom && name != null && !name.isEmpty()) s.name = name;
            if (pi != null && !pi.isEmpty()) s.pi = pi;
        }
        save();
    }

    public void remove(Station s) { list.remove(s); save(); }

    /** Si la emisora favorita ha cambiado de frecuencia (otra zona), la actualizamos. */
    public void updateFreqIfMoved(int freq, String pi) {
        if (pi == null || pi.isEmpty()) return;
        for (Station s : list) {
            if (pi.equalsIgnoreCase(s.pi) && s.freq != freq) { s.freq = freq; save(); return; }
        }
    }

    public void sortByFreq() {
        Collections.sort(list, (a, b) -> Integer.compare(a.freq, b.freq));
        save();
    }

    /** Mueve una favorita una posición (dir = -1 izquierda/arriba, +1 derecha/abajo). */
    public void move(Station s, int dir) {
        int i = list.indexOf(s), j = i + dir;
        if (i < 0 || j < 0 || j >= list.size()) return;
        Collections.swap(list, i, j);
        save();
    }

    public void rename(Station s, String name) {
        if (name == null || name.trim().isEmpty()) { s.custom = false; }
        else { s.name = name.trim(); s.custom = true; }
        save();
    }

    private void load() {
        list.clear();
        try {
            JSONArray a = new JSONArray(prefs.getString("favs", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Station st = new Station(o.optInt("f"), o.optString("n"), o.optString("p"));
                st.custom = o.optBoolean("c", false);
                list.add(st);
            }
        } catch (Exception ignored) { }
    }

    private void save() {
        JSONArray a = new JSONArray();
        try {
            for (Station s : list) {
                JSONObject o = new JSONObject();
                o.put("f", s.freq);
                o.put("n", s.name);
                o.put("p", s.pi);
                if (s.custom) o.put("c", true);
                a.put(o);
            }
        } catch (Exception ignored) { }
        prefs.edit().putString("favs", a.toString()).apply();
        try { Widgets.update(app); } catch (Exception ignored) { }
    }
}
