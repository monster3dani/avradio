package net.danlab.avradio;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.text.TextPaint;
import android.view.View;

/** Botón de favorita: el logo ocupa casi todo, para verlo de un vistazo conduciendo. */
public class StationTileView extends View {
    private String name = "", freq = "", key = "";
    private int number;
    private Bitmap logo;
    private boolean active, empty;

    private final Paint face = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bmp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final TextPaint txt = new TextPaint(Paint.ANTI_ALIAS_FLAG);

    public StationTileView(Context c) {
        super(c);
        stroke.setStyle(Paint.Style.STROKE);
        txt.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
    }

    public void set(int number, String name, String freq, String key, Bitmap logo, boolean active) {
        this.number = number;
        this.name = name == null ? "" : name;
        this.freq = freq;
        this.key = key == null ? "" : key;
        this.logo = logo;
        this.active = active;
        this.empty = false;
        invalidate();
    }

    public void setEmpty() { empty = true; logo = null; active = false; invalidate(); }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), d = Ui.dp(getContext(), 1);
        float rad = 16 * d;
        RectF outer = new RectF(d, d, w - d, h - d);

        if (empty) {
            stroke.setStrokeWidth(d);
            stroke.setColor(Ui.LINE);
            stroke.setPathEffect(new android.graphics.DashPathEffect(new float[]{8 * d, 6 * d}, 0));
            c.drawRoundRect(outer, rad, rad, stroke);
            stroke.setPathEffect(null);
            return;
        }

        float labelH = 30 * d;
        RectF logoR = new RectF(outer.left, outer.top, outer.right, outer.bottom - labelH);

        // Fondo de la tarjeta
        face.setShader(null);
        face.setColor(active ? Ui.CARD_ON : Ui.CARD);
        c.drawRoundRect(outer, rad, rad, face);

        // Zona del logo (arriba, grande)
        Path clip = new Path();
        clip.addRoundRect(logoR, new float[]{rad, rad, rad, rad, 0, 0, 0, 0}, Path.Direction.CW);
        c.save();
        c.clipPath(clip);
        if (logo != null) {
            face.setColor(Color.rgb(244, 246, 250));
            c.drawRect(logoR, face);
            float pad = 8 * d;
            float k = Math.min((logoR.width() - 2 * pad) / logo.getWidth(), (logoR.height() - 2 * pad) / logo.getHeight());
            float dw = logo.getWidth() * k, dh = logo.getHeight() * k;
            c.drawBitmap(logo, null, new RectF(logoR.centerX() - dw / 2, logoR.centerY() - dh / 2,
                    logoR.centerX() + dw / 2, logoR.centerY() + dh / 2), bmp);
        } else {
            int col = Ui.stationColor(key.isEmpty() ? name : key);
            face.setShader(new LinearGradient(logoR.left, logoR.top, logoR.right, logoR.bottom,
                    col, Color.rgb(Color.red(col) / 3, Color.green(col) / 3, Color.blue(col) / 3), Shader.TileMode.CLAMP));
            c.drawRect(logoR, face);
            face.setShader(null);
            String lab = Ui.initials(name.isEmpty() ? "FM" : name);
            txt.setColor(Color.WHITE);
            txt.setTextAlign(Paint.Align.CENTER);
            txt.setTextSize(logoR.height() * 0.42f);
            Paint.FontMetrics fm = txt.getFontMetrics();
            c.drawText(lab, logoR.centerX(), logoR.centerY() - (fm.ascent + fm.descent) / 2f, txt);
        }
        c.restore();

        // Número
        txt.setTextAlign(Paint.Align.LEFT);
        txt.setTextSize(13 * d);
        txt.setColor(active ? Ui.ACCENT : Ui.TEXT_2);
        float base = outer.bottom - 10 * d;
        String num = String.valueOf(number);
        c.drawText(num, outer.left + 10 * d, base, txt);
        float x = outer.left + 10 * d + txt.measureText(num) + 6 * d;
        // Frecuencia a la derecha
        txt.setTextAlign(Paint.Align.RIGHT);
        txt.setColor(Ui.TEXT_2);
        txt.setTextSize(12 * d);
        float fw = txt.measureText(freq);
        c.drawText(freq, outer.right - 10 * d, base, txt);
        // Nombre en medio
        txt.setTextAlign(Paint.Align.LEFT);
        txt.setTextSize(13 * d);
        txt.setColor(Ui.TEXT);
        CharSequence n = TextUtils.ellipsize(name, txt, outer.right - 16 * d - fw - x, TextUtils.TruncateAt.END);
        c.drawText(n, 0, n.length(), x, base, txt);

        stroke.setStrokeWidth(active ? 2.5f * d : d);
        stroke.setColor(active ? Ui.ACCENT : Ui.LINE);
        c.drawRoundRect(outer, rad, rad, stroke);
    }
}
