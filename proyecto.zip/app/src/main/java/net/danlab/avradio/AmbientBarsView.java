package net.danlab.avradio;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

import java.util.Random;

/** Barras de fondo que se mueven suavemente, para dar vida a la pantalla. */
public class AmbientBarsView extends View {
    private static final int BARS = 36;
    private final float[] level = new float[BARS], target = new float[BARS];
    private final Random rnd = new Random();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int color = Ui.ACCENT;
    private boolean running = true, enabled = true;
    private long lastTarget;
    private float energy = 1f;

    public AmbientBarsView(Context c) { super(c); }

    public void setColor(int c) { color = c; }
    public void setRunning(boolean r) { running = r; if (r) invalidate(); }
    public void setEnabledBars(boolean e) { enabled = e; invalidate(); }
    /** 0 = calma (sin señal), 1 = normal */
    public void setEnergy(float e) { energy = e; }

    @Override
    protected void onDraw(Canvas c) {
        if (!enabled) return;
        long now = System.currentTimeMillis();
        if (now - lastTarget > 140) {
            lastTarget = now;
            double t = now / 1000.0;
            for (int i = 0; i < BARS; i++) {
                double wave = 0.5 + 0.25 * Math.sin(t * 2.1 + i * 0.45) + 0.15 * Math.sin(t * 3.7 - i * 0.8);
                target[i] = (float) Math.max(0.05, Math.min(1, (wave * 0.6 + rnd.nextFloat() * 0.5) * energy));
            }
        }
        float w = getWidth(), h = getHeight();
        float slot = w / BARS, bw = slot * 0.55f, d = Ui.dp(getContext(), 1);
        for (int i = 0; i < BARS; i++) {
            level[i] += (target[i] - level[i]) * 0.18f;
            // Más altas en el centro, más bajas en los lados
            float edge = 1f - Math.abs(i - (BARS - 1) / 2f) / (BARS / 2f);
            float bh = Math.max(3 * d, h * level[i] * (0.35f + 0.65f * edge));
            float x = i * slot + (slot - bw) / 2;
            paint.setShader(new LinearGradient(0, h - bh, 0, h,
                    Color.argb(70, Color.red(color), Color.green(color), Color.blue(color)),
                    Color.argb(10, Color.red(color), Color.green(color), Color.blue(color)),
                    Shader.TileMode.CLAMP));
            c.drawRoundRect(new RectF(x, h - bh, x + bw, h), bw / 2, bw / 2, paint);
        }
        if (running) postInvalidateOnAnimation();
    }
}
