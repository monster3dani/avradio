package net.danlab.avradio;

import android.app.Application;
import org.lsposed.hiddenapibypass.HiddenApiBypass;

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        Ui.loadTheme(this);
        FmlistApi.init(this);
        try {
            // Permite usar clases internas del sistema (TWUtil de TopWay)
            HiddenApiBypass.addHiddenApiExemptions("L");
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }
}
