package net.danlab.avradio;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Logos de emisoras: los busca en Radio Browser (base de datos pública) la primera vez,
 * los guarda en la pantalla y después funcionan sin internet.
 */
public class LogoStore {

    public interface Listener { void onLogoReady(String key); }

    private static final long RETRY_MS = 6L * 3600 * 1000;      // reintentar a las 6 horas
    /** Servidores de Radio Browser (si uno cae, se prueba el siguiente). */
    private static final String[] SERVERS = {
            "https://de1.api.radio-browser.info", "https://fi1.api.radio-browser.info",
            "https://de2.api.radio-browser.info", "https://nl1.api.radio-browser.info",
            "https://at1.api.radio-browser.info", "https://all.api.radio-browser.info"};
    private static String goodServer;

    /** Nombres RDS abreviados -> nombre real para buscar. */
    private static final Map<String, String> ALIAS = new HashMap<>();
    static {
        String[][] a = {
                {"ONDACERO", "Onda Cero"}, {"RNECLAS", "Radio Clasica"}, {"RNE1", "Radio Nacional"},
                {"RNE3", "Radio 3"}, {"RNE5", "Radio 5"}, {"3CATINFO", "Catalunya Informacio"},
                {"CATINFO", "Catalunya Informacio"}, {"CATRADIO", "Catalunya Radio"},
                {"CATMUSIC", "Catalunya Musica"}, {"LOS40CL", "LOS40 Classic"},
                {"LOS40DC", "LOS40 Dance"}, {"LOS40", "LOS40"}, {"CADENA100", "Cadena 100"},
                {"CADENASER", "Cadena SER"}, {"SER", "Cadena SER"}, {"EUROPAFM", "Europa FM"},
                {"KISSFM", "Kiss FM"}, {"ROCKFM", "Rock FM"}, {"RSTCUGAT", "Radio Sant Cugat"},
                {"SBD", "Radio Sabadell"}, {"SABADELL", "Radio Sabadell"}, {"FLAIXFM", "Flaix FM"},
                {"FLAIXBAC", "Flaixbac"}, {"RAC1", "RAC1"}, {"RAC105", "RAC105"},
                {"MEGASTAR", "MegaStar"}, {"DIAL", "Cadena Dial"}, {"CADENADIAL", "Cadena Dial"},
                {"ICAT", "iCat"}, {"TECNORED", "Tecnored"}, {"MELODIAFM", "Melodia FM"},
                {"HITFM", "Hit FM"}, {"COPE", "COPE"}, {"ESRADIO", "esRadio"}, {"RADIOMARCA", "Radio Marca"},
                {"MARCABCN", "Radio Marca"}, {"LOSTOP", "Los Top"}};
        for (String[] p : a) ALIAS.put(p[0], p[1]);
    }

    private final File dir;
    private final SharedPreferences prefs;
    private final LruCache<String, Bitmap> mem = new LruCache<>(40);
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private final Set<String> busy = new HashSet<>();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final java.util.List<Listener> listeners = new java.util.concurrent.CopyOnWriteArrayList<>();
    private static LogoStore shared;

    /** Un solo buscador para toda la app (pantalla, servicio y widgets). */
    public static synchronized LogoStore shared(Context c, Listener l) {
        if (shared == null) shared = new LogoStore(c.getApplicationContext());
        if (l != null && !shared.listeners.contains(l)) shared.listeners.add(l);
        return shared;
    }

    public void removeListener(Listener l) { listeners.remove(l); }

    private void notifyReady(String key) { for (Listener l : listeners) l.onLogoReady(key); }

    private final Context ctx;

    private void log(String t) { try { RadioHub.get(ctx).log("Logo: " + t); } catch (Exception ignored) { } }

    private LogoStore(Context c) {
        ctx = c.getApplicationContext();
        dir = new File(c.getFilesDir(), "logos");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        prefs = c.getSharedPreferences("avradio_logos", Context.MODE_PRIVATE);
    }

    private File file(String key) { return new File(dir, key + ".png"); }

    /** Devuelve el logo si ya lo tenemos; si no, lo busca en segundo plano. */
    public Bitmap get(String key, String name) {
        if (key == null || key.isEmpty()) return null;
        Bitmap b = mem.get(key);
        if (b != null) return b;
        File f = file(key);
        if (f.exists()) {
            b = BitmapFactory.decodeFile(f.getAbsolutePath());
            if (b != null) { mem.put(key, b); return b; }
        }
        fetch(key, name, false);
        return null;
    }

    public void retry(String key, String name) {
        prefs.edit().remove("fail_" + key).apply();
        fetch(key, name, true);
    }

    /** Logo elegido a mano por el usuario. */
    public void setManual(String key, Bitmap b) {
        if (key == null || key.isEmpty() || b == null) return;
        Bitmap s = scale(b);
        save(key, s);
        mem.put(key, s);
        notifyReady(key);
    }

    private synchronized void fetch(final String key, final String name, boolean force) {
        if (name == null || name.trim().isEmpty() || busy.contains(key)) return;
        long failed = prefs.getLong("fail_" + key, 0);
        if (!force && System.currentTimeMillis() - failed < RETRY_MS) return;
        busy.add(key);
        pool.execute(() -> {
            Bitmap b = null;
            main.post(() -> log("buscando «" + name + "»"));
            try { b = search(name); } catch (Exception e) { final String m = e.toString(); main.post(() -> log("error " + m)); }
            final boolean ok = b != null;
            final String why = lastError;
            main.post(() -> log(ok ? "encontrado para «" + name + "»"
                    : "no encontrado para «" + name + "»" + (why.isEmpty() ? " (la base de datos no lo tiene)" : " (error de red: " + why + ")")));
            final Bitmap res = b;
            synchronized (LogoStore.this) { busy.remove(key); }
            if (res != null) {
                save(key, res);
                main.post(() -> { mem.put(key, res); notifyReady(key); });
            } else {
                prefs.edit().putLong("fail_" + key, System.currentTimeMillis()).apply();
            }
        });
    }

    private Bitmap search(String ps) throws Exception {
        final long deadline = System.currentTimeMillis() + 40_000;   // como mucho 40 s por emisora
        lastError = "";
        String norm = ps.toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]", "");
        List<String> queries = new ArrayList<>();
        if (ALIAS.containsKey(norm)) queries.add(ALIAS.get(norm));
        queries.add(ps.trim());
        String spaced = ps.trim().replaceAll("(?i)([A-Z0-9])FM$", "$1 FM");
        if (!queries.contains(spaced)) queries.add(spaced);
        String firstWord = ps.trim().split("\\s+")[0];
        if (firstWord.length() >= 3 && !queries.contains(firstWord)) queries.add(firstWord);

        List<String> homepages = new ArrayList<>();
        for (String q : queries) {
            for (String country : new String[]{"&countrycode=ES", ""}) {
                if (System.currentTimeMillis() > deadline) break;
                JSONArray arr = query(q, country);
                if (arr == null) continue;
                String target = q.toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]", "");
                // Primero los que coinciden mejor con el nombre
                for (int pass = 0; pass < 2; pass++) {
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject o = arr.getJSONObject(i);
                        String fav = o.optString("favicon", "");
                        String home = o.optString("homepage", "");
                        if (pass == 0 && !home.isEmpty() && homepages.size() < 3) homepages.add(home);
                        if (fav.isEmpty()) continue;
                        String n = o.optString("name", "").toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]", "");
                        boolean good = n.equals(target) || n.startsWith(target);
                        if (pass == 0 && !good) continue;
                        Bitmap b = download(fav);
                        if (b != null) return scale(b);
                    }
                }
            }
        }
        // Plan B: el icono de la web de la emisora
        for (String home : homepages) {
            try {
                String host = new URL(home).getHost();
                if (host == null || host.isEmpty()) continue;
                Bitmap b = download("https://www.google.com/s2/favicons?sz=256&domain=" + host);
                if (b != null && b.getWidth() >= 64) return scale(b);
            } catch (Exception ignored) { }
        }
        return null;
    }

    private JSONArray query(String name, String country) {
        List<String> order = new ArrayList<>();
        if (goodServer != null) order.add(goodServer);
        for (String sv : SERVERS) if (!sv.equals(goodServer)) order.add(sv);
        for (String s : order) {
            try {
                String url = s + "/json/stations/search?limit=15&hidebroken=true&order=clickcount&reverse=true"
                        + country + "&name=" + URLEncoder.encode(name, "UTF-8");
                byte[] data = httpGet(url, 512 * 1024);
                if (data != null) { goodServer = s; return new JSONArray(new String(data, "UTF-8")); }
            } catch (Exception ignored) { }
        }
        return null;
    }

    private Bitmap download(String url) {
        try {
            byte[] d = httpGet(url, 3 * 1024 * 1024);
            if (d == null) return null;
            return BitmapFactory.decodeByteArray(d, 0, d.length);
        } catch (Exception e) {
            return null;
        }
    }

    /** Último error de red, para el registro técnico. */
    private static volatile String lastError = "";

    private static byte[] httpGet(String url, int max) throws Exception {
        try {
            return httpGet1(url, max);
        } catch (javax.net.ssl.SSLException e) {
            lastError = "certificado (" + e.getClass().getSimpleName() + ")";
            if (url.startsWith("https://")) return httpGet1("http://" + url.substring(8), max);
            throw e;
        } catch (Exception e) {
            lastError = e.getClass().getSimpleName();
            throw e;
        }
    }

    private static byte[] httpGet1(String url, int max) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(5000);
        c.setReadTimeout(7000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "AVRadio/" + BuildConfig.VERSION_NAME + " (DanLab)");
        try {
            if (c.getResponseCode() != 200) return null;
            InputStream in = c.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n, total = 0;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > max) return null;
                out.write(buf, 0, n);
            }
            return out.toByteArray();
        } finally {
            c.disconnect();
        }
    }

    private static Bitmap scale(Bitmap b) {
        int max = 256;
        int w = b.getWidth(), h = b.getHeight();
        if (w <= max && h <= max) return b;
        float k = Math.min(max / (float) w, max / (float) h);
        return Bitmap.createScaledBitmap(b, Math.max(1, Math.round(w * k)), Math.max(1, Math.round(h * k)), true);
    }

    private void save(String key, Bitmap b) {
        try (FileOutputStream o = new FileOutputStream(file(key))) {
            b.compress(Bitmap.CompressFormat.PNG, 100, o);
        } catch (Exception ignored) { }
    }
}
