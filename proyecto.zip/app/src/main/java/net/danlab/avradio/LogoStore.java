package net.danlab.avradio;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Logos de emisoras: los busca en Radio Browser (base de datos pública) la primera vez,
 * los guarda en la pantalla y después funcionan sin internet.
 */
public class LogoStore {

    public interface Listener { void onLogoReady(String key); }

    private static final long RETRY_MS = 3L * 24 * 3600 * 1000; // reintentar a los 3 días
    private static final String[] SERVERS = {
            "https://de1.api.radio-browser.info", "https://fi1.api.radio-browser.info"};

    /** Nombres RDS abreviados -> nombre real para buscar. */
    private static final Map<String, String> ALIAS = new HashMap<>();
    static {
        String[][] a = {
                {"ONDACERO", "Onda Cero"}, {"RNECLAS", "Radio Clasica"}, {"RNE1", "Radio Nacional"},
                {"RNE3", "Radio 3"}, {"RNE5", "Radio 5"}, {"3CATINFO", "Catalunya Informacio"},
                {"CATINFO", "Catalunya Informacio"}, {"CATRADIO", "Catalunya Radio"},
                {"CATMUSIC", "Catalunya Musica"}, {"LOS40CL", "LOS40 Classic"},
                {"LOS40DC", "LOS40 Dance"}, {"LOS40", "LOS40"}, {"CADENA100", "Cadena 100"},
                {"CADENASER", "Cadena SER"}, {"SER", "Cadena SER"}, {"EUROPAFM", "Europa FM"},
                {"KISSFM", "Kiss FM"}, {"ROCKFM", "Rock FM"}, {"RSTCUGAT", "Radio Sant Cugat"},
                {"SBD", "Radio Sabadell"}, {"SABADELL", "Radio Sabadell"}, {"FLAIXFM", "Flaix FM"},
                {"FLAIXBAC", "Flaixbac"}, {"RAC1", "RAC1"}, {"RAC105", "RAC105"},
                {"MEGASTAR", "MegaStar"}, {"DIAL", "Cadena Dial"}, {"CADENADIAL", "Cadena Dial"},
                {"ICAT", "iCat"}, {"TECNORED", "Tecnored"}, {"MELODIAFM", "Melodia FM"},
                {"HITFM", "Hit FM"}, {"COPE", "COPE"}, {"ESRADIO", "esRadio"}, {"RADIOMARCA", "Radio Marca"},
                {"MARCABCN", "Radio Marca"}, {"LOSTOP", "Los Top"}};
        for (String[] p : a) ALIAS.put(p[0], p[1]);
    }

    private final File dir;
    private final SharedPreferences prefs;
    private final LruCache<String, Bitmap> mem = new LruCache<>(40);
    private final ExecutorService pool = Executors.newSingleThreadExecutor();
    private final Set<String> busy = new HashSet<>();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Listener listener;

    public LogoStore(Context c, Listener l) {
        dir = new File(c.getFilesDir(), "logos");
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        prefs = c.getSharedPreferences("avradio_logos", Context.MODE_PRIVATE);
        listener = l;
    }

    private File file(String key) { return new File(dir, key + ".png"); }

    /** Devuelve el logo si ya lo tenemos; si no, lo busca en segundo plano. */
    public Bitmap get(String key, String name) {
        if (key == null || key.isEmpty()) return null;
        Bitmap b = mem.get(key);
        if (b != null) return b;
        File f = file(key);
        if (f.exists()) {
            b = BitmapFactory.decodeFile(f.getAbsolutePath());
            if (b != null) { mem.put(key, b); return b; }
        }
        fetch(key, name, false);
        return null;
    }

    public void retry(String key, String name) {
        prefs.edit().remove("fail_" + key).apply();
        fetch(key, name, true);
    }

    /** Logo elegido a mano por el usuario. */
    public void setManual(String key, Bitmap b) {
        if (key == null || key.isEmpty() || b == null) return;
        Bitmap s = scale(b);
        save(key, s);
        mem.put(key, s);
        listener.onLogoReady(key);
    }

    private synchronized void fetch(final String key, final String name, boolean force) {
        if (name == null || name.trim().isEmpty() || busy.contains(key)) return;
        long failed = prefs.getLong("fail_" + key, 0);
        if (!force && System.currentTimeMillis() - failed < RETRY_MS) return;
        busy.add(key);
        pool.execute(() -> {
            Bitmap b = null;
            try { b = search(name); } catch (Exception ignored) { }
            final Bitmap res = b;
            synchronized (LogoStore.this) { busy.remove(key); }
            if (res != null) {
                save(key, res);
                main.post(() -> { mem.put(key, res); listener.onLogoReady(key); });
            } else {
                prefs.edit().putLong("fail_" + key, System.currentTimeMillis()).apply();
            }
        });
    }

    private Bitmap search(String ps) throws Exception {
        String norm = ps.toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]", "");
        List<String> queries = new ArrayList<>();
        if (ALIAS.containsKey(norm)) queries.add(ALIAS.get(norm));
        queries.add(ps.trim());
        String spaced = ps.trim().replaceAll("(?i)([A-Z0-9])FM$", "$1 FM");
        if (!queries.contains(spaced)) queries.add(spaced);
        String firstWord = ps.trim().split("\\s+")[0];
        if (firstWord.length() >= 3 && !queries.contains(firstWord)) queries.add(firstWord);

        for (String q : queries) {
            for (String country : new String[]{"&countrycode=ES", ""}) {
                JSONArray arr = query(q, country);
                if (arr == null) continue;
                String target = q.toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]", "");
                // Primero los que coinciden mejor con el nombre
                for (int pass = 0; pass < 2; pass++) {
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject o = arr.getJSONObject(i);
                        String fav = o.optString("favicon", "");
                        if (fav.isEmpty()) continue;
                        String n = o.optString("name", "").toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]", "");
                        boolean good = n.equals(target) || n.startsWith(target);
                        if (pass == 0 && !good) continue;
                        Bitmap b = download(fav);
                        if (b != null) return scale(b);
                    }
                }
            }
        }
        return null;
    }

    private JSONArray query(String name, String country) {
        for (String s : SERVERS) {
            try {
                String url = s + "/json/stations/search?limit=15&hidebroken=true&order=clickcount&reverse=true"
                        + country + "&name=" + URLEncoder.encode(name, "UTF-8");
                byte[] data = httpGet(url, 512 * 1024);
                if (data != null) return new JSONArray(new String(data, "UTF-8"));
            } catch (Exception ignored) { }
        }
        return null;
    }

    private Bitmap download(String url) {
        try {
            byte[] d = httpGet(url, 3 * 1024 * 1024);
            if (d == null) return null;
            return BitmapFactory.decodeByteArray(d, 0, d.length);
        } catch (Exception e) {
            return null;
        }
    }

    private static byte[] httpGet(String url, int max) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(7000);
        c.setReadTimeout(9000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "AVRadio/" + BuildConfig.VERSION_NAME + " (DanLab)");
        try {
            if (c.getResponseCode() != 200) return null;
            InputStream in = c.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n, total = 0;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > max) return null;
                out.write(buf, 0, n);
            }
            return out.toByteArray();
        } finally {
            c.disconnect();
        }
    }

    private static Bitmap scale(Bitmap b) {
        int max = 256;
        int w = b.getWidth(), h = b.getHeight();
        if (w <= max && h <= max) return b;
        float k = Math.min(max / (float) w, max / (float) h);
        return Bitmap.createScaledBitmap(b, Math.max(1, Math.round(w * k)), Math.max(1, Math.round(h * k)), true);
    }

    private void save(String key, Bitmap b) {
        try (FileOutputStream o = new FileOutputStream(file(key))) {
            b.compress(Bitmap.CompressFormat.PNG, 100, o);
        } catch (Exception ignored) { }
    }
}
