package net.danlab.avradio;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ComposeShader;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.view.MotionEvent;
import android.view.View;

/** Rueda de colores: el ángulo elige el tono y la distancia al centro, la intensidad. */
public class ColorWheelView extends View {
    public interface Listener { void onColor(int color); }

    private final Paint wheel = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mark = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float hue = 200, sat = 0.8f;
    private Listener listener;

    public ColorWheelView(Context c) {
        super(c);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
        mark.setStyle(Paint.Style.STROKE);
    }

    public void setListener(Listener l) { listener = l; }

    public void setColor(int color) {
        float[] hsv = new float[3];
        Color.colorToHSV(color, hsv);
        hue = hsv[0];
        sat = hsv[1];
        invalidate();
    }

    public int getColor() { return Color.HSVToColor(new float[]{hue, sat, 1f}); }

    @Override
    protected void onDraw(Canvas c) {
        float cx = getWidth() / 2f, cy = getHeight() / 2f, r = Math.min(cx, cy) * 0.92f;
        int[] cols = new int[13];
        for (int i = 0; i < 13; i++) cols[i] = Color.HSVToColor(new float[]{(i * 30) % 360, 1f, 1f});
        Shader sweep = new SweepGradient(cx, cy, cols, null);
        Shader rad = new RadialGradient(cx, cy, r, Color.WHITE, 0x00FFFFFF, Shader.TileMode.CLAMP);
        wheel.setShader(new ComposeShader(sweep, rad, PorterDuff.Mode.SRC_OVER));
        c.drawCircle(cx, cy, r, wheel);
        double a = Math.toRadians(hue);
        float mx = cx + (float) Math.cos(a) * r * sat, my = cy + (float) Math.sin(a) * r * sat;
        mark.setStrokeWidth(Ui.dp(getContext(), 3));
        mark.setColor(Color.WHITE);
        c.drawCircle(mx, my, Ui.dp(getContext(), 12), mark);
        mark.setColor(Color.BLACK);
        mark.setStrokeWidth(Ui.dp(getContext(), 1));
        c.drawCircle(mx, my, Ui.dp(getContext(), 14), mark);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float cx = getWidth() / 2f, cy = getHeight() / 2f, r = Math.min(cx, cy) * 0.92f;
        float dx = e.getX() - cx, dy = e.getY() - cy;
        hue = (float) ((Math.toDegrees(Math.atan2(dy, dx)) + 360) % 360);
        sat = Math.min(1f, (float) Math.sqrt(dx * dx + dy * dy) / r);
        getParent().requestDisallowInterceptTouchEvent(true);
        invalidate();
        if (listener != null) listener.onColor(getColor());
        return true;
    }
}
