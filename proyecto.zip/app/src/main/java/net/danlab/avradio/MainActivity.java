package net.danlab.avradio;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TreeMap;

/** AVRadio · Creado por DanLab */
public class MainActivity extends Activity implements LogoStore.Listener {

    private static final int PICK_LOGO = 41;
    private static final String[] PTY = {"", "Noticias", "Actualidad", "Información",
            "Deportes", "Educación", "Teatro", "Cultura", "Ciencia", "Variado",
            "Música pop", "Rock", "Música ligera", "Clásica ligera", "Clásica",
            "Otra música", "Tiempo", "Economía", "Infantil", "Sociedad",
            "Religión", "Llamadas", "Viajes", "Ocio", "Jazz", "Country",
            "Música nacional", "Oldies", "Folk", "Documental", "Prueba alarma", "Alarma"};

    private static class Preset { int freq; String ps = ""; String pi = ""; }

    private final RadioLink radio = new RadioLink();
    private Updater updater;
    private Favorites favs;
    private LogoStore logos;
    private final Handler ui = new Handler(Looper.getMainLooper());

    /** Emisoras que guarda el sintonizador (lista de emisoras disponibles). */
    private final TreeMap<Integer, Preset> mcu = new TreeMap<>();
    private int currentFreq = 0;
    private String currentPs = "";
    private boolean afOn, taOn, stereo, scanning;
    private String pendingLogoKey, pendingLogoName;

    // Vistas
    private CarouselView carousel;
    private TextView tvName, tvFreq, tvPty, tvRt, chipAf, chipTa, chipSt, tvStar, tvTaWarn, updateBanner, tvFavHint;
    private TunerScaleView scale;
    private LinearLayout stationListBox, favDots;
    private final StationTileView[] favTiles = new StationTileView[6];
    private int favPage = 0;
    private AmbientBarsView bars;
    private float swipeX;
    private AlertDialog stationDialog;

    private final StringBuilder log = new StringBuilder();
    private int logLines;

    private final Handler handler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) { onRadioMessage(msg); }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Ui.BG_TOP);
        getWindow().setNavigationBarColor(Ui.BG_BOTTOM);
        updater = new Updater(this);
        favs = new Favorites(this);
        logos = new LogoStore(this, this);
        buildUi();
        String err = radio.open(handler);
        addLog(err == null ? "Conectado con el sintonizador" : "ERROR al conectar: " + err);
        if (err == null) radio.requestRadioSource();
        else tvName.setText("Sin sintonizador");
        refreshAll();
        checkUpdate(false);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (radio.isOpen()) radio.requestRadioSource();
        if (bars != null) bars.setRunning(true);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (bars != null) bars.setRunning(false);
    }

    @Override
    protected void onDestroy() {
        radio.close();
        super.onDestroy();
    }

    @Override
    public void onLogoReady(String key) { refreshAll(); }

    // ===================== Datos del sintonizador =====================

    private void onRadioMessage(Message msg) {
        String obj = msg.obj == null ? "" : String.valueOf(msg.obj);
        addLog(msg.what + " | " + msg.arg1 + " | " + msg.arg2 + (obj.isEmpty() ? "" : " | " + obj));
        switch (msg.what) {
            case RadioLink.MSG_RADIO_INFO:
                if (msg.arg1 == 2) {
                    if (msg.arg2 != currentFreq) {
                        currentFreq = msg.arg2;
                        currentPs = "";
                        tvRt.setText("");
                        tvPty.setVisibility(View.GONE);
                    }
                    scale.setFreq(currentFreq);
                    refreshAll();
                } else if (msg.arg1 == 0) {
                    stereo = (msg.arg2 & 16) == 16;
                    refreshChips();
                }
                break;
            case RadioLink.MSG_RDS: {
                afOn = (msg.arg1 & 64) == 64;
                taOn = (msg.arg1 & 32) == 32;
                int pty = msg.arg2;
                if (pty > 0 && pty < PTY.length) {
                    tvPty.setText(PTY[pty].toUpperCase(Locale.ROOT));
                    tvPty.setVisibility(View.VISIBLE);
                }
                if (msg.obj instanceof String && !((String) msg.obj).trim().isEmpty()) {
                    String ps = ((String) msg.obj).trim();
                    if (!ps.equals(currentPs)) { currentPs = ps; refreshAll(); }
                }
                refreshChips();
                break;
            }
            case RadioLink.MSG_PRESET: {
                int index = msg.arg1 & 0xFF;
                int pi = (msg.arg1 >> 16) & 0xFFFF;
                Preset p = new Preset();
                p.freq = msg.arg2;
                p.ps = msg.obj instanceof String ? ((String) msg.obj).trim() : "";
                p.pi = pi == 0 ? "" : hex(pi);
                mcu.put(index, p);
                ui.removeCallbacks(afterPresets);
                ui.postDelayed(afterPresets, 2500);
                refreshAll();
                break;
            }
            case RadioLink.MSG_RDS_TEXT:
                if (msg.obj instanceof String) {
                    tvRt.setText(((String) msg.obj).trim());
                    tvRt.setSelected(true);
                }
                break;
            case RadioLink.MSG_STEERING:
                if (msg.arg1 == 3) stepFavorite(+1);
                else if (msg.arg1 == 4) stepFavorite(-1);
                break;
        }
    }

    /** Cuando el sintonizador termina de mandar su lista. */
    private final Runnable afterPresets = () -> {
        // La primera vez, importamos sus emisoras como favoritas para no empezar vacío
        if (!favs.importedOnce() && favs.isEmpty()) {
            for (Preset p : mcu.values()) if (p.freq > 0 && !p.ps.isEmpty()) favs.add(p.freq, p.ps, p.pi);
            favs.setImported();
            refreshAll();
        }
        if (scanning) {
            scanning = false;
            Toast.makeText(this, "Búsqueda terminada", Toast.LENGTH_SHORT).show();
        }
        refreshStationList();
    };

    private Preset mcuFor(int freq) {
        for (Preset p : mcu.values()) if (p.freq == freq) return p;
        return null;
    }

    private String currentPi() {
        Preset p = mcuFor(currentFreq);
        if (p != null && !p.pi.isEmpty()) return p.pi;
        Favorites.Station f = favs.find(currentFreq, "");
        return f != null ? f.pi : "";
    }

    private String currentName() {
        if (!currentPs.isEmpty()) return currentPs;
        Favorites.Station f = favs.find(currentFreq, "");
        if (f != null && !f.name.isEmpty()) return f.name;
        Preset p = mcuFor(currentFreq);
        return p != null ? p.ps : "";
    }

    private void stepFavorite(int dir) {
        List<Favorites.Station> l = favs.all();
        if (l.isEmpty()) { if (dir > 0) radio.seekNext(); else radio.seekPrev(); return; }
        Favorites.Station target = null;
        if (dir > 0) { for (Favorites.Station s : l) if (s.freq > currentFreq) { target = s; break; } }
        else { for (int i = l.size() - 1; i >= 0; i--) if (l.get(i).freq < currentFreq) { target = l.get(i); break; } }
        if (target == null) target = dir > 0 ? l.get(0) : l.get(l.size() - 1);
        radio.tune(target.freq);
    }

    // ===================== Refresco de la interfaz =====================

    private void refreshAll() {
        if (tvName == null) return;
        String name = currentName();
        String pi = currentPi();
        Favorites.Station fav = favs.find(currentFreq, pi);
        if (fav != null && !pi.isEmpty()) favs.updateFreqIfMoved(currentFreq, pi);

        tvName.setText(name.isEmpty() ? (currentFreq == 0 ? "AVRadio" : "Buscando RDS…") : name);
        tvName.setTextColor(name.isEmpty() ? Ui.TEXT_3 : Ui.TEXT);
        tvFreq.setText(currentFreq == 0 ? "" : formatFreq(currentFreq) + "  MHz");
        tvStar.setText(fav != null ? "★  En favoritas" : "☆  Guardar en favoritas");
        tvStar.setTextColor(fav != null ? Ui.WARM : Ui.TEXT_2);
        tvStar.setVisibility(currentFreq == 0 ? View.INVISIBLE : View.VISIBLE);

        // Carrusel: favoritas + la actual si no está guardada
        List<CarouselView.Item> items = new ArrayList<>();
        int sel = 0;
        boolean placed = false;
        for (Favorites.Station s : favs.all()) {
            if (!placed && fav == null && currentFreq > 0 && currentFreq < s.freq) {
                sel = items.size();
                items.add(tempItem(name, pi));
                placed = true;
            }
            CarouselView.Item it = new CarouselView.Item();
            it.freq = s.freq;
            it.name = s.name;
            it.key = s.key();
            it.logo = logos.get(it.key, s.name);
            it.favorite = true;
            if (s == fav) sel = items.size();
            items.add(it);
        }
        if (!placed && fav == null && currentFreq > 0) { sel = items.size(); items.add(tempItem(name, pi)); }
        carousel.setItems(items, sel);
        if (bars != null) {
            bars.setColor(name.isEmpty() ? Ui.ACCENT : Ui.stationColor(Favorites.keyFor(pi, name)));
            bars.setEnergy(name.isEmpty() ? 0.25f : stereo ? 1f : 0.55f);
        }

        List<Integer> marks = new ArrayList<>();
        for (Favorites.Station s : favs.all()) marks.add(s.freq);
        scale.setMarks(marks);
        refreshFavStrip(fav);
    }

    private CarouselView.Item tempItem(String name, String pi) {
        CarouselView.Item it = new CarouselView.Item();
        it.freq = currentFreq;
        it.name = name;
        it.key = Favorites.keyFor(pi, name);
        it.logo = name.isEmpty() ? null : logos.get(it.key, name);
        it.favorite = false;
        return it;
    }

    private void refreshChips() {
        chip(chipAf, "AF", afOn, Ui.OK);
        chip(chipTa, "TA", taOn, Ui.WARM);
        chip(chipSt, stereo ? "ESTÉREO" : "MONO", stereo, Ui.OK);
        tvTaWarn.setVisibility(taOn ? View.VISIBLE : View.GONE);
    }

    private void refreshFavStrip(Favorites.Station current) {
        List<Favorites.Station> l = favs.all();
        int pages = Math.max(1, (l.size() + 5) / 6);
        // Si la emisora que suena es favorita, mostrar su página (solo al cambiar de emisora)
        if (current != null && current.freq != lastFavFreq) {
            int idx = l.indexOf(current);
            if (idx >= 0) favPage = idx / 6;
        }
        lastFavFreq = current != null ? current.freq : 0;
        if (favPage >= pages) favPage = pages - 1;
        tvFavHint.setText(l.isEmpty() ? "Pulsa «Guardar en favoritas» para añadir emisoras"
                : "Favoritas · desliza para ver más · mantén pulsada para opciones");
        for (int i = 0; i < 6; i++) {
            int idx = favPage * 6 + i;
            if (idx < l.size()) {
                Favorites.Station s = l.get(idx);
                favTiles[i].set(idx + 1, s.name.isEmpty() ? "—" : s.name, formatFreq(s.freq), s.key(),
                        logos.get(s.key(), s.name), s == current);
                favTiles[i].setTag(s);
            } else {
                favTiles[i].setEmpty();
                favTiles[i].setTag(null);
            }
        }
        favDots.removeAllViews();
        if (pages > 1) {
            for (int p = 0; p < pages; p++) {
                final int pg = p;
                View dot = new View(this);
                dot.setBackground(Ui.rounded(p == favPage ? Ui.ACCENT : Ui.LINE, Ui.dp(this, 4), 0, 0));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        Ui.dp(this, p == favPage ? 22 : 8), Ui.dp(this, 8));
                lp.setMargins(Ui.dp(this, 4), 0, Ui.dp(this, 4), 0);
                dot.setOnClickListener(v -> { favPage = pg; refreshFavStrip(favs.find(currentFreq, currentPi())); });
                favDots.addView(dot, lp);
            }
        }
    }

    private int lastFavFreq = -1;

    private void changeFavPage(int dir) {
        int pages = Math.max(1, (favs.all().size() + 5) / 6);
        int np = Math.max(0, Math.min(pages - 1, favPage + dir));
        if (np != favPage) {
            favPage = np;
            refreshFavStrip(favs.find(currentFreq, currentPi()));
        }
    }

    // ===================== Interfaz =====================

    private void buildUi() {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Ui.BG_TOP, Ui.BG_BOTTOM}));
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 20);
        root.setPadding(pad, Ui.dp(this, 14), pad, Ui.dp(this, 16));
        sv.addView(root);
        frame.addView(sv);

        // --- Barra superior ---
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        TextView title = Ui.text(this, "AVRadio", 22, Ui.TEXT, true);
        title.setLetterSpacing(0.08f);
        LinearLayout byRow = new LinearLayout(this);
        byRow.setGravity(Gravity.CENTER_VERTICAL);
        android.widget.ImageView dl = new android.widget.ImageView(this);
        dl.setImageResource(R.drawable.danlab);
        dl.setAlpha(0.55f);
        byRow.addView(dl, new LinearLayout.LayoutParams(Ui.dp(this, 13), Ui.dp(this, 13)));
        TextView by = Ui.text(this, "  by DanLab", 11, Ui.TEXT_3, false);
        by.setLetterSpacing(0.15f);
        byRow.addView(by);
        brand.addView(title);
        brand.addView(byRow);
        brand.setOnLongClickListener(v -> { showLog(); return true; });
        top.addView(brand, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView list = pill("Emisoras", false);
        list.setOnClickListener(v -> showStationList());
        top.addView(list, chipLp());
        TextView settings = pill("Ajustes", false);
        settings.setOnClickListener(v -> showSettings());
        top.addView(settings);
        root.addView(top);

        updateBanner = pill("Nueva versión disponible · Actualizar", true);
        updateBanner.setVisibility(View.GONE);
        updateBanner.setOnClickListener(v -> startUpdate());
        root.addView(updateBanner, centered(10));

        // --- Carrusel ---
        carousel = new CarouselView(this);
        carousel.setListener(new CarouselView.Listener() {
            @Override public void onPick(CarouselView.Item item) { radio.tune(item.freq); }
            @Override public void onLongPress(CarouselView.Item item) { stationMenu(item.freq, item.name, currentPi()); }
        });
        FrameLayout hero = new FrameLayout(this);
        bars = new AmbientBarsView(this);
        bars.setEnabledBars(getSharedPreferences("avradio", MODE_PRIVATE).getBoolean("bars", true));
        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 170), Gravity.BOTTOM);
        hero.addView(bars, bl);
        hero.addView(carousel, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 250));
        cl.topMargin = Ui.dp(this, 4);
        root.addView(hero, cl);

        tvName = Ui.text(this, "AVRadio", 38, Ui.TEXT, true);
        tvName.setGravity(Gravity.CENTER);
        tvName.setSingleLine(true);
        tvName.setEllipsize(TextUtils.TruncateAt.END);
        root.addView(tvName, centered(0));

        tvFreq = Ui.text(this, "", 20, Ui.ACCENT, false);
        tvFreq.setGravity(Gravity.CENTER);
        tvFreq.setLetterSpacing(0.06f);
        root.addView(tvFreq, centered(6));

        tvPty = Ui.text(this, "", 12, Ui.WARM, true);
        tvPty.setLetterSpacing(0.2f);
        tvPty.setGravity(Gravity.CENTER);
        tvPty.setVisibility(View.GONE);
        root.addView(tvPty, centered(8));

        tvRt = Ui.text(this, "", 15, Ui.TEXT_2, false);
        tvRt.setGravity(Gravity.CENTER);
        tvRt.setSingleLine(true);
        tvRt.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        tvRt.setMarqueeRepeatLimit(-1);
        tvRt.setHorizontalFadingEdgeEnabled(true);
        root.addView(tvRt, centered(8));

        // Estado + guardar
        LinearLayout chips = new LinearLayout(this);
        chips.setGravity(Gravity.CENTER);
        chipAf = pill("AF", false);
        chipTa = pill("TA", false);
        chipSt = pill("ESTÉREO", false);
        chipAf.setOnClickListener(v -> radio.setAf(!afOn));
        chips.addView(chipAf, chipLp());
        chips.addView(chipTa, chipLp());
        chips.addView(chipSt, chipLp());
        tvStar = pill("☆  Guardar en favoritas", false);
        tvStar.setOnClickListener(v -> toggleFavorite());
        chips.addView(tvStar, chipLp());
        root.addView(chips, centered(12));

        tvTaWarn = Ui.text(this, "TA activado: la búsqueda solo se para en emisoras con información de tráfico", 12, Ui.WARM, false);
        tvTaWarn.setGravity(Gravity.CENTER);
        tvTaWarn.setVisibility(View.GONE);
        root.addView(tvTaWarn, centered(8));

        // --- Dial ---
        scale = new TunerScaleView(this);
        scale.setListener(f -> radio.tune(f));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 88));
        slp.topMargin = Ui.dp(this, 10);
        root.addView(scale, slp);

        // --- Controles ---
        LinearLayout ctr = new LinearLayout(this);
        ctr.setGravity(Gravity.CENTER);
        addCtrl(ctr, ControlButton.SEEK_PREV, true, v -> radio.seekPrev());
        addCtrl(ctr, ControlButton.STEP_PREV, false, v -> radio.stepPrev());
        addCtrl(ctr, ControlButton.STEP_NEXT, false, v -> radio.stepNext());
        addCtrl(ctr, ControlButton.SEEK_NEXT, true, v -> radio.seekNext());
        root.addView(ctr, centered(6));

        // --- Favoritas ---
        tvFavHint = Ui.text(this, "", 12, Ui.TEXT_3, false);
        tvFavHint.setLetterSpacing(0.05f);
        root.addView(tvFavHint, centered(18));
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        for (int r = 0; r < 2; r++) {
            LinearLayout row = new LinearLayout(this);
            for (int c = 0; c < 3; c++) {
                final StationTileView t = new StationTileView(this);
                favTiles[r * 3 + c] = t;
                t.setOnClickListener(v -> {
                    Object o = t.getTag();
                    if (o instanceof Favorites.Station) radio.tune(((Favorites.Station) o).freq);
                });
                t.setOnLongClickListener(v -> {
                    Object o = t.getTag();
                    if (!(o instanceof Favorites.Station)) return false;
                    Favorites.Station s = (Favorites.Station) o;
                    stationMenu(s.freq, s.name, s.pi);
                    return true;
                });
                LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, Ui.dp(this, 128), 1f);
                int m = Ui.dp(this, 5);
                tl.setMargins(m, m, m, m);
                row.addView(t, tl);
            }
            grid.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        // Deslizar a izquierda/derecha para cambiar de página
        grid.setOnTouchListener((v, e) -> false);
        FrameLayout gridWrap = new FrameLayout(this) {
            @Override
            public boolean onInterceptTouchEvent(android.view.MotionEvent e) {
                if (e.getActionMasked() == android.view.MotionEvent.ACTION_DOWN) swipeX = e.getX();
                if (e.getActionMasked() == android.view.MotionEvent.ACTION_MOVE
                        && Math.abs(e.getX() - swipeX) > Ui.dp(getContext(), 30)) return true;
                return false;
            }
            @Override
            public boolean onTouchEvent(android.view.MotionEvent e) {
                if (e.getActionMasked() == android.view.MotionEvent.ACTION_UP) {
                    float dx = e.getX() - swipeX;
                    if (Math.abs(dx) > Ui.dp(getContext(), 50)) changeFavPage(dx < 0 ? 1 : -1);
                }
                return true;
            }
        };
        gridWrap.addView(grid);
        LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        gl.topMargin = Ui.dp(this, 6);
        root.addView(gridWrap, gl);
        favDots = new LinearLayout(this);
        favDots.setGravity(Gravity.CENTER);
        root.addView(favDots, centered(8));

        refreshChips();
        setContentView(frame);
    }

    private void toggleFavorite() {
        if (currentFreq == 0) return;
        String pi = currentPi();
        Favorites.Station f = favs.find(currentFreq, pi);
        if (f != null) {
            favs.remove(f);
            Toast.makeText(this, "Quitada de favoritas", Toast.LENGTH_SHORT).show();
        } else {
            favs.add(currentFreq, currentName(), pi);
            Toast.makeText(this, "Guardada en favoritas", Toast.LENGTH_SHORT).show();
        }
        refreshAll();
    }

    /** Menú de una emisora: guardar/quitar, logo… */
    private void stationMenu(final int freq, final String name, final String pi) {
        final Favorites.Station f = favs.find(freq, pi);
        final String key = f != null ? f.key() : Favorites.keyFor(pi, name);
        LinearLayout box = dialogBox((name.isEmpty() ? "Emisora" : name) + "  ·  " + formatFreq(freq), null);
        final AlertDialog d = new AlertDialog.Builder(this).setView(box).create();
        box.addView(settingRow(f != null ? "Quitar de favoritas" : "Guardar en favoritas", () -> {
            if (f != null) favs.remove(f); else favs.add(freq, name, pi);
            d.dismiss();
            refreshAll();
        }));
        box.addView(settingRow("Elegir logo (imagen de la pantalla)", () -> {
            d.dismiss();
            if (key.isEmpty()) { Toast.makeText(this, "Espera a que salga el nombre de la emisora", Toast.LENGTH_LONG).show(); return; }
            pendingLogoKey = key;
            pendingLogoName = name;
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            startActivityForResult(Intent.createChooser(i, "Elige el logo"), PICK_LOGO);
        }));
        box.addView(settingRow("Buscar el logo otra vez en internet", () -> {
            d.dismiss();
            if (!key.isEmpty()) {
                logos.retry(key, name);
                Toast.makeText(this, "Buscando logo…", Toast.LENGTH_SHORT).show();
            }
        }));
        box.addView(settingRow("Sintonizar", () -> { d.dismiss(); radio.tune(freq); }));
        show(d);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != PICK_LOGO || res != RESULT_OK || data == null || data.getData() == null) return;
        try {
            Uri u = data.getData();
            InputStream in = getContentResolver().openInputStream(u);
            Bitmap b = BitmapFactory.decodeStream(in);
            if (in != null) in.close();
            if (b != null) {
                logos.setManual(pendingLogoKey, b);
                Toast.makeText(this, "Logo guardado", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "No se ha podido leer la imagen", Toast.LENGTH_LONG).show();
        }
    }

    // --- Lista de emisoras disponibles ---

    private void showStationList() {
        LinearLayout box = dialogBox("Emisoras disponibles",
                "Las que ha encontrado el sintonizador. Toca para escuchar, ☆ para guardar.");
        stationListBox = new LinearLayout(this);
        stationListBox.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this);
        sv.addView(stationListBox);
        box.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 460)));
        stationDialog = new AlertDialog.Builder(this).setView(box).create();
        box.addView(settingRow("Buscar todas las emisoras de esta zona", () -> {
            new AlertDialog.Builder(this)
                    .setTitle("Buscar emisoras")
                    .setMessage("El sintonizador recorrerá todo el dial (tarda unos segundos). "
                            + "Esto sustituye las presintonías de la radio original, pero tus favoritas de AVRadio no se tocan.")
                    .setPositiveButton("Buscar", (dd, w) -> {
                        scanning = true;
                        mcu.clear();
                        refreshStationList();
                        radio.autoStore();
                        Toast.makeText(this, "Buscando emisoras…", Toast.LENGTH_LONG).show();
                    })
                    .setNegativeButton("Cancelar", null).show();
        }));
        stationDialog.setOnDismissListener(di -> { stationListBox = null; stationDialog = null; });
        refreshStationList();
        show(stationDialog);
    }

    private void refreshStationList() {
        if (stationListBox == null) return;
        stationListBox.removeAllViews();
        TreeMap<Integer, Preset> byFreq = new TreeMap<>();
        for (Preset p : mcu.values()) if (p.freq > 0) byFreq.put(p.freq, p);
        if (byFreq.isEmpty()) {
            TextView t = Ui.text(this, scanning ? "Buscando…" : "Todavía no hay emisoras. Pulsa «Buscar todas las emisoras».", 15, Ui.TEXT_2, false);
            t.setPadding(0, Ui.dp(this, 16), 0, Ui.dp(this, 16));
            stationListBox.addView(t);
            return;
        }
        for (final Preset p : byFreq.values()) {
            final Favorites.Station f = favs.find(p.freq, p.pi);
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8));
            row.setBackground(Ui.rounded(p.freq == currentFreq ? Ui.CARD_ON : Ui.CARD, Ui.dp(this, 14), Ui.LINE, 1));
            LogoView lv = new LogoView(this, false);
            String key = Favorites.keyFor(p.pi, p.ps);
            lv.setStation(p.ps.isEmpty() ? formatFreq(p.freq) : p.ps, key);
            lv.setLogo(p.ps.isEmpty() ? null : logos.get(key, p.ps));
            row.addView(lv, new LinearLayout.LayoutParams(Ui.dp(this, 42), Ui.dp(this, 42)));
            LinearLayout txt = new LinearLayout(this);
            txt.setOrientation(LinearLayout.VERTICAL);
            txt.setPadding(Ui.dp(this, 12), 0, 0, 0);
            txt.addView(Ui.text(this, p.ps.isEmpty() ? "Sin nombre" : p.ps, 17, Ui.TEXT, true));
            txt.addView(Ui.text(this, formatFreq(p.freq) + " MHz" + (p.pi.isEmpty() ? "" : "   ·   PI " + p.pi), 12, Ui.TEXT_2, false));
            row.addView(txt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView star = Ui.text(this, f != null ? "★" : "☆", 26, f != null ? Ui.WARM : Ui.TEXT_2, false);
            star.setPadding(Ui.dp(this, 14), Ui.dp(this, 4), Ui.dp(this, 6), Ui.dp(this, 4));
            star.setOnClickListener(v -> {
                if (f != null) favs.remove(f); else favs.add(p.freq, p.ps, p.pi);
                refreshAll();
                refreshStationList();
            });
            row.addView(star);
            row.setOnClickListener(v -> radio.tune(p.freq));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = Ui.dp(this, 6);
            stationListBox.addView(row, lp);
        }
    }

    // --- Ajustes ---

    private void showSettings() {
        LinearLayout box = dialogBox("AVRadio", "Versión " + BuildConfig.VERSION_NAME + "  ·  Creado por DanLab");
        final AlertDialog d = new AlertDialog.Builder(this).setView(box).create();
        box.addView(settingRow("Buscar actualización", () -> { d.dismiss(); checkUpdate(true); }));
        box.addView(settingRow(afOn ? "Desactivar AF (frecuencias alternativas)" : "Activar AF (frecuencias alternativas)",
                () -> { radio.setAf(!afOn); d.dismiss(); }));
        box.addView(settingRow(taOn ? "Desactivar TA (avisos de tráfico)" : "Activar TA (avisos de tráfico)", () -> {
            d.dismiss();
            if (taOn) { radio.setTa(false); return; }
            new AlertDialog.Builder(this).setTitle("Avisos de tráfico (TA)")
                    .setMessage("Con TA activado, la búsqueda solo se detiene en emisoras que emiten información de tráfico y se salta las demás.")
                    .setPositiveButton("Activar", (dd, w) -> radio.setTa(true))
                    .setNegativeButton("Cancelar", null).show();
        }));
        final android.content.SharedPreferences sp = getSharedPreferences("avradio", MODE_PRIVATE);
        final boolean barsOn = sp.getBoolean("bars", true);
        box.addView(settingRow(barsOn ? "Quitar barras animadas de fondo" : "Poner barras animadas de fondo", () -> {
            sp.edit().putBoolean("bars", !barsOn).apply();
            bars.setEnabledBars(!barsOn);
            if (!barsOn) bars.setRunning(true);
            d.dismiss();
        }));
        box.addView(settingRow("Volver a pedir datos al sintonizador", () -> { radio.requestAll(); d.dismiss(); }));
        box.addView(settingRow("Ver registro técnico", () -> { d.dismiss(); showLog(); }));
        show(d);
    }

    private LinearLayout dialogBox(String title, String sub) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 20);
        box.setPadding(p, p, p, p);
        box.setBackground(Ui.rounded(Ui.CARD, Ui.dp(this, 20), Ui.LINE, 1));
        box.addView(Ui.text(this, title, 22, Ui.TEXT, true));
        if (sub != null) {
            TextView v = Ui.text(this, sub, 13, Ui.TEXT_2, false);
            v.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 10));
            box.addView(v);
        }
        return box;
    }

    private void show(AlertDialog d) {
        d.show();
        if (d.getWindow() != null) d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
    }

    private TextView settingRow(String s, Runnable r) {
        TextView t = Ui.text(this, s, 16, Ui.TEXT, false);
        t.setPadding(Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14));
        t.setBackground(Ui.rounded(Ui.CARD_ON, Ui.dp(this, 14), Ui.LINE, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 8);
        t.setLayoutParams(lp);
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private void addCtrl(LinearLayout parent, int type, boolean big, View.OnClickListener l) {
        ControlButton b = new ControlButton(this, type, big);
        b.setOnClickListener(l);
        int s = Ui.dp(this, big ? 80 : 64);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(s, s);
        p.setMargins(Ui.dp(this, 10), 0, Ui.dp(this, 10), 0);
        p.gravity = Gravity.CENTER_VERTICAL;
        parent.addView(b, p);
    }

    private LinearLayout.LayoutParams centered(int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = Ui.dp(this, topDp);
        p.gravity = Gravity.CENTER_HORIZONTAL;
        return p;
    }

    private LinearLayout.LayoutParams chipLp() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(Ui.dp(this, 5), 0, Ui.dp(this, 5), 0);
        return p;
    }

    private TextView pill(String s, boolean accent) {
        TextView t = Ui.text(this, s, 13, accent ? Color.WHITE : Ui.TEXT_2, true);
        t.setLetterSpacing(0.06f);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Ui.dp(this, 14), Ui.dp(this, 8), Ui.dp(this, 14), Ui.dp(this, 8));
        if (accent) {
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{Ui.ACCENT_2, Ui.ACCENT});
            g.setCornerRadius(Ui.dp(this, 18));
            t.setBackground(g);
        } else {
            t.setBackground(Ui.rounded(Ui.CARD, Ui.dp(this, 18), Ui.LINE, Ui.dp(this, 1)));
        }
        return t;
    }

    private void chip(TextView t, String s, boolean on, int onColor) {
        t.setText(s);
        t.setTextColor(on ? onColor : Ui.TEXT_3);
        t.setBackground(Ui.rounded(Ui.CARD, Ui.dp(this, 18),
                on ? Color.argb(140, Color.red(onColor), Color.green(onColor), Color.blue(onColor)) : Ui.LINE,
                Ui.dp(this, 1)));
    }

    // --- Actualización y registro ---

    private void checkUpdate(final boolean manual) {
        if (manual) Toast.makeText(this, "Buscando actualización…", Toast.LENGTH_SHORT).show();
        updater.check((remote, error) -> {
            if (remote > Updater.localVersion()) {
                updateBanner.setVisibility(View.VISIBLE);
                if (manual) startUpdate();
            } else if (manual) {
                Toast.makeText(this, error != null ? error : "Ya tienes la última versión", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void startUpdate() {
        Toast.makeText(this, "Descargando actualización…", Toast.LENGTH_LONG).show();
        updater.downloadAndInstall();
    }

    private void showLog() {
        ScrollView sv = new ScrollView(this);
        TextView t = Ui.text(this, log.toString(), 12, Ui.TEXT_2, false);
        t.setTypeface(Typeface.MONOSPACE);
        int p = Ui.dp(this, 16);
        t.setPadding(p, p, p, p);
        sv.addView(t);
        new AlertDialog.Builder(this).setTitle("Registro técnico").setView(sv)
                .setPositiveButton("Cerrar", null).show();
    }

    private void addLog(String line) {
        String t = new SimpleDateFormat("HH:mm:ss", Locale.ROOT).format(new Date());
        log.insert(0, t + "  " + line + "\n");
        if (++logLines > 300) {
            int cut = log.lastIndexOf("\n", log.length() - 2);
            if (cut > 0) log.setLength(cut + 1);
            logLines--;
        }
    }

    private static String hex(int pi) { return String.format(Locale.ROOT, "%04X", pi); }

    private static String formatFreq(int f) { return String.format(Locale.ROOT, "%.1f", f / 100.0); }
}
