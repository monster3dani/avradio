package net.danlab.avradio;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TreeMap;
import java.util.TreeSet;

/** AVRadio · Creado por DanLab */
public class MainActivity extends Activity {

    private static final String[] PTY = {"", "Noticias", "Actualidad", "Información",
            "Deportes", "Educación", "Teatro", "Cultura", "Ciencia", "Variado",
            "Música pop", "Rock", "Música ligera", "Clásica ligera", "Clásica",
            "Otra música", "Tiempo", "Economía", "Infantil", "Sociedad",
            "Religión", "Llamadas", "Viajes", "Ocio", "Jazz", "Country",
            "Música nacional", "Oldies", "Folk", "Documental", "Prueba alarma", "Alarma"};

    private static class Preset { int freq; String ps = ""; String pi = ""; }

    private final RadioLink radio = new RadioLink();
    private Updater updater;
    private final TreeMap<Integer, Preset> presets = new TreeMap<>();
    private int currentFreq = 0, bank = 0;
    private String currentPs = "", currentPi = "";
    private boolean afOn, taOn, stereo;

    // Vistas
    private LogoView heroLogo;
    private TextView tvName, tvFreq, tvPty, tvRt, chipAf, chipTa, chipSt, updateBanner;
    private TunerScaleView scale;
    private final TextView[] bankTabs = new TextView[3];
    private final LinearLayout[] tiles = new LinearLayout[6];
    private final LogoView[] tileLogos = new LogoView[6];
    private final TextView[] tileNames = new TextView[6], tileFreqs = new TextView[6];

    // Registro para depurar (pulsación larga en el título)
    private final StringBuilder log = new StringBuilder();
    private int logLines;

    private final Handler handler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) { onRadioMessage(msg); }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Ui.BG_TOP);
        getWindow().setNavigationBarColor(Ui.BG_BOTTOM);
        updater = new Updater(this);
        buildUi();
        String err = radio.open(handler);
        addLog(err == null ? "Conectado con el sintonizador" : "ERROR al conectar: " + err);
        if (err == null) radio.requestRadioSource();
        else tvName.setText("Sin sintonizador");
        checkUpdate(false);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (radio.isOpen()) radio.requestRadioSource();
    }

    @Override
    protected void onDestroy() {
        radio.close();
        super.onDestroy();
    }

    // ===================== Datos del sintonizador =====================

    private void onRadioMessage(Message msg) {
        String obj = msg.obj == null ? "" : String.valueOf(msg.obj);
        addLog(msg.what + " | " + msg.arg1 + " | " + msg.arg2 + (obj.isEmpty() ? "" : " | " + obj));
        switch (msg.what) {
            case RadioLink.MSG_RADIO_INFO:
                if (msg.arg1 == 2) {
                    if (msg.arg2 != currentFreq) {
                        currentFreq = msg.arg2;
                        currentPs = "";
                        tvRt.setText("");
                        tvPty.setVisibility(View.GONE);
                    }
                    scale.setFreq(currentFreq);
                    refreshStation();
                } else if (msg.arg1 == 0) {
                    stereo = (msg.arg2 & 16) == 16;
                    refreshChips();
                }
                break;
            case RadioLink.MSG_RDS: {
                afOn = (msg.arg1 & 64) == 64;
                taOn = (msg.arg1 & 32) == 32;
                int pty = msg.arg2;
                if (pty > 0 && pty < PTY.length) {
                    tvPty.setText(PTY[pty].toUpperCase(Locale.ROOT));
                    tvPty.setVisibility(View.VISIBLE);
                }
                if (msg.obj instanceof String && !((String) msg.obj).trim().isEmpty()) {
                    currentPs = ((String) msg.obj).trim();
                }
                int pi = (msg.arg1 >> 16) & 0xFFFF;
                if (pi != 0) currentPi = hex(pi);
                refreshChips();
                refreshStation();
                break;
            }
            case RadioLink.MSG_PRESET: {
                int index = msg.arg1 & 0xFF;
                int pi = (msg.arg1 >> 16) & 0xFFFF;
                Preset p = new Preset();
                p.freq = msg.arg2;
                p.ps = msg.obj instanceof String ? ((String) msg.obj).trim() : "";
                p.pi = pi == 0 ? "" : hex(pi);
                presets.put(index, p);
                refreshTiles();
                refreshStation();
                break;
            }
            case RadioLink.MSG_RDS_TEXT:
                if (msg.obj instanceof String) {
                    tvRt.setText(((String) msg.obj).trim());
                    tvRt.setSelected(true);
                }
                break;
            case RadioLink.MSG_STEERING:
                if (msg.arg1 == 3) stepPreset(+1);
                else if (msg.arg1 == 4) stepPreset(-1);
                break;
        }
    }

    /** Botones del volante: pasa a la emisora guardada siguiente/anterior. */
    private void stepPreset(int dir) {
        TreeSet<Integer> set = new TreeSet<>();
        for (Preset p : presets.values()) if (p.freq > 0) set.add(p.freq);
        if (set.isEmpty()) { if (dir > 0) radio.seekNext(); else radio.seekPrev(); return; }
        Integer f = dir > 0 ? set.higher(currentFreq) : set.lower(currentFreq);
        if (f == null) f = dir > 0 ? set.first() : set.last();
        radio.tune(f);
    }

    private Preset presetFor(int freq) {
        for (Preset p : presets.values()) if (p.freq == freq) return p;
        return null;
    }

    private void refreshStation() {
        Preset p = presetFor(currentFreq);
        String name = !currentPs.isEmpty() ? currentPs : (p != null && !p.ps.isEmpty() ? p.ps : "");
        String pi = p != null && !p.pi.isEmpty() ? p.pi : currentPi;
        tvName.setText(name.isEmpty() ? "Buscando RDS…" : name);
        tvName.setTextColor(name.isEmpty() ? Ui.TEXT_3 : Ui.TEXT);
        tvFreq.setText(currentFreq == 0 ? "" : formatFreq(currentFreq) + "  MHz");
        heroLogo.setStation(name.isEmpty() ? "FM" : name, pi);
        refreshTiles();
    }

    private void refreshChips() {
        chip(chipAf, "AF", afOn);
        chip(chipTa, "TA", taOn);
        chip(chipSt, stereo ? "ESTÉREO" : "MONO", stereo);
    }

    private void refreshTiles() {
        List<Integer> marks = new ArrayList<>();
        for (Preset p : presets.values()) if (p.freq > 0) marks.add(p.freq);
        scale.setMarks(marks);
        for (int i = 0; i < 3; i++) {
            boolean on = i == bank;
            bankTabs[i].setTextColor(on ? Color.WHITE : Ui.TEXT_3);
            bankTabs[i].setBackground(on ? Ui.rounded(Ui.CARD_ON, Ui.dp(this, 18), Ui.ACCENT, Ui.dp(this, 1)) : null);
        }
        for (int i = 0; i < 6; i++) {
            Preset p = presets.get(bank * 6 + i);
            boolean has = p != null && p.freq > 0;
            boolean active = has && p.freq == currentFreq;
            tileNames[i].setText(has ? (p.ps.isEmpty() ? "—" : p.ps) : "Vacío");
            tileFreqs[i].setText(has ? formatFreq(p.freq) : "");
            tileLogos[i].setStation(has && !p.ps.isEmpty() ? p.ps : String.valueOf(i + 1), has ? p.pi : "");
            tiles[i].setBackground(Ui.rounded(active ? Ui.CARD_ON : Ui.CARD, Ui.dp(this, 18),
                    active ? Ui.ACCENT : Ui.LINE, Ui.dp(this, active ? 2 : 1)));
            tiles[i].setAlpha(has ? 1f : 0.45f);
        }
    }

    // ===================== Interfaz =====================

    private void buildUi() {
        FrameLayout frame = new FrameLayout(this);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Ui.BG_TOP, Ui.BG_BOTTOM});
        frame.setBackground(bg);

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 22);
        root.setPadding(pad, Ui.dp(this, 14), pad, Ui.dp(this, 18));
        sv.addView(root);
        frame.addView(sv);

        // --- Barra superior ---
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        TextView title = Ui.text(this, "AVRadio", 22, Ui.TEXT, true);
        title.setLetterSpacing(0.08f);
        TextView by = Ui.text(this, "by DanLab", 11, Ui.TEXT_3, false);
        by.setLetterSpacing(0.15f);
        brand.addView(title);
        brand.addView(by);
        brand.setOnLongClickListener(v -> { showLog(); return true; });
        top.addView(brand, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView settings = pill("Ajustes", false);
        settings.setOnClickListener(v -> showSettings());
        top.addView(settings);
        root.addView(top);

        updateBanner = pill("Nueva versión disponible · Actualizar", true);
        updateBanner.setVisibility(View.GONE);
        updateBanner.setOnClickListener(v -> startUpdate());
        LinearLayout.LayoutParams ub = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ub.topMargin = Ui.dp(this, 10);
        root.addView(updateBanner, ub);

        // --- Emisora actual ---
        heroLogo = new LogoView(this, true);
        heroLogo.setStation("FM", "");
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(this, 190), Ui.dp(this, 190));
        lp.gravity = Gravity.CENTER_HORIZONTAL;
        lp.topMargin = Ui.dp(this, 8);
        root.addView(heroLogo, lp);

        tvName = Ui.text(this, "AVRadio", 40, Ui.TEXT, true);
        tvName.setGravity(Gravity.CENTER);
        tvName.setSingleLine(true);
        tvName.setEllipsize(TextUtils.TruncateAt.END);
        root.addView(tvName, centered(4));

        tvFreq = Ui.text(this, "", 22, Ui.ACCENT, false);
        tvFreq.setGravity(Gravity.CENTER);
        tvFreq.setLetterSpacing(0.06f);
        root.addView(tvFreq, centered(8));

        tvPty = Ui.text(this, "", 12, Ui.WARM, true);
        tvPty.setLetterSpacing(0.2f);
        tvPty.setGravity(Gravity.CENTER);
        tvPty.setVisibility(View.GONE);
        root.addView(tvPty, centered(8));

        tvRt = Ui.text(this, "", 15, Ui.TEXT_2, false);
        tvRt.setGravity(Gravity.CENTER);
        tvRt.setSingleLine(true);
        tvRt.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        tvRt.setMarqueeRepeatLimit(-1);
        tvRt.setHorizontalFadingEdgeEnabled(true);
        root.addView(tvRt, centered(10));

        LinearLayout chips = new LinearLayout(this);
        chips.setGravity(Gravity.CENTER);
        chipAf = pill("AF", false);
        chipTa = pill("TA", false);
        chipSt = pill("ESTÉREO", false);
        chipAf.setOnClickListener(v -> radio.setAf(!afOn));
        chipTa.setOnClickListener(v -> radio.setTa(!taOn));
        chips.addView(chipAf, chipLp());
        chips.addView(chipTa, chipLp());
        chips.addView(chipSt, chipLp());
        root.addView(chips, centered(14));
        refreshChips();

        // --- Dial ---
        scale = new TunerScaleView(this);
        scale.setListener(f -> radio.tune(f));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 96));
        slp.topMargin = Ui.dp(this, 14);
        root.addView(scale, slp);

        // --- Controles ---
        LinearLayout ctr = new LinearLayout(this);
        ctr.setGravity(Gravity.CENTER);
        addCtrl(ctr, ControlButton.SEEK_PREV, true, v -> radio.seekPrev());
        addCtrl(ctr, ControlButton.STEP_PREV, false, v -> radio.stepPrev());
        addCtrl(ctr, ControlButton.STEP_NEXT, false, v -> radio.stepNext());
        addCtrl(ctr, ControlButton.SEEK_NEXT, true, v -> radio.seekNext());
        root.addView(ctr, centered(10));

        // --- Bancos FM1 / FM2 / FM3 ---
        LinearLayout tabs = new LinearLayout(this);
        tabs.setGravity(Gravity.CENTER);
        tabs.setBackground(Ui.rounded(Ui.CARD, Ui.dp(this, 20), Ui.LINE, Ui.dp(this, 1)));
        tabs.setPadding(Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4));
        for (int i = 0; i < 3; i++) {
            final int b = i;
            TextView t = Ui.text(this, "FM" + (i + 1), 15, Ui.TEXT_3, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(Ui.dp(this, 26), Ui.dp(this, 8), Ui.dp(this, 26), Ui.dp(this, 8));
            t.setOnClickListener(v -> { bank = b; refreshTiles(); });
            bankTabs[i] = t;
            tabs.addView(t);
        }
        root.addView(tabs, centered(18));

        // --- Presintonías (3 x 2) ---
        for (int r = 0; r < 2; r++) {
            LinearLayout row = new LinearLayout(this);
            for (int c = 0; c < 3; c++) {
                final int i = r * 3 + c;
                LinearLayout tile = new LinearLayout(this);
                tile.setOrientation(LinearLayout.VERTICAL);
                tile.setGravity(Gravity.CENTER);
                tile.setPadding(Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 12));
                LogoView lv = new LogoView(this, false);
                tile.addView(lv, new LinearLayout.LayoutParams(Ui.dp(this, 46), Ui.dp(this, 46)));
                TextView n = Ui.text(this, "", 15, Ui.TEXT, true);
                n.setSingleLine(true);
                n.setEllipsize(TextUtils.TruncateAt.END);
                n.setGravity(Gravity.CENTER);
                n.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 2));
                TextView f = Ui.text(this, "", 13, Ui.TEXT_2, false);
                f.setGravity(Gravity.CENTER);
                tile.addView(n, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                tile.addView(f);
                tile.setOnClickListener(v -> {
                    Preset p = presets.get(bank * 6 + i);
                    if (p != null && p.freq > 0) radio.tune(p.freq);
                });
                LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                int m = Ui.dp(this, 5);
                tl.setMargins(m, m, m, m);
                row.addView(tile, tl);
                tiles[i] = tile;
                tileLogos[i] = lv;
                tileNames[i] = n;
                tileFreqs[i] = f;
            }
            root.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        refreshTiles();
        setContentView(frame);
    }

    private void addCtrl(LinearLayout parent, int type, boolean big, View.OnClickListener l) {
        ControlButton b = new ControlButton(this, type, big);
        b.setOnClickListener(l);
        int s = Ui.dp(this, big ? 84 : 68);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(s, s);
        p.setMargins(Ui.dp(this, 10), 0, Ui.dp(this, 10), 0);
        p.gravity = Gravity.CENTER_VERTICAL;
        parent.addView(b, p);
    }

    private LinearLayout.LayoutParams centered(int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = Ui.dp(this, topDp);
        p.gravity = Gravity.CENTER_HORIZONTAL;
        return p;
    }

    private LinearLayout.LayoutParams chipLp() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(Ui.dp(this, 6), 0, Ui.dp(this, 6), 0);
        return p;
    }

    private TextView pill(String s, boolean accent) {
        TextView t = Ui.text(this, s, 13, accent ? Color.WHITE : Ui.TEXT_2, true);
        t.setLetterSpacing(0.08f);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Ui.dp(this, 16), Ui.dp(this, 8), Ui.dp(this, 16), Ui.dp(this, 8));
        if (accent) {
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{Ui.ACCENT_2, Ui.ACCENT});
            g.setCornerRadius(Ui.dp(this, 18));
            t.setBackground(g);
        } else {
            t.setBackground(Ui.rounded(Ui.CARD, Ui.dp(this, 18), Ui.LINE, Ui.dp(this, 1)));
        }
        return t;
    }

    private void chip(TextView t, String s, boolean on) {
        t.setText(s);
        t.setTextColor(on ? Ui.OK : Ui.TEXT_3);
        t.setBackground(Ui.rounded(Ui.CARD, Ui.dp(this, 18),
                on ? Color.argb(140, 80, 220, 150) : Ui.LINE, Ui.dp(this, 1)));
    }

    // ===================== Ajustes, actualización y registro =====================

    private void showSettings() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 20);
        box.setPadding(p, p, p, p);
        box.setBackground(Ui.rounded(Ui.CARD, Ui.dp(this, 20), Ui.LINE, 1));

        TextView h = Ui.text(this, "AVRadio", 24, Ui.TEXT, true);
        TextView v = Ui.text(this, "Versión " + BuildConfig.VERSION_NAME + "  ·  Creado por DanLab", 13, Ui.TEXT_2, false);
        v.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 16));
        box.addView(h);
        box.addView(v);

        final AlertDialog d = new AlertDialog.Builder(this).setView(box).create();
        box.addView(settingRow("Buscar actualización", () -> { d.dismiss(); checkUpdate(true); }));
        box.addView(settingRow(afOn ? "Desactivar AF (frecuencias alternativas)" : "Activar AF (frecuencias alternativas)",
                () -> { radio.setAf(!afOn); d.dismiss(); }));
        box.addView(settingRow(taOn ? "Desactivar TA (avisos de tráfico)" : "Activar TA (avisos de tráfico)",
                () -> { radio.setTa(!taOn); d.dismiss(); }));
        box.addView(settingRow("Volver a pedir datos al sintonizador", () -> { radio.requestAll(); d.dismiss(); }));
        box.addView(settingRow("Ver registro técnico", () -> { d.dismiss(); showLog(); }));
        d.show();
        if (d.getWindow() != null) d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
    }

    private TextView settingRow(String s, Runnable r) {
        TextView t = Ui.text(this, s, 16, Ui.TEXT, false);
        t.setPadding(Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14));
        t.setBackground(Ui.rounded(Ui.CARD_ON, Ui.dp(this, 14), Ui.LINE, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 8);
        t.setLayoutParams(lp);
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private void checkUpdate(final boolean manual) {
        if (manual) Toast.makeText(this, "Buscando actualización…", Toast.LENGTH_SHORT).show();
        updater.check((remote, error) -> {
            if (remote > Updater.localVersion()) {
                updateBanner.setVisibility(View.VISIBLE);
                if (manual) startUpdate();
            } else if (manual) {
                Toast.makeText(this, error != null ? error : "Ya tienes la última versión",
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    private void startUpdate() {
        Toast.makeText(this, "Descargando actualización…", Toast.LENGTH_LONG).show();
        updater.downloadAndInstall();
    }

    private void showLog() {
        ScrollView sv = new ScrollView(this);
        TextView t = Ui.text(this, log.toString(), 12, Ui.TEXT_2, false);
        t.setTypeface(Typeface.MONOSPACE);
        int p = Ui.dp(this, 16);
        t.setPadding(p, p, p, p);
        sv.addView(t);
        new AlertDialog.Builder(this).setTitle("Registro técnico").setView(sv)
                .setPositiveButton("Cerrar", null).show();
    }

    private void addLog(String line) {
        String t = new SimpleDateFormat("HH:mm:ss", Locale.ROOT).format(new Date());
        log.insert(0, t + "  " + line + "\n");
        if (++logLines > 300) {
            int cut = log.lastIndexOf("\n", log.length() - 2);
            if (cut > 0) log.setLength(cut + 1);
            logLines--;
        }
    }

    private static String hex(int pi) { return String.format(Locale.ROOT, "%04X", pi); }

    private static String formatFreq(int f) { return String.format(Locale.ROOT, "%.1f", f / 100.0); }
}
