package net.danlab.avradio;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TreeMap;

/** AVRadio · Creado por DanLab */
public class MainActivity extends Activity implements LogoStore.Listener {

    private static final int PICK_LOGO = 41;
    private static final String[] PTY = {"", "Noticias", "Actualidad", "Información",
            "Deportes", "Educación", "Teatro", "Cultura", "Ciencia", "Variado",
            "Música pop", "Rock", "Música ligera", "Clásica ligera", "Clásica",
            "Otra música", "Tiempo", "Economía", "Infantil", "Sociedad",
            "Religión", "Llamadas", "Viajes", "Ocio", "Jazz", "Country",
            "Música nacional", "Oldies", "Folk", "Documental", "Prueba alarma", "Alarma"};

    private static class Preset { int freq; String ps = ""; String pi = ""; }

    /** true mientras AVRadio está en pantalla (para no mostrar el aviso emergente encima). */
    public static boolean visible;
    private static final int EXPORT_FAVS = 42, IMPORT_FAVS = 43;
    private RadioHub hub;
    private RadioLink radio;
    private CoverArt covers;
    private android.widget.ImageView ivCover;
    private View offOverlay;
    private final Runnable onPower = this::refreshPower;
    private Updater updater;
    private Favorites favs;
    private LogoStore logos;
    private final Handler ui = new Handler(Looper.getMainLooper());

    /** Emisoras que guarda el sintonizador (lista de emisoras disponibles). */
    private final TreeMap<Integer, Preset> mcu = new TreeMap<>();
    private int currentFreq = 0;
    private String currentPs = "";
    private boolean afOn, taOn, stereo, scanning;
    /** Emisoras encontradas en la última búsqueda (no se borran mientras busca). */
    private final TreeMap<Integer, Preset> found = new TreeMap<>();
    private int scanFreq, scanReturnFreq;
    private long scanStarted;
    private TextView scanStatus;
    private android.widget.ProgressBar scanBar;
    private TextView scanButton;
    private ScrollView stationScroll;
    private String pendingLogoKey, pendingLogoName;

    // Vistas
    private CarouselView carousel;
    private TextView tvName, tvFreq, tvPty, tvRt, chipAf, chipTa, chipSt, tvStar, tvStarLabel, updateBanner, tvFavHint;
    private TunerScaleView scale;
    private LinearLayout stationListBox, favDots;
    private FavPager favPager;
    private final List<StationTileView> favTiles = new ArrayList<>();
    private static final int PER_PAGE = 8;
    private AmbientBarsView bars;
    private android.content.SharedPreferences prefs;
    private boolean restoredLast;
    private AlertDialog stationDialog;

    private final StringBuilder log = new StringBuilder();
    private int logLines;

    private final Handler handler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) { onRadioMessage(msg); }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Ui.BG_TOP);
        getWindow().setNavigationBarColor(Ui.BG_BOTTOM);
        updater = new Updater(this);
        prefs = getSharedPreferences("avradio", MODE_PRIVATE);
        favs = Favorites.get(this);
        covers = new CoverArt();
        logos = new LogoStore(this, this);
        buildUi();
        RadioService.start(this);
        hub = RadioHub.get(this);
        String err = hub.start();
        radio = hub.link();
        hub.addListener(handler);
        hub.addPowerListener(onPower);
        addLog(err == null ? "Conectado con el sintonizador" : "ERROR al conectar: " + err);
        if (err == null) {
            hub.powerOn();
            radio.requestAll();
        } else tvName.setText("Sin sintonizador");
        refreshAll();
        checkUpdate(false);
        // Primera vez: si no hay emisoras, ofrecer buscarlas (esperamos a que llegue la lista del sintonizador)
        if (err == null && !prefs.getBoolean("welcomed", false)) ui.postDelayed(this::maybeWelcome, 4500);
    }

    private void maybeWelcome() {
        if (isFinishing() || prefs.getBoolean("welcomed", false)) return;
        prefs.edit().putBoolean("welcomed", true).apply();
        favs.setImported();                       // nunca importar nada sin preguntar
        if (!favs.isEmpty()) return;
        LinearLayout box = dialogBox("Bienvenido a AVRadio",
                "Creado por DanLab\n\nTodavía no tienes emisoras. ¿Cómo quieres empezar?");
        final AlertDialog d = new AlertDialog.Builder(this).setView(box).setCancelable(true).create();
        box.addView(settingRow("Buscar las emisoras de mi zona", () -> {
            d.dismiss();
            showStationList();
            startScan();
        }));
        boolean hasPresets = false;
        for (Preset p : mcu.values()) if (p.freq > 0 && !p.ps.isEmpty()) hasPresets = true;
        if (hasPresets) box.addView(settingRow("Copiar las presintonías de la radio original", () -> {
            d.dismiss();
            for (Preset p : mcu.values()) if (p.freq > 0 && !p.ps.isEmpty()) favs.add(p.freq, p.ps, p.pi);
            favs.sortByFreq();
            refreshAll();
        }));
        box.addView(settingRow("Empezar sin emisoras", d::dismiss));
        show(d);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (radio != null && radio.isOpen()) hub.powerOn();
        if (bars != null) bars.setRunning(true);
        visible = true;
    }

    @Override
    protected void onPause() {
        super.onPause();
        visible = false;
        if (bars != null) bars.setRunning(false);
    }

    @Override
    protected void onDestroy() {
        if (hub != null) { hub.removeListener(handler); hub.removePowerListener(onPower); }
        super.onDestroy();
    }

    @Override
    public void onLogoReady(String key) { refreshAll(); }

    // ===================== Datos del sintonizador =====================

    private void onRadioMessage(Message msg) {
        if (msg.what == 99999) { addLog(String.valueOf(msg.obj)); return; }
        String obj = msg.obj == null ? "" : String.valueOf(msg.obj);
        addLog(msg.what + " | " + msg.arg1 + " | " + msg.arg2 + (obj.isEmpty() ? "" : " | " + obj));
        switch (msg.what) {
            case RadioLink.MSG_RADIO_INFO:
                if (msg.arg1 == 2) {
                    if (scanning) { scanFreq = msg.arg2; kickScanWatch(); updateScanProgress(); }
                    if (msg.arg2 != currentFreq) {
                        currentFreq = msg.arg2;
                        currentPs = "";
                        tvRt.setText("");
                        ivCover.setVisibility(View.GONE);
                        tvPty.setVisibility(View.INVISIBLE);
                    }
                    scale.setFreq(currentFreq);
                    refreshAll();
                } else if (msg.arg1 == 0) {
                    stereo = (msg.arg2 & 16) == 16;
                    refreshChips();
                }
                break;
            case RadioLink.MSG_RDS: {
                afOn = (msg.arg1 & 64) == 64;
                taOn = (msg.arg1 & 32) == 32;
                int pty = msg.arg2;
                if (pty > 0 && pty < PTY.length) {
                    tvPty.setText(PTY[pty].toUpperCase(Locale.ROOT));
                    tvPty.setVisibility(View.VISIBLE);
                }
                // Nombre ya filtrado por el hub (sin letras cambiadas)
                if (!hub.ps.isEmpty() && !hub.ps.equals(currentPs)) { currentPs = hub.ps; refreshAll(); }
                refreshChips();
                break;
            }
            case RadioLink.MSG_PRESET: {
                int index = msg.arg1 & 0xFF;
                int pi = (msg.arg1 >> 16) & 0xFFFF;
                Preset p = new Preset();
                p.freq = msg.arg2;
                p.ps = msg.obj instanceof String ? ((String) msg.obj).trim() : "";
                p.pi = pi == 0 ? "" : hex(pi);
                mcu.put(index, p);
                if (scanning && p.freq > 0) {
                    // Lo encontrado se queda en la lista aunque el sintonizador reutilice el hueco
                    Preset old0 = found.get(p.freq);
                    if (old0 == null || (old0.ps.isEmpty() && !p.ps.isEmpty()) || (old0.pi.isEmpty() && !p.pi.isEmpty())) found.put(p.freq, p);
                    kickScanWatch();
                }
                ui.removeCallbacks(afterPresets);
                ui.postDelayed(afterPresets, 2500);
                refreshAll();
                break;
            }
            case RadioLink.MSG_RDS_TEXT:
                if (msg.obj instanceof String) {
                    final String rt = ((String) msg.obj).trim();
                    if (!rt.equals(tvRt.getText().toString())) {
                        tvRt.setText(rt);
                        tvRt.setSelected(true);
                        if (prefs.getBoolean("covers", true)) covers.find(rt, (forText, cover) -> {
                            if (!forText.equals(tvRt.getText().toString())) return;
                            if (cover != null) { ivCover.setImageBitmap(cover); ivCover.setVisibility(View.VISIBLE); }
                            else ivCover.setVisibility(View.GONE);
                        });
                    }
                }
                break;
        }
    }

    /** Cuando el sintonizador termina de mandar su lista. */
    private final Runnable afterPresets = () -> refreshStationList();

    private Preset mcuFor(int freq) {
        for (Preset p : mcu.values()) if (p.freq == freq) return p;
        return null;
    }

    private String currentPi() {
        Preset p = mcuFor(currentFreq);
        if (p != null && !p.pi.isEmpty()) return p.pi;
        Favorites.Station f = favs.find(currentFreq, "");
        return f != null ? f.pi : "";
    }

    private String currentName() {
        Favorites.Station cf = favs.find(currentFreq, currentPi());
        if (cf != null && cf.custom) return cf.name;
        if (!currentPs.isEmpty()) return currentPs;
        Favorites.Station f = favs.find(currentFreq, "");
        if (f != null && !f.name.isEmpty()) return f.name;
        Preset p = mcuFor(currentFreq);
        return p != null ? p.ps : "";
    }

    private void stepFavorite(int dir) {
        List<Favorites.Station> l = favs.all();
        if (l.isEmpty()) { if (dir > 0) radio.seekNext(); else radio.seekPrev(); return; }
        Favorites.Station target = null;
        if (dir > 0) { for (Favorites.Station s : l) if (s.freq > currentFreq) { target = s; break; } }
        else { for (int i = l.size() - 1; i >= 0; i--) if (l.get(i).freq < currentFreq) { target = l.get(i); break; } }
        if (target == null) target = dir > 0 ? l.get(0) : l.get(l.size() - 1);
        radio.tune(target.freq);
    }

    // ===================== Refresco de la interfaz =====================

    private void refreshAll() {
        if (tvName == null) return;
        String name = currentName();
        String pi = currentPi();
        Favorites.Station fav = favs.find(currentFreq, pi);
        if (fav != null && !pi.isEmpty()) favs.updateFreqIfMoved(currentFreq, pi);
        // Favorita guardada "sin nombre": en cuanto la emisora manda su nombre, lo guardamos (y así se busca su logo)
        if (fav != null && !fav.custom && fav.name.isEmpty() && !currentPs.isEmpty()) favs.add(currentFreq, currentPs, pi);
        // Lo mismo en la lista de emisoras encontradas
        Preset fp = found.get(currentFreq);
        if (fp != null && fp.ps.isEmpty() && !currentPs.isEmpty()) { fp.ps = currentPs; refreshStationList(); }

        tvName.setText(name.isEmpty() ? (currentFreq == 0 ? "AVRadio" : "Buscando RDS…") : name);
        tvName.setTextColor(name.isEmpty() ? Ui.TEXT_3 : Ui.TEXT);
        tvFreq.setText(currentFreq == 0 ? "" : formatFreq(currentFreq) + "  MHz");
        tvStar.setText(fav != null ? "★" : "☆");
        tvStar.setTextColor(fav != null ? Ui.WARM : Ui.TEXT_2);
        tvStarLabel.setText(fav != null ? "Favorita" : "Guardar");
        tvStarLabel.setTextColor(fav != null ? Ui.WARM : Ui.TEXT_3);

        // Carrusel: favoritas + la actual si no está guardada
        List<CarouselView.Item> items = new ArrayList<>();
        int sel = 0;
        for (Favorites.Station s : favs.all()) {
            CarouselView.Item it = new CarouselView.Item();
            it.freq = s.freq;
            it.name = s.name;
            it.key = s.key();
            it.logo = logos.get(it.key, s.name);
            it.favorite = true;
            if (s == fav) sel = items.size();
            items.add(it);
        }
        if (fav == null && currentFreq > 0) { sel = items.size(); items.add(tempItem(name, pi)); }
        carousel.setItems(items, sel);
        if (bars != null) {
            bars.setColor(name.isEmpty() ? Ui.ACCENT : Ui.stationColor(Favorites.keyFor(pi, name)));
            bars.setEnergy(name.isEmpty() ? 0.25f : stereo ? 1f : 0.55f);
        }

        List<Integer> marks = new ArrayList<>();
        for (Favorites.Station s : favs.all()) marks.add(s.freq);
        scale.setMarks(marks);
        refreshFavStrip(fav);
    }

    private CarouselView.Item tempItem(String name, String pi) {
        CarouselView.Item it = new CarouselView.Item();
        it.freq = currentFreq;
        it.name = name;
        it.key = Favorites.keyFor(pi, name);
        it.logo = name.isEmpty() ? null : logos.get(it.key, name);
        it.favorite = false;
        return it;
    }

    private void refreshChips() {
        chip(chipAf, "AF", afOn, Ui.OK);
        chip(chipTa, "TA", taOn, Ui.WARM);
        chip(chipSt, stereo ? "ESTÉREO" : "MONO", stereo, Ui.OK);
    }

    private int lastFavFreq = -1;

    private void refreshFavStrip(Favorites.Station current) {
        if (favColumn != null) { refreshFavColumn(current); return; }
        if (favPager == null) return;
        List<Favorites.Station> l = favs.all();
        int pages = Math.max(1, (l.size() + PER_PAGE - 1) / PER_PAGE);
        if (favPager.getChildCount() != pages) buildFavPages(pages);
        tvFavHint.setText(l.isEmpty() ? "Toca la estrella para guardar la emisora que suena"
                : "Favoritas · desliza para ver más · mantén pulsada para opciones");
        for (int i = 0; i < favTiles.size(); i++) {
            StationTileView t = favTiles.get(i);
            if (i < l.size()) {
                Favorites.Station s = l.get(i);
                t.set(i + 1, s.name.isEmpty() ? "—" : s.name, formatFreq(s.freq), s.key(),
                        logos.get(s.key(), s.name), s == current);
                t.setTag(s);
            } else {
                t.setEmpty();
                t.setTag(null);
            }
        }
        // Al cambiar de emisora, ir a la página donde está
        if (current != null && current.freq != lastFavFreq) {
            int idx = l.indexOf(current);
            if (idx >= 0 && idx / PER_PAGE != favPager.getPage()) favPager.setPage(idx / PER_PAGE, true);
        }
        lastFavFreq = current != null ? current.freq : 0;
        refreshDots();
    }

    private void buildFavPages(int pages) {
        favPager.removeAllViews();
        favTiles.clear();
        for (int p = 0; p < pages; p++) {
            LinearLayout page = new LinearLayout(this);
            page.setOrientation(LinearLayout.VERTICAL);
            for (int r = 0; r < 2; r++) {
                LinearLayout row = new LinearLayout(this);
                for (int c = 0; c < 4; c++) {
                    final StationTileView t = new StationTileView(this);
                    favTiles.add(t);
                    t.setOnClickListener(v -> {
                        Object o = t.getTag();
                        if (o instanceof Favorites.Station) radio.tune(((Favorites.Station) o).freq);
                    });
                    t.setOnLongClickListener(v -> {
                        Object o = t.getTag();
                        if (!(o instanceof Favorites.Station)) return false;
                        Favorites.Station s = (Favorites.Station) o;
                        stationMenu(s.freq, s.name, s.pi);
                        return true;
                    });
                    LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, Ui.dp(this, 124), 1f);
                    int m = Ui.dp(this, 4);
                    tl.setMargins(m, m, m, m);
                    row.addView(t, tl);
                }
                page.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            }
            favPager.addView(page);
        }
        if (favPager.getPage() >= pages) favPager.setPage(pages - 1, false);
    }

    private void refreshDots() {
        if (favDots == null || favPager == null) return;
        favDots.removeAllViews();
        int pages = favPager.pages();
        if (pages <= 1) return;
        for (int p = 0; p < pages; p++) {
            final int pg = p;
            boolean on = p == favPager.getPage();
            View dot = new View(this);
            dot.setBackground(Ui.rounded(on ? Ui.ACCENT : Ui.LINE, Ui.dp(this, 4), 0, 0));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(this, on ? 22 : 8), Ui.dp(this, 8));
            lp.setMargins(Ui.dp(this, 4), 0, Ui.dp(this, 4), 0);
            dot.setOnClickListener(v -> favPager.setPage(pg, true));
            favDots.addView(dot, lp);
        }
    }

    // ===================== Interfaz =====================

    private void buildUi() {
        FrameLayout frame = new FrameLayout(this);
        frame.addView(new BackgroundView(this), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        frame.addView(root, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        int pad = Ui.dp(this, 18);
        root.setPadding(pad, Ui.dp(this, 12), pad, Ui.dp(this, 12));

        // --- Barra superior ---
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        TextView title = Ui.text(this, "AVRadio", 22, Ui.TEXT, true);
        title.setLetterSpacing(0.08f);
        LinearLayout byRow = new LinearLayout(this);
        byRow.setGravity(Gravity.CENTER_VERTICAL);
        android.widget.ImageView dl = new android.widget.ImageView(this);
        dl.setImageResource(R.drawable.danlab);
        dl.setAlpha(0.55f);
        byRow.addView(dl, new LinearLayout.LayoutParams(Ui.dp(this, 13), Ui.dp(this, 13)));
        TextView by = Ui.text(this, "  by DanLab", 11, Ui.TEXT_3, false);
        by.setLetterSpacing(0.15f);
        byRow.addView(by);
        brand.addView(title);
        brand.addView(byRow);
        brand.setOnLongClickListener(v -> { if (!isAdmin()) return false; showLog(); return true; });
        top.addView(brand, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView list = pill("Emisoras", false);
        list.setOnClickListener(v -> showStationList());
        top.addView(list, chipLp());
        TextView settings = pill("Ajustes", false);
        settings.setOnClickListener(v -> showSettings());
        top.addView(settings, chipLp());
        FrameLayout power = new FrameLayout(this);
        power.setBackground(Ui.rounded(Ui.CARD, Ui.dp(this, 18), Ui.LINE, Ui.dp(this, 1)));
        power.addView(new PowerIcon(this, Ui.TEXT_2), new FrameLayout.LayoutParams(Ui.dp(this, 34), Ui.dp(this, 34), Gravity.CENTER));
        power.setOnClickListener(v -> hub.powerOff());
        top.addView(power, new LinearLayout.LayoutParams(Ui.dp(this, 52), Ui.dp(this, 36)));
        root.addView(top);

        updateBanner = pill("Nueva versión disponible · Actualizar", true);
        updateBanner.setVisibility(View.GONE);
        updateBanner.setOnClickListener(v -> startUpdate());
        root.addView(updateBanner, centered(8));

        createCommonViews();
        if (layoutId() == LAYOUT_COLUMN) buildColumnLayout(root); else buildClassicLayout(root);

        LinearLayout off = new LinearLayout(this);
        off.setOrientation(LinearLayout.VERTICAL);
        off.setGravity(Gravity.CENTER);
        off.setBackgroundColor(Color.argb(225, Color.red(Ui.BG_BOTTOM), Color.green(Ui.BG_BOTTOM), Color.blue(Ui.BG_BOTTOM)));
        PowerIcon pw = new PowerIcon(this, Ui.ACCENT);
        TextView pt = Ui.text(this, "Radio apagada", 30, Ui.TEXT, true);
        pt.setGravity(Gravity.CENTER);
        pt.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 6));
        TextView ps2 = Ui.text(this, "Toca para encender", 16, Ui.TEXT_2, false);
        ps2.setGravity(Gravity.CENTER);
        off.addView(pw, new LinearLayout.LayoutParams(Ui.dp(this, 120), Ui.dp(this, 120)));
        off.addView(pt);
        off.addView(ps2);
        TextView exit = pill("Salir de AVRadio", false);
        exit.setOnClickListener(v -> finishAndRemoveTask());
        LinearLayout.LayoutParams el = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        el.topMargin = Ui.dp(this, 36);
        off.addView(exit, el);
        off.setClickable(true);
        off.setOnClickListener(v -> hub.powerOn());
        off.setVisibility(View.GONE);
        offOverlay = off;
        frame.addView(off, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        refreshChips();
        setContentView(frame);
    }

    private void renameDialog(final Favorites.Station st) {
        final android.widget.EditText ed = new android.widget.EditText(this);
        ed.setText(st.name);
        ed.setSingleLine(true);
        ed.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this).setTitle("Nombre de la emisora")
                .setMessage("Déjalo vacío para volver a usar el nombre que manda la emisora.")
                .setView(ed)
                .setPositiveButton("Guardar", (dd, w) -> { favs.rename(st, ed.getText().toString()); refreshAll(); })
                .setNegativeButton("Cancelar", null).show();
    }

    private LinearLayout orderList;

    /** Ordenar, renombrar y quitar favoritas. */
    private void showOrder() {
        LinearLayout box = dialogBox("Tus favoritas", "Usa las flechas para cambiar el orden. El orden también es el de los botones del volante.");
        orderList = new LinearLayout(this);
        orderList.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this);
        sv.addView(orderList);
        box.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 470)));
        final AlertDialog d = new AlertDialog.Builder(this).setView(box).create();
        box.addView(settingRow("Ordenar por frecuencia", () -> { favs.sortByFreq(); fillOrder(); refreshAll(); }));
        box.addView(settingRow("Hecho", d::dismiss));
        fillOrder();
        show(d);
    }

    private void fillOrder() {
        orderList.removeAllViews();
        List<Favorites.Station> l = favs.all();
        for (int i = 0; i < l.size(); i++) {
            final Favorites.Station st = l.get(i);
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.dp(this, 10), Ui.dp(this, 6), Ui.dp(this, 6), Ui.dp(this, 6));
            row.setBackground(Ui.rounded(Ui.CARD_ON, Ui.dp(this, 14), Ui.LINE, 1));
            row.addView(Ui.text(this, String.valueOf(i + 1), 15, Ui.TEXT_2, true),
                    new LinearLayout.LayoutParams(Ui.dp(this, 28), ViewGroup.LayoutParams.WRAP_CONTENT));
            LogoView lv = new LogoView(this, false);
            lv.setStation(st.name.isEmpty() ? "FM" : st.name, st.key());
            lv.setLogo(logos.get(st.key(), st.name));
            row.addView(lv, new LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 40)));
            LinearLayout tx = new LinearLayout(this);
            tx.setOrientation(LinearLayout.VERTICAL);
            tx.setPadding(Ui.dp(this, 10), 0, 0, 0);
            tx.addView(Ui.text(this, st.name.isEmpty() ? "—" : st.name, 16, Ui.TEXT, true));
            tx.addView(Ui.text(this, formatFreq(st.freq) + " MHz", 12, Ui.TEXT_2, false));
            row.addView(tx, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(iconBtn("▲", v -> { favs.move(st, -1); fillOrder(); refreshAll(); }));
            row.addView(iconBtn("▼", v -> { favs.move(st, +1); fillOrder(); refreshAll(); }));
            row.addView(iconBtn("✎", v -> renameDialog(st)));
            row.addView(iconBtn("✕", v -> {
                new AlertDialog.Builder(this).setMessage("¿Quitar " + (st.name.isEmpty() ? "esta emisora" : st.name) + " de favoritas?")
                        .setPositiveButton("Quitar", (dd, w) -> { favs.remove(st); fillOrder(); refreshAll(); })
                        .setNegativeButton("Cancelar", null).show();
            }));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = Ui.dp(this, 6);
            orderList.addView(row, lp);
        }
    }

    private TextView iconBtn(String s, View.OnClickListener l) {
        TextView t = Ui.text(this, s, 20, Ui.TEXT, false);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Ui.rounded(Ui.CARD, Ui.dp(this, 12), Ui.LINE, 1));
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(this, 46), Ui.dp(this, 46));
        lp.leftMargin = Ui.dp(this, 6);
        t.setLayoutParams(lp);
        return t;
    }

    private static final int REQ_LOCATION = 51;

    /** Seguir emisora por zona: ubicación, activar y consentimiento para compartir. */
    private void showFollowSettings() {
        LinearLayout box = dialogBox("Seguir la emisora por zona",
                "Cuando una emisora favorita pierde la señal en un viaje, AVRadio busca otra frecuencia de la misma emisora "
                        + "cerca de donde estás. Aprende de los sitios por donde ya has pasado y, pronto, también con los datos de FMLIST.");
        final AlertDialog d = new AlertDialog.Builder(this).setView(box).create();
        if (!FollowManager.hasLocationPermission(this)) {
            box.addView(settingRow("⚠  Permitir ubicación (necesaria para saber por dónde vas)", () -> {
                d.dismiss();
                requestPermissions(new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION,
                        android.Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            }));
        }
        final boolean on = FollowManager.enabled(this);
        box.addView(settingRow(on ? "Seguir emisora: ACTIVADO" : "Seguir emisora: DESACTIVADO", () -> {
            prefs.edit().putBoolean("follow", !on).apply();
            d.dismiss();
            showFollowSettings();
        }));
        final boolean share = FollowManager.sharing(this);
        box.addView(settingRow(share ? "Compartir datos con FMLIST: SÍ" : "Compartir datos con FMLIST: NO", () -> {
            d.dismiss();
            if (share) { prefs.edit().putBoolean("shareFmlist", false).apply(); showFollowSettings(); return; }
            new AlertDialog.Builder(this).setTitle("Compartir datos de recepción")
                    .setMessage("Puedes ayudar a mejorar la base de datos de emisoras de FMLIST, que usa AVRadio.\n\n"
                            + "Se enviaría solo: frecuencia, código de la emisora, nombre, posición aproximada (unos 1 km) y la hora.\n"
                            + "No se envía tu nombre, ni datos de la pantalla, ni tu posición exacta.\n\n"
                            + "Es totalmente opcional y puedes desactivarlo cuando quieras.")
                    .setPositiveButton("Acepto compartir", (dd, w) -> { prefs.edit().putBoolean("shareFmlist", true).apply(); showFollowSettings(); })
                    .setNegativeButton("No, gracias", (dd, w) -> showFollowSettings()).show();
        }));
        ReceptionLog rl = ReceptionLog.get(this);
        TextView info = Ui.text(this, "Lugares aprendidos: " + rl.size() + "  ·  Conexión con FMLIST: "
                + (FmlistApi.available() ? "activa" : "sin clave") + "\n" + FmlistApi.CREDIT, 12, Ui.TEXT_3, false);
        info.setPadding(Ui.dp(this, 4), Ui.dp(this, 10), 0, 0);
        box.addView(info);
        box.addView(settingRow("Hecho", d::dismiss));
        show(d);
    }

    /** Pregunta a FMLIST las frecuencias de una emisora donde estás ahora. */
    private void showAlternatives(final int freq, final String pi, final String name) {
        android.location.Location loc = RadioService.follow != null ? RadioService.follow.lastLocation() : null;
        if (loc == null) {
            Toast.makeText(this, FollowManager.hasLocationPermission(this)
                    ? "Todavía no hay ubicación (espera a que el GPS te encuentre)"
                    : "Activa la ubicación en Ajustes → Seguir la emisora por zona", Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "Consultando FMLIST…", Toast.LENGTH_SHORT).show();
        String usePi = pi != null && !pi.isEmpty() ? pi : hub.piFor(freq);
        FmlistApi.alternatives(freq, usePi, loc.getLatitude(), loc.getLongitude(), a -> {
            LinearLayout box = dialogBox(a.station.isEmpty() ? (name.isEmpty() ? "Emisora" : name) : a.station,
                    a.error != null ? a.error : "Frecuencias de esta emisora donde estás, de más a menos señal prevista. Toca para escuchar.");
            final AlertDialog d = new AlertDialog.Builder(this).setView(box).create();
            for (final FmlistApi.Alt x : a.alts) {
                String label = formatFreq(x.freq) + " MHz   ·   " + x.dbuv + " dBµV" + (x.current ? "   (la actual)" : "")
                        + (x.program.isEmpty() || x.program.equals(a.station) ? "" : "   ·   " + x.program);
                box.addView(settingRow(label, () -> { d.dismiss(); radio.tune(x.freq); }));
            }
            TextView cr = Ui.text(this, FmlistApi.CREDIT, 11, Ui.TEXT_3, false);
            cr.setPadding(Ui.dp(this, 4), Ui.dp(this, 12), 0, 0);
            box.addView(cr);
            box.addView(settingRow("Cerrar", d::dismiss));
            show(d);
        });
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == REQ_LOCATION) {
            if (RadioService.follow != null) RadioService.follow.startLocation();
            showFollowSettings();
        }
    }

    /** Ajustes de avisos: permiso, activar, mostrar texto y elegir apps. */
    private void showNotifySettings() {
        LinearLayout box = dialogBox("Avisos de notificaciones",
                "AVRadio muestra un cartel cuando llega un aviso, ya que la barra de la pantalla no los enseña.");
        final AlertDialog d = new AlertDialog.Builder(this).setView(box).create();
        boolean perm = NotifyService.hasPermission(this);
        if (!perm) {
            box.addView(settingRow("⚠  Dar permiso de acceso a notificaciones", () -> {
                d.dismiss();
                try { startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")); }
                catch (Exception e) { Toast.makeText(this, "Búscalo en Ajustes → Apps → Acceso especial", Toast.LENGTH_LONG).show(); }
            }));
        }
        final boolean on = prefs.getBoolean("notifyOn", true);
        box.addView(settingRow(on ? "Avisos: ACTIVADOS" : "Avisos: DESACTIVADOS", () -> {
            prefs.edit().putBoolean("notifyOn", !on).apply();
            d.dismiss();
            showNotifySettings();
        }));
        final boolean txt = prefs.getBoolean("notifyText", true);
        box.addView(settingRow(txt ? "Mostrar el texto del mensaje: SÍ" : "Mostrar el texto del mensaje: NO (solo quién)", () -> {
            prefs.edit().putBoolean("notifyText", !txt).apply();
            d.dismiss();
            showNotifySettings();
        }));

        TextView h = Ui.text(this, "Avisar de estas apps", 15, Ui.TEXT, true);
        h.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 2));
        box.addView(h);
        TextView hint = Ui.text(this, "Aquí aparecen las apps instaladas que suelen avisar y las que ya te han mandado alguna notificación.", 12, Ui.TEXT_3, false);
        hint.setPadding(0, 0, 0, Ui.dp(this, 6));
        box.addView(hint);

        java.util.TreeMap<String, String> apps = new java.util.TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        java.util.Set<String> pk = NotifyService.seenApps(this);
        for (String p0 : NotifyService.DEFAULT_APPS) {
            try { getPackageManager().getApplicationInfo(p0, 0); pk.add(p0); } catch (Exception ignored) { }
        }
        for (String p0 : pk) apps.put(NotifyService.label(this, p0) + "|" + p0, p0);
        final java.util.Set<String> enabled = NotifyService.enabledApps(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        for (final String pkg : apps.values()) {
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8));
            row.setBackground(Ui.rounded(Ui.CARD_ON, Ui.dp(this, 14), Ui.LINE, 1));
            android.widget.ImageView iv = new android.widget.ImageView(this);
            iv.setImageBitmap(NotifyService.icon(this, pkg));
            row.addView(iv, new LinearLayout.LayoutParams(Ui.dp(this, 36), Ui.dp(this, 36)));
            TextView name = Ui.text(this, NotifyService.label(this, pkg), 16, Ui.TEXT, false);
            name.setPadding(Ui.dp(this, 12), 0, 0, 0);
            row.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            final TextView mark = Ui.text(this, enabled.contains(pkg) ? "✔" : "—", 20,
                    enabled.contains(pkg) ? Ui.OK : Ui.TEXT_3, true);
            row.addView(mark);
            row.setOnClickListener(v -> {
                if (enabled.contains(pkg)) enabled.remove(pkg); else enabled.add(pkg);
                prefs.edit().putStringSet("notifyApps", new java.util.HashSet<>(enabled)).apply();
                boolean e = enabled.contains(pkg);
                mark.setText(e ? "✔" : "—");
                mark.setTextColor(e ? Ui.OK : Ui.TEXT_3);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = Ui.dp(this, 6);
            list.addView(row, lp);
        }
        ScrollView sv = new ScrollView(this);
        sv.addView(list);
        box.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 300)));
        box.addView(settingRow("Hecho", d::dismiss));
        show(d);
    }

    private int pickVol;

    /** Elegir el volumen con el que arranca la pantalla (1–30, 0 = no tocar). */
    private void showStartVolume() {
        pickVol = prefs.getInt("startVolume", 0);
        LinearLayout box = dialogBox("Volumen al arrancar",
                "Al encender el coche, AVRadio espera unos segundos y pone este volumen. "
                        + "Volumen actual de la pantalla: " + (hub.volume >= 0 ? hub.volume : "?") + " de " + hub.volumeMax + ".");
        final TextView val = Ui.text(this, "", 48, Ui.ACCENT, true);
        val.setGravity(Gravity.CENTER);
        final Runnable upd = () -> val.setText(pickVol == 0 ? "No tocar" : String.valueOf(pickVol));
        upd.run();
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        row.addView(iconBtn("−", v -> { pickVol = Math.max(0, pickVol - 1); upd.run(); }));
        row.addView(val, new LinearLayout.LayoutParams(Ui.dp(this, 200), ViewGroup.LayoutParams.WRAP_CONTENT));
        row.addView(iconBtn("+", v -> { pickVol = Math.min(30, pickVol + 1); upd.run(); }));
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rl.topMargin = Ui.dp(this, 10);
        box.addView(row, rl);
        String res = prefs.getString("volResult", "");
        TextView r = Ui.text(this, "Resultado de la última vez: " + (res.isEmpty() ? "todavía no se ha probado" : res), 13, Ui.WARM, false);
        r.setPadding(0, Ui.dp(this, 12), 0, 0);
        box.addView(r);
        final AlertDialog d = new AlertDialog.Builder(this).setView(box).create();
        box.addView(settingRow("Guardar", () -> {
            prefs.edit().putInt("startVolume", pickVol).apply();
            d.dismiss();
        }));
        box.addView(settingRow("Guardar y probar ahora", () -> {
            prefs.edit().putInt("startVolume", pickVol).apply();
            d.dismiss();
            if (pickVol > 0) {
                Toast.makeText(this, "Probando… comprueba el volumen en unos segundos", Toast.LENGTH_LONG).show();
                hub.applyVolume(pickVol, true);
            }
        }));
        show(d);
    }

    private int pickTheme, pickStyle, pickColor;
    private Boolean pickImage;
    private Bitmap pickedBitmap;
    private BackgroundView themePreview;
    private static final int PICK_BG = 44;

    private Object[] pickedThemeData() {
        return pickTheme == Ui.CUSTOM ? Ui.customTheme(pickColor) : Ui.THEMES[pickTheme];
    }

    /** Selector de colores y estilo de fondo, con vista previa. */
    private void showThemes() {
        pickTheme = prefs.getInt("theme", 0);
        pickStyle = Ui.style;
        pickColor = prefs.getInt("customColor", Ui.ACCENT_DEFAULT);
        pickImage = prefs.getBoolean("bgImage", false);
        pickedBitmap = null;
        LinearLayout box = dialogBox("Colores y fondo", "Elige un color ambiente, un estilo y, si quieres, una imagen tuya de fondo.");
        themePreview = new BackgroundView(this);
        if (!pickImage) themePreview.setImage(null);
        themePreview.preview(pickedThemeData(), pickStyle);
        themePreview.setClipToOutline(true);
        themePreview.setBackground(Ui.rounded(Ui.CARD, Ui.dp(this, 16), Ui.LINE, 1));
        box.addView(themePreview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 160)));

        final TextView themeName = Ui.text(this, (String) pickedThemeData()[0], 15, Ui.TEXT, true);
        themeName.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 6));
        box.addView(themeName);

        final ColorWheelView wheel = new ColorWheelView(this);
        wheel.setColor(pickColor);
        wheel.setVisibility(pickTheme == Ui.CUSTOM ? View.VISIBLE : View.GONE);
        wheel.setListener(c -> {
            pickColor = c;
            themePreview.preview(pickedThemeData(), pickStyle);
        });

        LinearLayout sw = new LinearLayout(this);
        for (int i = 0; i <= Ui.THEMES.length; i++) {
            final int t = i == Ui.THEMES.length ? Ui.CUSTOM : i;
            View dot = new View(this);
            GradientDrawable g;
            if (t == Ui.CUSTOM) {
                g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{
                        Color.rgb(255, 70, 70), Color.rgb(255, 210, 60), Color.rgb(60, 220, 120),
                        Color.rgb(60, 160, 255), Color.rgb(190, 90, 255)});
            } else {
                g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                        new int[]{(Integer) Ui.THEMES[i][5], (Integer) Ui.THEMES[i][1]});
            }
            g.setShape(GradientDrawable.OVAL);
            g.setStroke(Ui.dp(this, 2), Color.argb(90, 255, 255, 255));
            dot.setBackground(g);
            dot.setOnClickListener(v -> {
                pickTheme = t;
                themeName.setText((String) pickedThemeData()[0]);
                wheel.setVisibility(t == Ui.CUSTOM ? View.VISIBLE : View.GONE);
                themePreview.preview(pickedThemeData(), pickStyle);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44));
            lp.setMargins(0, 0, Ui.dp(this, 8), 0);
            sw.addView(dot, lp);
        }
        box.addView(sw);
        LinearLayout.LayoutParams wl = new LinearLayout.LayoutParams(Ui.dp(this, 200), Ui.dp(this, 200));
        wl.gravity = Gravity.CENTER_HORIZONTAL;
        wl.topMargin = Ui.dp(this, 10);
        box.addView(wheel, wl);

        TextView st = Ui.text(this, "Estilo de fondo", 15, Ui.TEXT, true);
        st.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 6));
        box.addView(st);
        LinearLayout styles = new LinearLayout(this);
        final List<TextView> chips = new ArrayList<>();
        for (int i = 0; i < Ui.STYLES.length; i++) {
            final int k = i;
            final TextView c = pill(Ui.STYLES[i], false);
            chips.add(c);
            c.setOnClickListener(v -> {
                pickStyle = k;
                themePreview.preview(pickedThemeData(), pickStyle);
                for (int j = 0; j < chips.size(); j++) chips.get(j).setTextColor(j == k ? Ui.ACCENT : Ui.TEXT_2);
            });
            c.setTextColor(i == pickStyle ? Ui.ACCENT : Ui.TEXT_2);
            styles.addView(c, chipLp());
        }
        box.addView(styles);

        LinearLayout imgRow = new LinearLayout(this);
        TextView pick = pill("Imagen de fondo…", false);
        pick.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            startActivityForResult(Intent.createChooser(i, "Elige la imagen de fondo"), PICK_BG);
        });
        TextView noImg = pill("Sin imagen", false);
        noImg.setOnClickListener(v -> { pickImage = false; pickedBitmap = null; themePreview.setImage(null); });
        imgRow.addView(pick, chipLp());
        imgRow.addView(noImg, chipLp());
        LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        il.topMargin = Ui.dp(this, 10);
        box.addView(imgRow, il);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(box);
        final AlertDialog d = new AlertDialog.Builder(this).setView(scroll).create();
        box.addView(settingRow("Aplicar", () -> {
            android.content.SharedPreferences.Editor e = prefs.edit()
                    .putInt("theme", pickTheme).putInt("bgStyle", pickStyle)
                    .putInt("customColor", pickColor).putBoolean("bgImage", pickImage);
            e.apply();
            if (pickImage && pickedBitmap != null) {
                try (java.io.FileOutputStream o = new java.io.FileOutputStream(BackgroundView.imageFile(this))) {
                    pickedBitmap.compress(Bitmap.CompressFormat.JPEG, 88, o);
                } catch (Exception ignored) { }
            }
            Ui.loadTheme(this);
            Widgets.update(this);
            d.dismiss();
            recreate();
        }));
        box.addView(settingRow("Cancelar", d::dismiss));
        d.setOnDismissListener(di -> themePreview = null);
        show(d);
    }

    /** Reduce una imagen grande al tamaño de la pantalla. */
    private Bitmap shrink(Bitmap b) {
        int max = 1400;
        int w = b.getWidth(), h = b.getHeight();
        if (w <= max && h <= max) return b;
        float k = Math.min(max / (float) w, max / (float) h);
        return Bitmap.createScaledBitmap(b, Math.round(w * k), Math.round(h * k), true);
    }

    /** Huella (SHA-256) de la contraseña de administrador; la contraseña no aparece en el código. */
    private static final String ADMIN_HASH = "f0f5e8b6348c37e3de794a7e93d2ca2abec4decdfde271606d6639460044ae84";

    private boolean isAdmin() { return prefs.getBoolean("admin", false); }

    private static String sha256(String t) {
        try {
            byte[] h = java.security.MessageDigest.getInstance("SHA-256").digest(("AVRadio-DanLab:" + t).getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : h) sb.append(String.format(Locale.ROOT, "%02x", b));
            return sb.toString();
        } catch (Exception e) { return ""; }
    }

    private void askAdminPassword() {
        final android.widget.EditText ed = new android.widget.EditText(this);
        ed.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        ed.setSingleLine(true);
        new AlertDialog.Builder(this).setTitle("Modo administrador")
                .setMessage("Introduce la contraseña")
                .setView(ed)
                .setPositiveButton("Entrar", (dd, w) -> {
                    if (ADMIN_HASH.equals(sha256(ed.getText().toString().trim()))) {
                        prefs.edit().putBoolean("admin", true).apply();
                        Toast.makeText(this, "Modo administrador activado", Toast.LENGTH_SHORT).show();
                        showSettings();
                    } else {
                        Toast.makeText(this, "Contraseña incorrecta", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancelar", null).show();
    }

    private void askOverlay() {
        new AlertDialog.Builder(this).setTitle("Permiso necesario")
                .setMessage("Para que AVRadio pueda abrirse sola al encender el coche, Android necesita que le permitas «mostrarse sobre otras apps».")
                .setPositiveButton("Dar permiso", (dd, w) -> {
                    try {
                        startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + getPackageName())));
                    } catch (Exception ignored) { }
                })
                .setNegativeButton("Ahora no", null).show();
    }

    /** Por si la pantalla no tiene selector de archivos: guarda en Descargas. */
    private void exportToDownloads() {
        try {
            java.io.File dir = getExternalFilesDir(android.os.Environment.DIRECTORY_DOCUMENTS);
            java.io.File f = new java.io.File(dir, "AVRadio_favoritas.json");
            try (java.io.FileOutputStream o = new java.io.FileOutputStream(f)) { o.write(favs.toJson().getBytes("UTF-8")); }
            Toast.makeText(this, "Guardado en " + f.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (Exception e) { Toast.makeText(this, "No se ha podido guardar", Toast.LENGTH_LONG).show(); }
    }

    private void refreshPower() {
        if (offOverlay != null) offOverlay.setVisibility(hub.isPowered() ? View.GONE : View.VISIBLE);
        if (bars != null) bars.setRunning(hub.isPowered() && visible);
    }

    @Override
    public void onBackPressed() {
        // Como la radio original: salir con "atrás" apaga la radio (configurable)
        if (prefs.getBoolean("backOff", true)) hub.powerOff();
        super.onBackPressed();
    }

    // ===================== Diseños de pantalla =====================

    static final int LAYOUT_CLASSIC = 0, LAYOUT_COLUMN = 1;
    static final String[] LAYOUT_NAMES = {"Clásico", "Columna"};
    static final String[] LAYOUT_DESC = {
            "Carrusel horizontal arriba, dial y botones en medio y favoritas en rejilla abajo.",
            "Favoritas en una columna a la izquierda y carrusel vertical grande a la derecha."};

    private int layoutId() { return prefs.getInt("layout", LAYOUT_CLASSIC); }

    private LinearLayout starBox, ctrRow, favColumn;
    private ScrollView favColumnScroll;
    private final List<StationTileView> colTiles = new ArrayList<>();

    /** Crea las piezas comunes; cada diseño las coloca a su manera. */
    private void createCommonViews() {
        bars = new AmbientBarsView(this);
        bars.setEnabledBars(prefs.getBoolean("bars", true));

        chipAf = pill("AF", false);
        chipTa = pill("TA", false);
        chipSt = pill("ESTÉREO", false);
        chipAf.setOnClickListener(v -> radio.setAf(!afOn));

        carousel = new CarouselView(this);
        carousel.setListener(new CarouselView.Listener() {
            @Override public void onPick(CarouselView.Item item) { radio.tune(item.freq); }
            @Override public void onLongPress(CarouselView.Item item) { stationMenu(item.freq, item.name, currentPi()); }
        });

        tvStar = Ui.text(this, "☆", 48, Ui.TEXT_2, false);
        tvStar.setGravity(Gravity.CENTER);
        tvStarLabel = Ui.text(this, "Guardar", 12, Ui.TEXT_3, true);
        tvStarLabel.setGravity(Gravity.CENTER);
        tvStarLabel.setLetterSpacing(0.08f);
        starBox = new LinearLayout(this);
        starBox.setGravity(Gravity.CENTER);
        starBox.addView(tvStar);
        starBox.addView(tvStarLabel);
        starBox.setBackground(Ui.rounded(Ui.CARD, Ui.dp(this, 18), Ui.LINE, Ui.dp(this, 1)));
        starBox.setOnClickListener(v -> toggleFavorite());

        tvName = Ui.text(this, "AVRadio", 36, Ui.TEXT, true);
        tvName.setGravity(Gravity.CENTER);
        tvName.setSingleLine(true);
        tvName.setEllipsize(TextUtils.TruncateAt.END);

        tvFreq = Ui.text(this, "", 19, Ui.ACCENT, false);
        tvFreq.setGravity(Gravity.CENTER);
        tvFreq.setLetterSpacing(0.06f);

        tvPty = Ui.text(this, " ", 12, Ui.WARM, true);
        tvPty.setLetterSpacing(0.2f);
        tvPty.setGravity(Gravity.CENTER);
        tvPty.setVisibility(View.INVISIBLE);

        ivCover = new android.widget.ImageView(this);
        ivCover.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
        ivCover.setClipToOutline(true);
        ivCover.setBackground(Ui.rounded(Ui.CARD, Ui.dp(this, 8), Ui.LINE, 1));
        ivCover.setVisibility(View.GONE);
        tvRt = Ui.text(this, " ", 15, Ui.TEXT_2, false);
        tvRt.setGravity(Gravity.CENTER);
        tvRt.setSingleLine(true);
        tvRt.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        tvRt.setMarqueeRepeatLimit(-1);
        tvRt.setHorizontalFadingEdgeEnabled(true);

        scale = new TunerScaleView(this);
        scale.setListener(f -> radio.tune(f));

        ctrRow = new LinearLayout(this);
        ctrRow.setGravity(Gravity.CENTER);
    }

    private LinearLayout rtRow() {
        LinearLayout rtRow = new LinearLayout(this);
        rtRow.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams cvl = new LinearLayout.LayoutParams(Ui.dp(this, 48), Ui.dp(this, 48));
        cvl.rightMargin = Ui.dp(this, 12);
        rtRow.addView(ivCover, cvl);
        rtRow.addView(tvRt, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return rtRow;
    }

    /** Diseño 1: Clásico (el de siempre). */
    private void buildClassicLayout(LinearLayout root) {
        FrameLayout hero = new FrameLayout(this);
        hero.addView(bars, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 150), Gravity.BOTTOM));
        LinearLayout heroRow = new LinearLayout(this);
        heroRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.setGravity(Gravity.CENTER);
        left.addView(chipAf, sideLp());
        left.addView(chipTa, sideLp());
        left.addView(chipSt, sideLp());
        heroRow.addView(left, new LinearLayout.LayoutParams(Ui.dp(this, 92), ViewGroup.LayoutParams.WRAP_CONTENT));
        heroRow.addView(carousel, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        starBox.setOrientation(LinearLayout.VERTICAL);
        starBox.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 10));
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(Ui.dp(this, 84), ViewGroup.LayoutParams.WRAP_CONTENT);
        rl.leftMargin = Ui.dp(this, 8);
        heroRow.addView(starBox, rl);
        hero.addView(heroRow, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        hl.topMargin = Ui.dp(this, 4);
        root.addView(hero, hl);

        root.addView(tvName, centered(2));
        root.addView(tvFreq, centered(6));
        root.addView(tvPty, centered(6));
        LinearLayout.LayoutParams rrl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 52));
        rrl.topMargin = Ui.dp(this, 4);
        root.addView(rtRow(), rrl);

        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 80));
        slp.topMargin = Ui.dp(this, 6);
        root.addView(scale, slp);

        addCtrl(ctrRow, ControlButton.SEEK_PREV, true, v -> seek(false));
        addCtrl(ctrRow, ControlButton.STEP_PREV, false, v -> radio.stepPrev());
        addCtrl(ctrRow, ControlButton.STEP_NEXT, false, v -> radio.stepNext());
        addCtrl(ctrRow, ControlButton.SEEK_NEXT, true, v -> seek(true));
        root.addView(ctrRow, centered(4));

        tvFavHint = Ui.text(this, "", 12, Ui.TEXT_3, false);
        tvFavHint.setLetterSpacing(0.05f);
        root.addView(tvFavHint, centered(12));
        favPager = new FavPager(this);
        favPager.setListener(p -> refreshDots());
        LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        gl.topMargin = Ui.dp(this, 4);
        root.addView(favPager, gl);
        favDots = new LinearLayout(this);
        favDots.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 14));
        dlp.topMargin = Ui.dp(this, 6);
        root.addView(favDots, dlp);
        buildFavPages(1);
    }

    /** Diseño 2: Columna — favoritas a la izquierda y carrusel vertical a la derecha. */
    private void buildColumnLayout(LinearLayout root) {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        bl.topMargin = Ui.dp(this, 10);
        root.addView(body, bl);

        // Columna de favoritas
        favColumnScroll = new ScrollView(this);
        favColumnScroll.setVerticalScrollBarEnabled(false);
        favColumn = new LinearLayout(this);
        favColumn.setOrientation(LinearLayout.VERTICAL);
        favColumnScroll.addView(favColumn);
        body.addView(favColumnScroll, new LinearLayout.LayoutParams(Ui.dp(this, 104), ViewGroup.LayoutParams.MATCH_PARENT));

        // Línea luminosa de separación
        View line = new View(this);
        GradientDrawable lg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{
                Color.argb(0, Color.red(Ui.ACCENT), Color.green(Ui.ACCENT), Color.blue(Ui.ACCENT)),
                Ui.ACCENT,
                Color.argb(0, Color.red(Ui.ACCENT_2), Color.green(Ui.ACCENT_2), Color.blue(Ui.ACCENT_2))});
        lg.setCornerRadius(Ui.dp(this, 2));
        line.setBackground(lg);
        LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(Ui.dp(this, 2), ViewGroup.LayoutParams.MATCH_PARENT);
        ll.setMargins(Ui.dp(this, 12), Ui.dp(this, 10), Ui.dp(this, 12), Ui.dp(this, 10));
        body.addView(line, ll);

        // Zona derecha
        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        body.addView(right, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        FrameLayout hero = new FrameLayout(this);
        hero.addView(bars, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 130), Gravity.CENTER_VERTICAL));
        carousel.setVertical(true);
        hero.addView(carousel, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        right.addView(hero, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        tvName.setTextSize(32);
        right.addView(tvName, centered(6));
        right.addView(tvFreq, centered(4));
        right.addView(tvPty, centered(6));
        LinearLayout.LayoutParams rrl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 52));
        rrl.topMargin = Ui.dp(this, 2);
        right.addView(rtRow(), rrl);

        LinearLayout chips = new LinearLayout(this);
        chips.setGravity(Gravity.CENTER);
        chips.addView(chipAf, chipLp());
        chips.addView(chipTa, chipLp());
        chips.addView(chipSt, chipLp());
        starBox.setOrientation(LinearLayout.HORIZONTAL);
        starBox.setPadding(Ui.dp(this, 12), Ui.dp(this, 2), Ui.dp(this, 14), Ui.dp(this, 2));
        tvStar.setTextSize(22);
        tvStarLabel.setPadding(Ui.dp(this, 6), 0, 0, 0);
        chips.addView(starBox, chipLp());
        right.addView(chips, centered(8));

        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 72));
        slp.topMargin = Ui.dp(this, 8);
        right.addView(scale, slp);

        addCtrl(ctrRow, ControlButton.SEEK_PREV, true, v -> seek(false));
        addCtrl(ctrRow, ControlButton.STEP_PREV, false, v -> radio.stepPrev());
        addCtrl(ctrRow, ControlButton.STEP_NEXT, false, v -> radio.stepNext());
        addCtrl(ctrRow, ControlButton.SEEK_NEXT, true, v -> seek(true));
        right.addView(ctrRow, centered(4));

        tvFavHint = Ui.text(this, "", 1, Ui.TEXT_3, false);   // no se usa en este diseño
    }

    /** Rellena la columna de favoritas (diseño Columna). */
    private void refreshFavColumn(Favorites.Station current) {
        List<Favorites.Station> l = favs.all();
        if (colTiles.size() != l.size()) {
            favColumn.removeAllViews();
            colTiles.clear();
            for (int i = 0; i < l.size(); i++) {
                final StationTileView t = new StationTileView(this);
                t.setCompact(true);
                t.setOnClickListener(v -> {
                    Object o = t.getTag();
                    if (o instanceof Favorites.Station) radio.tune(((Favorites.Station) o).freq);
                });
                t.setOnLongClickListener(v -> {
                    Object o = t.getTag();
                    if (!(o instanceof Favorites.Station)) return false;
                    Favorites.Station st = (Favorites.Station) o;
                    stationMenu(st.freq, st.name, st.pi);
                    return true;
                });
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 92));
                lp.bottomMargin = Ui.dp(this, 8);
                favColumn.addView(t, lp);
                colTiles.add(t);
            }
        }
        int activeIdx = -1;
        for (int i = 0; i < l.size(); i++) {
            Favorites.Station st = l.get(i);
            colTiles.get(i).set(i + 1, st.name.isEmpty() ? "—" : st.name, formatFreq(st.freq), st.key(),
                    logos.get(st.key(), st.name), st == current);
            colTiles.get(i).setTag(st);
            if (st == current) activeIdx = i;
        }
        // Al cambiar de emisora, desplazar la columna hasta la que suena
        if (activeIdx >= 0 && current.freq != lastFavFreq) {
            final View target = colTiles.get(activeIdx);
            favColumnScroll.post(() -> favColumnScroll.smoothScrollTo(0,
                    Math.max(0, target.getTop() - favColumnScroll.getHeight() / 2 + target.getHeight() / 2)));
        }
        lastFavFreq = current != null ? current.freq : 0;
    }

    /** Elegir diseño de pantalla. */
    private void showLayouts() {
        LinearLayout box = dialogBox("Diseño de pantalla", "Elige cómo se organiza AVRadio. Los colores se mantienen.");
        final AlertDialog d = new AlertDialog.Builder(this).setView(scrollable(box)).create();
        int curL = layoutId();
        for (int i = 0; i < LAYOUT_NAMES.length; i++) {
            final int k = i;
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.VERTICAL);
            row.setPadding(Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 14), Ui.dp(this, 12));
            row.setBackground(Ui.rounded(k == curL ? Ui.CARD_ON : Ui.CARD, Ui.dp(this, 14),
                    k == curL ? Ui.ACCENT : Ui.LINE, Ui.dp(this, k == curL ? 2 : 1)));
            row.addView(Ui.text(this, (k == curL ? "✔  " : "") + LAYOUT_NAMES[k], 18, k == curL ? Ui.ACCENT : Ui.TEXT, true));
            TextView ds = Ui.text(this, LAYOUT_DESC[k], 13, Ui.TEXT_2, false);
            ds.setPadding(0, Ui.dp(this, 4), 0, 0);
            row.addView(ds);
            row.setOnClickListener(v -> {
                prefs.edit().putInt("layout", k).apply();
                d.dismiss();
                recreate();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = Ui.dp(this, 8);
            box.addView(row, lp);
        }
        box.addView(settingRow("Cancelar", d::dismiss));
        show(d);
    }

    private void seek(boolean next) {
        if (taOn) Toast.makeText(this, "TA activado: solo se para en emisoras con información de tráfico", Toast.LENGTH_LONG).show();
        if (next) radio.seekNext(); else radio.seekPrev();
    }

    private LinearLayout.LayoutParams sideLp() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, Ui.dp(this, 5), 0, Ui.dp(this, 5));
        return p;
    }

    private void toggleFavorite() {
        if (currentFreq == 0) return;
        String pi = currentPi();
        Favorites.Station f = favs.find(currentFreq, pi);
        if (f != null) {
            favs.remove(f);
            Toast.makeText(this, "Quitada de favoritas", Toast.LENGTH_SHORT).show();
        } else {
            favs.add(currentFreq, currentName(), pi);
            Toast.makeText(this, "Guardada en favoritas", Toast.LENGTH_SHORT).show();
        }
        refreshAll();
    }

    /** Menú de una emisora: guardar/quitar, logo… */
    private void stationMenu(final int freq, final String name, final String pi) {
        final Favorites.Station f = favs.find(freq, pi);
        final String key = f != null ? f.key() : Favorites.keyFor(pi, name);
        LinearLayout box = dialogBox((name.isEmpty() ? "Emisora" : name) + "  ·  " + formatFreq(freq), null);
        final AlertDialog d = new AlertDialog.Builder(this).setView(box).create();
        box.addView(settingRow(f != null ? "Quitar de favoritas" : "Guardar en favoritas", () -> {
            if (f != null) favs.remove(f); else favs.add(freq, name, pi);
            d.dismiss();
            refreshAll();
        }));
        box.addView(settingRow("Elegir logo (imagen de la pantalla)", () -> {
            d.dismiss();
            if (key.isEmpty()) { Toast.makeText(this, "Espera a que salga el nombre de la emisora", Toast.LENGTH_LONG).show(); return; }
            pendingLogoKey = key;
            pendingLogoName = name;
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            startActivityForResult(Intent.createChooser(i, "Elige el logo"), PICK_LOGO);
        }));
        box.addView(settingRow("Buscar el logo otra vez en internet", () -> {
            d.dismiss();
            if (!key.isEmpty()) {
                logos.retry(key, name);
                Toast.makeText(this, "Buscando logo…", Toast.LENGTH_SHORT).show();
            }
        }));
        if (f != null) {
            box.addView(settingRow("Cambiar nombre", () -> { d.dismiss(); renameDialog(f); }));
            box.addView(settingRow("Ordenar favoritas", () -> { d.dismiss(); showOrder(); }));
        }
        box.addView(settingRow("Otras frecuencias de esta emisora (FMLIST)", () -> { d.dismiss(); showAlternatives(freq, pi, name); }));
        box.addView(settingRow("Sintonizar", () -> { d.dismiss(); radio.tune(freq); }));
        show(d);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        if (req == EXPORT_FAVS) {
            try (java.io.OutputStream o = getContentResolver().openOutputStream(data.getData())) {
                o.write(favs.toJson().getBytes("UTF-8"));
                Toast.makeText(this, "Favoritas exportadas", Toast.LENGTH_SHORT).show();
            } catch (Exception e) { Toast.makeText(this, "No se ha podido guardar", Toast.LENGTH_LONG).show(); }
            return;
        }
        if (req == IMPORT_FAVS) {
            try (InputStream in = getContentResolver().openInputStream(data.getData())) {
                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                int added = favs.importJson(bo.toString("UTF-8"));
                refreshAll();
                Toast.makeText(this, "Importadas " + added + " emisoras nuevas", Toast.LENGTH_LONG).show();
            } catch (Exception e) { Toast.makeText(this, "Ese archivo no es una copia de AVRadio", Toast.LENGTH_LONG).show(); }
            return;
        }
        if (req == PICK_BG) {
            try (InputStream in = getContentResolver().openInputStream(data.getData())) {
                Bitmap b = BitmapFactory.decodeStream(in);
                if (b != null && themePreview != null) {
                    pickedBitmap = shrink(b);
                    pickImage = true;
                    themePreview.setImage(pickedBitmap);
                }
            } catch (Exception e) { Toast.makeText(this, "No se ha podido leer la imagen", Toast.LENGTH_LONG).show(); }
            return;
        }
        if (req != PICK_LOGO) return;
        try {
            Uri u = data.getData();
            InputStream in = getContentResolver().openInputStream(u);
            Bitmap b = BitmapFactory.decodeStream(in);
            if (in != null) in.close();
            if (b != null) {
                logos.setManual(pendingLogoKey, b);
                Toast.makeText(this, "Logo guardado", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "No se ha podido leer la imagen", Toast.LENGTH_LONG).show();
        }
    }

    // --- Lista de emisoras disponibles ---

    private void showStationList() {
        if (stationDialog != null) return;
        LinearLayout box = dialogBox("Emisoras disponibles",
                "Toca una emisora para escucharla y la estrella ☆ para guardarla en favoritas.");
        // Estado de la búsqueda, siempre visible
        scanStatus = Ui.text(this, "", 15, Ui.ACCENT, true);
        scanStatus.setPadding(Ui.dp(this, 4), Ui.dp(this, 4), 0, Ui.dp(this, 6));
        box.addView(scanStatus);
        scanBar = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        scanBar.setMax(2050);
        scanBar.setProgressTintList(android.content.res.ColorStateList.valueOf(Ui.ACCENT));
        box.addView(scanBar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 8)));

        stationListBox = new LinearLayout(this);
        stationListBox.setOrientation(LinearLayout.VERTICAL);
        stationScroll = new ScrollView(this);
        stationScroll.addView(stationListBox);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 440));
        sl.topMargin = Ui.dp(this, 8);
        box.addView(stationScroll, sl);
        stationDialog = new AlertDialog.Builder(this).setView(box).create();
        scanButton = settingRow("", () -> {
            if (scanning) { stopScan(); return; }
            new AlertDialog.Builder(this)
                    .setTitle("Buscar emisoras")
                    .setMessage("El sintonizador recorrerá todo el dial, de 87.5 a 108 MHz. Puede tardar un minuto o dos. "
                            + "Esto cambia las presintonías de la radio original, pero tus favoritas de AVRadio no se tocan.")
                    .setPositiveButton("Buscar", (dd, w) -> startScan())
                    .setNegativeButton("Cancelar", null).show();
        });
        box.addView(scanButton);
        box.addView(settingRow("Cerrar", () -> stationDialog.dismiss()));
        stationDialog.setOnDismissListener(di -> {
            stationListBox = null; stationDialog = null; scanStatus = null; scanBar = null; scanButton = null; stationScroll = null;
        });
        updateScanProgress();
        refreshStationList();
        show(stationDialog);
    }

    private void startScan() {
        scanning = true;
        scanStarted = System.currentTimeMillis();
        scanReturnFreq = currentFreq;
        scanFreq = 8750;
        found.clear();
        mcu.clear();
        refreshStationList();
        updateScanProgress();
        radio.autoStore();
        kickScanWatch();
    }

    private void stopScan() {
        if (!scanning) return;
        // Sintonizar cualquier frecuencia detiene la búsqueda del sintonizador
        radio.tune(scanReturnFreq > 0 ? scanReturnFreq : 8980);
        finishScan(true);
    }

    /** La búsqueda acaba cuando el sintonizador deja de mandar datos un rato. */
    private final Runnable scanWatch = () -> finishScan(false);

    private void kickScanWatch() {
        ui.removeCallbacks(scanWatch);
        long since = System.currentTimeMillis() - scanStarted;
        ui.postDelayed(scanWatch, since < 8000 ? 9000 : 5000);
    }

    private void finishScan(boolean stopped) {
        if (!scanning) return;
        ui.removeCallbacks(scanWatch);
        scanning = false;
        for (Preset p : mcu.values()) if (p.freq > 0 && !found.containsKey(p.freq)) found.put(p.freq, p);
        addLog("Búsqueda " + (stopped ? "detenida" : "terminada") + ": " + found.size() + " emisoras");
        updateScanProgress();
        refreshStationList();
        nameUnknownStations();
    }

    private void updateScanProgress() {
        if (scanStatus == null) return;
        if (scanning) {
            scanStatus.setText("Buscando…  " + formatFreq(Math.max(8750, scanFreq)) + " MHz  ·  " + found.size() + " encontradas");
            scanStatus.setTextColor(Ui.ACCENT);
            scanBar.setVisibility(View.VISIBLE);
            scanBar.setProgress(Math.max(0, Math.min(2050, scanFreq - 8750)));
            scanButton.setText("■  Detener la búsqueda");
        } else {
            int n = found.isEmpty() ? countMcu() : found.size();
            scanStatus.setText(n == 0 ? "Sin búsqueda todavía" : "✔  " + n + " emisoras encontradas");
            scanStatus.setTextColor(n == 0 ? Ui.TEXT_2 : Ui.OK);
            scanBar.setVisibility(View.GONE);
            scanButton.setText("Buscar todas las emisoras de esta zona");
        }
    }

    private int countMcu() {
        java.util.HashSet<Integer> f = new java.util.HashSet<>();
        for (Preset p : mcu.values()) if (p.freq > 0) f.add(p.freq);
        return f.size();
    }

    /** Las emisoras que llegan sin nombre: se lo preguntamos a FMLIST. */
    private void nameUnknownStations() {
        android.location.Location loc = RadioService.follow != null ? RadioService.follow.lastLocation() : null;
        if (loc == null || !FmlistApi.available()) return;
        for (final Preset p : new ArrayList<>(found.values())) {
            if (!p.ps.isEmpty()) continue;
            FmlistApi.alternatives(p.freq, p.pi, loc.getLatitude(), loc.getLongitude(), a -> {
                if (a.error == null && !a.station.isEmpty() && p.ps.isEmpty()) {
                    p.ps = a.station;
                    addLog("Nombre desde FMLIST: " + formatFreq(p.freq) + " = " + a.station);
                    refreshStationList();
                }
            });
        }
    }

    private void refreshStationList() {
        if (stationListBox == null) return;
        final int keepScroll = stationScroll != null ? stationScroll.getScrollY() : 0;
        stationListBox.removeAllViews();
        TreeMap<Integer, Preset> byFreq = new TreeMap<>(found);
        if (byFreq.isEmpty()) for (Preset p : mcu.values()) if (p.freq > 0) byFreq.put(p.freq, p);
        updateScanProgress();
        if (byFreq.isEmpty()) {
            TextView t = Ui.text(this, scanning ? "Buscando emisoras… irán apareciendo aquí." : "Todavía no hay emisoras. Pulsa «Buscar todas las emisoras».", 15, Ui.TEXT_2, false);
            t.setPadding(0, Ui.dp(this, 16), 0, Ui.dp(this, 16));
            stationListBox.addView(t);
            return;
        }
        for (final Preset p : byFreq.values()) {
            final Favorites.Station f = favs.find(p.freq, p.pi);
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8));
            row.setBackground(Ui.rounded(p.freq == currentFreq ? Ui.CARD_ON : Ui.CARD, Ui.dp(this, 14), Ui.LINE, 1));
            LogoView lv = new LogoView(this, false);
            String key = Favorites.keyFor(p.pi, p.ps);
            lv.setStation(p.ps.isEmpty() ? formatFreq(p.freq) : p.ps, key);
            lv.setLogo(p.ps.isEmpty() ? null : logos.get(key, p.ps));
            row.addView(lv, new LinearLayout.LayoutParams(Ui.dp(this, 42), Ui.dp(this, 42)));
            LinearLayout txt = new LinearLayout(this);
            txt.setOrientation(LinearLayout.VERTICAL);
            txt.setPadding(Ui.dp(this, 12), 0, 0, 0);
            txt.addView(Ui.text(this, p.ps.isEmpty() ? "Sin nombre (tócala para leerlo)" : p.ps, 17, p.ps.isEmpty() ? Ui.TEXT_2 : Ui.TEXT, true));
            txt.addView(Ui.text(this, formatFreq(p.freq) + " MHz" + (p.pi.isEmpty() ? "" : "   ·   PI " + p.pi), 12, Ui.TEXT_2, false));
            row.addView(txt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView star = Ui.text(this, f != null ? "★" : "☆", 26, f != null ? Ui.WARM : Ui.TEXT_2, false);
            star.setPadding(Ui.dp(this, 14), Ui.dp(this, 4), Ui.dp(this, 6), Ui.dp(this, 4));
            star.setOnClickListener(v -> {
                if (f != null) favs.remove(f); else favs.add(p.freq, p.ps, p.pi);
                refreshAll();
                refreshStationList();
            });
            row.addView(star);
            row.setOnClickListener(v -> { if (!scanning) radio.tune(p.freq); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = Ui.dp(this, 6);
            stationListBox.addView(row, lp);
        }
        if (stationScroll != null) stationScroll.post(() -> { if (stationScroll != null) stationScroll.scrollTo(0, keepScroll); });
    }

    // --- Ajustes ---

    private void showSettings() {
        LinearLayout box = dialogBox("AVRadio", "Versión " + BuildConfig.VERSION_NAME + "  ·  Creado por DanLab\n" + FmlistApi.CREDIT);
        final int[] taps = {0};
        box.getChildAt(1).setOnClickListener(v -> {
            if (isAdmin()) return;
            if (++taps[0] >= 7) { taps[0] = 0; askAdminPassword(); }
        });
        final AlertDialog d = new AlertDialog.Builder(this).setView(scrollable(box)).create();
        box.addView(settingRow("Diseño de pantalla: " + LAYOUT_NAMES[Math.min(layoutId(), LAYOUT_NAMES.length - 1)], () -> { d.dismiss(); showLayouts(); }));
        box.addView(settingRow("Colores y fondo", () -> { d.dismiss(); showThemes(); }));
        int sv = prefs.getInt("startVolume", 0);
        box.addView(settingRow(sv > 0 ? "Volumen al arrancar: nivel " + sv : "Volumen al arrancar: no tocar", () -> {
            d.dismiss();
            showStartVolume();
        }));
        final boolean bo = prefs.getBoolean("backOff", true);
        box.addView(settingRow(bo ? "Botón atrás: apaga la radio" : "Botón atrás: la radio sigue sonando", () -> {
            prefs.edit().putBoolean("backOff", !bo).apply();
            d.dismiss();
        }));
        box.addView(settingRow("Avisos de notificaciones (WhatsApp, llamadas…)", () -> { d.dismiss(); showNotifySettings(); }));
        box.addView(settingRow("Seguir la emisora por zona (beta)", () -> { d.dismiss(); showFollowSettings(); }));
        box.addView(settingRow("Ordenar y renombrar favoritas", () -> { d.dismiss(); showOrder(); }));
        box.addView(settingRow("Buscar actualización", () -> { d.dismiss(); checkUpdate(true); }));
        box.addView(settingRow(afOn ? "Desactivar AF (frecuencias alternativas)" : "Activar AF (frecuencias alternativas)",
                () -> { radio.setAf(!afOn); d.dismiss(); }));
        box.addView(settingRow(taOn ? "Desactivar TA (avisos de tráfico)" : "Activar TA (avisos de tráfico)", () -> {
            d.dismiss();
            if (taOn) { radio.setTa(false); return; }
            new AlertDialog.Builder(this).setTitle("Avisos de tráfico (TA)")
                    .setMessage("Con TA activado, la búsqueda solo se detiene en emisoras que emiten información de tráfico y se salta las demás.")
                    .setPositiveButton("Activar", (dd, w) -> radio.setTa(true))
                    .setNegativeButton("Cancelar", null).show();
        }));
        final android.content.SharedPreferences sp = prefs;
        final boolean barsOn = sp.getBoolean("bars", true);
        box.addView(settingRow(barsOn ? "Quitar barras animadas de fondo" : "Poner barras animadas de fondo", () -> {
            sp.edit().putBoolean("bars", !barsOn).apply();
            bars.setEnabledBars(!barsOn);
            if (!barsOn) bars.setRunning(true);
            d.dismiss();
        }));
        final boolean auto = sp.getBoolean("autostart", true);
        box.addView(settingRow(auto ? "Abrir AVRadio al encender el coche: SÍ" : "Abrir AVRadio al encender el coche: NO", () -> {
            sp.edit().putBoolean("autostart", !auto).apply();
            d.dismiss();
            if (!auto && !RadioService.canDrawOverlays(this)) askOverlay();
        }));
        long acc = sp.getLong("lastAccOn", 0), boot = sp.getLong("lastBoot", 0);
        SimpleDateFormat df = new SimpleDateFormat("dd/MM HH:mm", Locale.ROOT);
        TextView diag = Ui.text(this, "Diagnóstico · último encendido detectado: "
                + (acc > 0 ? df.format(new Date(acc)) : "nunca") + "  ·  último arranque: "
                + (boot > 0 ? df.format(new Date(boot)) : "nunca")
                + "  ·  permiso «sobre otras apps»: " + (RadioService.canDrawOverlays(this) ? "SÍ" : "NO"), 11, Ui.TEXT_3, false);
        diag.setPadding(Ui.dp(this, 4), Ui.dp(this, 6), Ui.dp(this, 4), Ui.dp(this, 2));
        diag.setOnClickListener(v -> { if (!RadioService.canDrawOverlays(this)) { d.dismiss(); askOverlay(); } });
        if (isAdmin()) box.addView(diag);
        final boolean pop = sp.getBoolean("popup", true);
        box.addView(settingRow(pop ? "Aviso de emisora sobre otras apps: SÍ" : "Aviso de emisora sobre otras apps: NO", () -> {
            sp.edit().putBoolean("popup", !pop).apply();
            d.dismiss();
        }));
        final boolean cov = sp.getBoolean("covers", true);
        box.addView(settingRow(cov ? "Carátulas de las canciones: SÍ" : "Carátulas de las canciones: NO", () -> {
            sp.edit().putBoolean("covers", !cov).apply();
            if (cov) ivCover.setVisibility(View.GONE);
            d.dismiss();
        }));
        box.addView(settingRow("Copia de seguridad: exportar favoritas", () -> {
            d.dismiss();
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/json");
            i.putExtra(Intent.EXTRA_TITLE, "AVRadio_favoritas.json");
            try { startActivityForResult(i, EXPORT_FAVS); }
            catch (Exception e) { exportToDownloads(); }
        }));
        box.addView(settingRow("Copia de seguridad: importar favoritas", () -> {
            d.dismiss();
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(Intent.createChooser(i, "Elige la copia de AVRadio"), IMPORT_FAVS);
        }));
        if (isAdmin()) {
            TextView ah = Ui.text(this, "ADMINISTRADOR", 12, Ui.WARM, true);
            ah.setLetterSpacing(0.2f);
            ah.setPadding(Ui.dp(this, 4), Ui.dp(this, 18), 0, Ui.dp(this, 2));
            box.addView(ah);
            final boolean test = Updater.testChannel(this);
            box.addView(settingRow(test ? "Actualizaciones: canal de PRUEBAS" : "Actualizaciones: canal ESTABLE", () -> {
                sp.edit().putBoolean("testChannel", !test).apply();
                d.dismiss();
                Toast.makeText(this, !test ? "Recibirás todas las versiones de prueba" : "Solo recibirás versiones estables", Toast.LENGTH_LONG).show();
                checkUpdate(false);
            }));
            ReceptionLog rl = ReceptionLog.get(this);
            TextView rc = Ui.text(this, "Registros de recepción: " + rl.size() + "  ·  pendientes de enviar a FMLIST: "
                    + rl.pending() + "  ·  API FMLIST: " + (FmlistApi.available() ? "conectada" : "pendiente"), 11, Ui.TEXT_3, false);
            rc.setPadding(Ui.dp(this, 4), Ui.dp(this, 6), Ui.dp(this, 4), Ui.dp(this, 2));
            box.addView(rc);
            box.addView(settingRow("Volver a pedir datos al sintonizador", () -> { radio.requestAll(); d.dismiss(); }));
            box.addView(settingRow("Ver registro técnico", () -> { d.dismiss(); showLog(); }));
            box.addView(settingRow("Salir del modo administrador", () -> {
                prefs.edit().putBoolean("admin", false).apply();
                d.dismiss();
                Toast.makeText(this, "Modo administrador desactivado", Toast.LENGTH_SHORT).show();
            }));
        }
        show(d);
    }

    private LinearLayout dialogBox(String title, String sub) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 20);
        box.setPadding(p, p, p, p);
        box.setBackground(Ui.rounded(Ui.CARD, Ui.dp(this, 20), Ui.LINE, 1));
        box.addView(Ui.text(this, title, 22, Ui.TEXT, true));
        if (sub != null) {
            TextView v = Ui.text(this, sub, 13, Ui.TEXT_2, false);
            v.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 10));
            box.addView(v);
        }
        return box;
    }

    /** Mete un cuadro largo en un panel que se puede desplazar. */
    private View scrollable(LinearLayout box) {
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(true);
        sv.addView(box);
        return sv;
    }

    private void show(AlertDialog d) {
        d.show();
        if (d.getWindow() != null) d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
    }

    private TextView settingRow(String s, Runnable r) {
        TextView t = Ui.text(this, s, 16, Ui.TEXT, false);
        t.setPadding(Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14));
        t.setBackground(Ui.rounded(Ui.CARD_ON, Ui.dp(this, 14), Ui.LINE, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 8);
        t.setLayoutParams(lp);
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private void addCtrl(LinearLayout parent, int type, boolean big, View.OnClickListener l) {
        ControlButton b = new ControlButton(this, type, big);
        b.setOnClickListener(l);
        int s = Ui.dp(this, big ? 80 : 64);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(s, s);
        p.setMargins(Ui.dp(this, 10), 0, Ui.dp(this, 10), 0);
        p.gravity = Gravity.CENTER_VERTICAL;
        parent.addView(b, p);
    }

    private LinearLayout.LayoutParams centered(int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = Ui.dp(this, topDp);
        p.gravity = Gravity.CENTER_HORIZONTAL;
        return p;
    }

    private LinearLayout.LayoutParams chipLp() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(Ui.dp(this, 5), 0, Ui.dp(this, 5), 0);
        return p;
    }

    private TextView pill(String s, boolean accent) {
        TextView t = Ui.text(this, s, 13, accent ? Color.WHITE : Ui.TEXT_2, true);
        t.setLetterSpacing(0.06f);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Ui.dp(this, 14), Ui.dp(this, 8), Ui.dp(this, 14), Ui.dp(this, 8));
        if (accent) {
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{Ui.ACCENT_2, Ui.ACCENT});
            g.setCornerRadius(Ui.dp(this, 18));
            t.setBackground(g);
        } else {
            t.setBackground(Ui.rounded(Ui.CARD, Ui.dp(this, 18), Ui.LINE, Ui.dp(this, 1)));
        }
        return t;
    }

    private void chip(TextView t, String s, boolean on, int onColor) {
        t.setText(s);
        t.setTextColor(on ? onColor : Ui.TEXT_3);
        t.setBackground(Ui.rounded(Ui.CARD, Ui.dp(this, 18),
                on ? Color.argb(140, Color.red(onColor), Color.green(onColor), Color.blue(onColor)) : Ui.LINE,
                Ui.dp(this, 1)));
    }

    // --- Actualización y registro ---

    private void checkUpdate(final boolean manual) {
        if (manual) Toast.makeText(this, "Buscando actualización…", Toast.LENGTH_SHORT).show();
        updater.check((remote, error) -> {
            if (remote > Updater.localVersion()) {
                updateBanner.setVisibility(View.VISIBLE);
                if (manual) startUpdate();
            } else if (manual) {
                Toast.makeText(this, error != null ? error : "Ya tienes la última versión", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void startUpdate() {
        Toast.makeText(this, "Descargando actualización…", Toast.LENGTH_LONG).show();
        updater.downloadAndInstall();
    }

    private void showLog() {
        ScrollView sv = new ScrollView(this);
        TextView t = Ui.text(this, log.toString(), 12, Ui.TEXT_2, false);
        t.setTypeface(Typeface.MONOSPACE);
        int p = Ui.dp(this, 16);
        t.setPadding(p, p, p, p);
        sv.addView(t);
        new AlertDialog.Builder(this).setTitle("Registro técnico").setView(sv)
                .setPositiveButton("Cerrar", null).show();
    }

    private void addLog(String line) {
        String t = new SimpleDateFormat("HH:mm:ss", Locale.ROOT).format(new Date());
        log.insert(0, t + "  " + line + "\n");
        if (++logLines > 300) {
            int cut = log.lastIndexOf("\n", log.length() - 2);
            if (cut > 0) log.setLength(cut + 1);
            logLines--;
        }
    }

    private static String hex(int pi) { return String.format(Locale.ROOT, "%04X", pi); }

    private static String formatFreq(int f) { return String.format(Locale.ROOT, "%.1f", f / 100.0); }
}
