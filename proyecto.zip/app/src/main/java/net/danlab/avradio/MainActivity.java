package net.danlab.avradio;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Versión 0.1: pantalla de pruebas para comprobar que hablamos con el sintonizador. */
public class MainActivity extends Activity {

    private final RadioLink radio = new RadioLink();
    private TextView tvFreq, tvPs, tvPi, tvRt, tvAf, tvLog;
    private boolean afOn = false;
    private final StringBuilder log = new StringBuilder();
    private int logLines = 0;

    private final Handler handler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {
            onRadioMessage(msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        String err = radio.open(handler);
        if (err == null) {
            addLog("Conectado con el sintonizador ✔");
        } else {
            addLog("ERROR al conectar: " + err);
        }
    }

    @Override
    protected void onDestroy() {
        radio.close();
        super.onDestroy();
    }

    // ---------- Mensajes que llegan del sintonizador ----------

    private void onRadioMessage(Message msg) {
        String obj = msg.obj == null ? "" : String.valueOf(msg.obj);
        switch (msg.what) {
            case RadioLink.MSG_RADIO_INFO:
                if (msg.arg1 == 2) {
                    tvFreq.setText(formatFreq(msg.arg2));
                    if (msg.obj instanceof String) tvPs.setText(((String) msg.obj).trim());
                }
                break;
            case RadioLink.MSG_RDS: {
                int pi = (msg.arg1 >> 16) & 0xFFFF;
                tvPi.setText("PI: " + (pi == 0 ? "----" : String.format(Locale.ROOT, "%04X", pi)));
                afOn = (msg.arg1 & 64) == 64;
                tvAf.setText(afOn ? "AF: ACTIVADO" : "AF: desactivado");
                tvAf.setTextColor(afOn ? Color.rgb(80, 220, 120) : Color.GRAY);
                break;
            }
            case RadioLink.MSG_RDS_TEXT:
                if (msg.obj instanceof String) tvRt.setText((String) msg.obj);
                break;
        }
        addLog(msg.what + " | " + msg.arg1 + " | " + msg.arg2 + (obj.isEmpty() ? "" : " | " + obj));
    }

    private static String formatFreq(int f) {
        return String.format(Locale.ROOT, "%.1f MHz", f / 100.0);
    }

    private void addLog(String line) {
        String t = new SimpleDateFormat("HH:mm:ss", Locale.ROOT).format(new Date());
        log.insert(0, t + "  " + line + "\n");
        logLines++;
        if (logLines > 200) {
            int cut = log.lastIndexOf("\n", log.length() - 2);
            if (cut > 0) log.setLength(cut + 1);
            logLines--;
        }
        if (tvLog != null) tvLog.setText(log);
    }

    // ---------- Interfaz ----------

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(18, 20, 24));
        root.setPadding(24, 24, 24, 24);

        TextView title = text("AVRadio · v0.1 pruebas", 18, Color.GRAY);
        root.addView(title);
        TextView credit = text("Creado por DanLab", 14, Color.rgb(110, 110, 110));
        root.addView(credit);

        tvFreq = text("--.- MHz", 56, Color.WHITE);
        tvFreq.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(tvFreq);
        tvPs = text("", 32, Color.rgb(90, 200, 250));
        root.addView(tvPs);
        tvPi = text("PI: ----", 22, Color.LTGRAY);
        root.addView(tvPi);
        tvAf = text("AF: ?", 22, Color.GRAY);
        root.addView(tvAf);
        tvRt = text("", 18, Color.LTGRAY);
        root.addView(tvRt);

        LinearLayout row1 = row();
        row1.addView(button("|◀◀ Buscar", v -> radio.seekPrev()));
        row1.addView(button("◀ Paso", v -> radio.stepPrev()));
        row1.addView(button("Paso ▶", v -> radio.stepNext()));
        row1.addView(button("Buscar ▶▶|", v -> radio.seekNext()));
        root.addView(row1);

        LinearLayout row2 = row();
        row2.addView(button("Sonar radio", v -> { radio.requestRadioSource(); addLog("Pedida fuente radio"); }));
        row2.addView(button("Rock FM 89.8", v -> radio.tune(8980)));
        row2.addView(button("AF on/off", v -> radio.setAf(!afOn)));
        root.addView(row2);

        TextView logTitle = text("Registro (lo más nuevo arriba):", 16, Color.GRAY);
        logTitle.setPadding(0, 24, 0, 8);
        root.addView(logTitle);

        ScrollView sv = new ScrollView(this);
        tvLog = text("", 13, Color.rgb(170, 170, 170));
        tvLog.setTypeface(Typeface.MONOSPACE);
        tvLog.setGravity(Gravity.START);
        sv.addView(tvLog);
        root.addView(sv, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
    }

    private TextView text(String s, int sp, int color) {
        TextView tv = new TextView(this);
        tv.setText(s);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        tv.setPadding(0, 6, 0, 6);
        return tv;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setPadding(0, 16, 0, 0);
        return r;
    }

    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        b.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        return b;
    }
}
