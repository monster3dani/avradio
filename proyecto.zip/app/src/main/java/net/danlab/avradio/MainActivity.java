package net.danlab.avradio;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TreeMap;

/** AVRadio · Creado por DanLab */
public class MainActivity extends Activity implements LogoStore.Listener {

    private static final int PICK_LOGO = 41;
    private static final String[] PTY = {"", "Noticias", "Actualidad", "Información",
            "Deportes", "Educación", "Teatro", "Cultura", "Ciencia", "Variado",
            "Música pop", "Rock", "Música ligera", "Clásica ligera", "Clásica",
            "Otra música", "Tiempo", "Economía", "Infantil", "Sociedad",
            "Religión", "Llamadas", "Viajes", "Ocio", "Jazz", "Country",
            "Música nacional", "Oldies", "Folk", "Documental", "Prueba alarma", "Alarma"};

    private static class Preset { int freq; String ps = ""; String pi = ""; }

    /** true mientras AVRadio está en pantalla (para no mostrar el aviso emergente encima). */
    public static boolean visible;
    private static final int EXPORT_FAVS = 42, IMPORT_FAVS = 43;
    private RadioHub hub;
    private RadioLink radio;
    private CoverArt covers;
    private android.widget.ImageView ivCover;
    private Updater updater;
    private Favorites favs;
    private LogoStore logos;
    private final Handler ui = new Handler(Looper.getMainLooper());

    /** Emisoras que guarda el sintonizador (lista de emisoras disponibles). */
    private final TreeMap<Integer, Preset> mcu = new TreeMap<>();
    private int currentFreq = 0;
    private String currentPs = "";
    private boolean afOn, taOn, stereo, scanning;
    private String pendingLogoKey, pendingLogoName;

    // Vistas
    private CarouselView carousel;
    private TextView tvName, tvFreq, tvPty, tvRt, chipAf, chipTa, chipSt, tvStar, tvStarLabel, updateBanner, tvFavHint;
    private TunerScaleView scale;
    private LinearLayout stationListBox, favDots;
    private FavPager favPager;
    private final List<StationTileView> favTiles = new ArrayList<>();
    private static final int PER_PAGE = 8;
    private AmbientBarsView bars;
    private android.content.SharedPreferences prefs;
    private boolean restoredLast, welcomeScan;
    private AlertDialog stationDialog;

    private final StringBuilder log = new StringBuilder();
    private int logLines;

    private final Handler handler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) { onRadioMessage(msg); }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Ui.BG_TOP);
        getWindow().setNavigationBarColor(Ui.BG_BOTTOM);
        updater = new Updater(this);
        prefs = getSharedPreferences("avradio", MODE_PRIVATE);
        favs = Favorites.get(this);
        covers = new CoverArt();
        logos = new LogoStore(this, this);
        buildUi();
        RadioService.start(this);
        hub = RadioHub.get(this);
        String err = hub.start();
        radio = hub.link();
        hub.addListener(handler);
        addLog(err == null ? "Conectado con el sintonizador" : "ERROR al conectar: " + err);
        if (err == null) {
            radio.requestRadioSource();
            radio.requestAll();
        } else tvName.setText("Sin sintonizador");
        refreshAll();
        checkUpdate(false);
        // Primera vez: si no hay emisoras, ofrecer buscarlas (esperamos a que llegue la lista del sintonizador)
        if (err == null && !prefs.getBoolean("welcomed", false)) ui.postDelayed(this::maybeWelcome, 4500);
    }

    private void maybeWelcome() {
        if (isFinishing() || prefs.getBoolean("welcomed", false)) return;
        prefs.edit().putBoolean("welcomed", true).apply();
        if (!favs.isEmpty()) {
            Toast.makeText(this, "Bienvenido a AVRadio · Se han importado " + favs.all().size()
                    + " emisoras de tu radio", Toast.LENGTH_LONG).show();
            return;
        }
        LinearLayout box = dialogBox("Bienvenido a AVRadio",
                "Creado por DanLab\n\nTodavía no tienes emisoras guardadas. ¿Buscamos las que se reciben en tu zona? "
                        + "Tarda unos segundos y se guardarán como favoritas.");
        final AlertDialog d = new AlertDialog.Builder(this).setView(box).setCancelable(true).create();
        box.addView(settingRow("Buscar emisoras de mi zona", () -> {
            d.dismiss();
            welcomeScan = true;
            scanning = true;
            mcu.clear();
            radio.autoStore();
            Toast.makeText(this, "Buscando emisoras… no toques la radio unos segundos", Toast.LENGTH_LONG).show();
        }));
        box.addView(settingRow("Ahora no (podrás hacerlo en «Emisoras»)", d::dismiss));
        show(d);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (radio.isOpen()) radio.requestRadioSource();
        if (bars != null) bars.setRunning(true);
        visible = true;
    }

    @Override
    protected void onPause() {
        super.onPause();
        visible = false;
        if (bars != null) bars.setRunning(false);
    }

    @Override
    protected void onDestroy() {
        if (hub != null) hub.removeListener(handler);
        super.onDestroy();
    }

    @Override
    public void onLogoReady(String key) { refreshAll(); }

    // ===================== Datos del sintonizador =====================

    private void onRadioMessage(Message msg) {
        String obj = msg.obj == null ? "" : String.valueOf(msg.obj);
        addLog(msg.what + " | " + msg.arg1 + " | " + msg.arg2 + (obj.isEmpty() ? "" : " | " + obj));
        switch (msg.what) {
            case RadioLink.MSG_RADIO_INFO:
                if (msg.arg1 == 2) {
                    if (msg.arg2 != currentFreq) {
                        currentFreq = msg.arg2;
                        currentPs = "";
                        tvRt.setText("");
                        ivCover.setVisibility(View.GONE);
                        tvPty.setVisibility(View.INVISIBLE);
                    }
                    scale.setFreq(currentFreq);
                    refreshAll();
                } else if (msg.arg1 == 0) {
                    stereo = (msg.arg2 & 16) == 16;
                    refreshChips();
                }
                break;
            case RadioLink.MSG_RDS: {
                afOn = (msg.arg1 & 64) == 64;
                taOn = (msg.arg1 & 32) == 32;
                int pty = msg.arg2;
                if (pty > 0 && pty < PTY.length) {
                    tvPty.setText(PTY[pty].toUpperCase(Locale.ROOT));
                    tvPty.setVisibility(View.VISIBLE);
                }
                if (msg.obj instanceof String && !((String) msg.obj).trim().isEmpty()) {
                    String ps = ((String) msg.obj).trim();
                    if (!ps.equals(currentPs)) { currentPs = ps; refreshAll(); }
                }
                refreshChips();
                break;
            }
            case RadioLink.MSG_PRESET: {
                int index = msg.arg1 & 0xFF;
                int pi = (msg.arg1 >> 16) & 0xFFFF;
                Preset p = new Preset();
                p.freq = msg.arg2;
                p.ps = msg.obj instanceof String ? ((String) msg.obj).trim() : "";
                p.pi = pi == 0 ? "" : hex(pi);
                mcu.put(index, p);
                ui.removeCallbacks(afterPresets);
                ui.postDelayed(afterPresets, 2500);
                refreshAll();
                break;
            }
            case RadioLink.MSG_RDS_TEXT:
                if (msg.obj instanceof String) {
                    final String rt = ((String) msg.obj).trim();
                    if (!rt.equals(tvRt.getText().toString())) {
                        tvRt.setText(rt);
                        tvRt.setSelected(true);
                        if (prefs.getBoolean("covers", true)) covers.find(rt, (forText, cover) -> {
                            if (!forText.equals(tvRt.getText().toString())) return;
                            if (cover != null) { ivCover.setImageBitmap(cover); ivCover.setVisibility(View.VISIBLE); }
                            else ivCover.setVisibility(View.GONE);
                        });
                    }
                }
                break;
        }
    }

    /** Cuando el sintonizador termina de mandar su lista. */
    private final Runnable afterPresets = () -> {
        // La primera vez, importamos sus emisoras como favoritas para no empezar vacío
        if (!favs.importedOnce() && favs.isEmpty()) {
            for (Preset p : mcu.values()) if (p.freq > 0 && !p.ps.isEmpty()) favs.add(p.freq, p.ps, p.pi);
            favs.sortByFreq();
            favs.setImported();
            refreshAll();
        }
        if (scanning) {
            scanning = false;
            if (welcomeScan) {
                welcomeScan = false;
                int n = 0;
                for (Preset p : mcu.values()) if (p.freq > 0 && favs.find(p.freq, p.pi) == null) { favs.add(p.freq, p.ps, p.pi); n++; }
                favs.sortByFreq();
                refreshAll();
                Toast.makeText(this, n > 0 ? "¡Listo! Se han guardado " + n + " emisoras en favoritas"
                        : "No se han encontrado emisoras. Prueba en otro sitio con mejor cobertura", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Búsqueda terminada", Toast.LENGTH_SHORT).show();
            }
        }
        refreshStationList();
    };

    private Preset mcuFor(int freq) {
        for (Preset p : mcu.values()) if (p.freq == freq) return p;
        return null;
    }

    private String currentPi() {
        Preset p = mcuFor(currentFreq);
        if (p != null && !p.pi.isEmpty()) return p.pi;
        Favorites.Station f = favs.find(currentFreq, "");
        return f != null ? f.pi : "";
    }

    private String currentName() {
        Favorites.Station cf = favs.find(currentFreq, currentPi());
        if (cf != null && cf.custom) return cf.name;
        if (!currentPs.isEmpty()) return currentPs;
        Favorites.Station f = favs.find(currentFreq, "");
        if (f != null && !f.name.isEmpty()) return f.name;
        Preset p = mcuFor(currentFreq);
        return p != null ? p.ps : "";
    }

    private void stepFavorite(int dir) {
        List<Favorites.Station> l = favs.all();
        if (l.isEmpty()) { if (dir > 0) radio.seekNext(); else radio.seekPrev(); return; }
        Favorites.Station target = null;
        if (dir > 0) { for (Favorites.Station s : l) if (s.freq > currentFreq) { target = s; break; } }
        else { for (int i = l.size() - 1; i >= 0; i--) if (l.get(i).freq < currentFreq) { target = l.get(i); break; } }
        if (target == null) target = dir > 0 ? l.get(0) : l.get(l.size() - 1);
        radio.tune(target.freq);
    }

    // ===================== Refresco de la interfaz =====================

    private void refreshAll() {
        if (tvName == null) return;
        String name = currentName();
        String pi = currentPi();
        Favorites.Station fav = favs.find(currentFreq, pi);
        if (fav != null && !pi.isEmpty()) favs.updateFreqIfMoved(currentFreq, pi);

        tvName.setText(name.isEmpty() ? (currentFreq == 0 ? "AVRadio" : "Buscando RDS…") : name);
        tvName.setTextColor(name.isEmpty() ? Ui.TEXT_3 : Ui.TEXT);
        tvFreq.setText(currentFreq == 0 ? "" : formatFreq(currentFreq) + "  MHz");
        tvStar.setText(fav != null ? "★" : "☆");
        tvStar.setTextColor(fav != null ? Ui.WARM : Ui.TEXT_2);
        tvStarLabel.setText(fav != null ? "Favorita" : "Guardar");
        tvStarLabel.setTextColor(fav != null ? Ui.WARM : Ui.TEXT_3);

        // Carrusel: favoritas + la actual si no está guardada
        List<CarouselView.Item> items = new ArrayList<>();
        int sel = 0;
        for (Favorites.Station s : favs.all()) {
            CarouselView.Item it = new CarouselView.Item();
            it.freq = s.freq;
            it.name = s.name;
            it.key = s.key();
            it.logo = logos.get(it.key, s.name);
            it.favorite = true;
            if (s == fav) sel = items.size();
            items.add(it);
        }
        if (fav == null && currentFreq > 0) { sel = items.size(); items.add(tempItem(name, pi)); }
        carousel.setItems(items, sel);
        if (bars != null) {
            bars.setColor(name.isEmpty() ? Ui.ACCENT : Ui.stationColor(Favorites.keyFor(pi, name)));
            bars.setEnergy(name.isEmpty() ? 0.25f : stereo ? 1f : 0.55f);
        }

        List<Integer> marks = new ArrayList<>();
        for (Favorites.Station s : favs.all()) marks.add(s.freq);
        scale.setMarks(marks);
        refreshFavStrip(fav);
    }

    private CarouselView.Item tempItem(String name, String pi) {
        CarouselView.Item it = new CarouselView.Item();
        it.freq = currentFreq;
        it.name = name;
        it.key = Favorites.keyFor(pi, name);
        it.logo = name.isEmpty() ? null : logos.get(it.key, name);
        it.favorite = false;
        return it;
    }

    private void refreshChips() {
        chip(chipAf, "AF", afOn, Ui.OK);
        chip(chipTa, "TA", taOn, Ui.WARM);
        chip(chipSt, stereo ? "ESTÉREO" : "MONO", stereo, Ui.OK);
    }

    private int lastFavFreq = -1;

    private void refreshFavStrip(Favorites.Station current) {
        List<Favorites.Station> l = favs.all();
        int pages = Math.max(1, (l.size() + PER_PAGE - 1) / PER_PAGE);
        if (favPager.getChildCount() != pages) buildFavPages(pages);
        tvFavHint.setText(l.isEmpty() ? "Toca la estrella para guardar la emisora que suena"
                : "Favoritas · desliza para ver más · mantén pulsada para opciones");
        for (int i = 0; i < favTiles.size(); i++) {
            StationTileView t = favTiles.get(i);
            if (i < l.size()) {
                Favorites.Station s = l.get(i);
                t.set(i + 1, s.name.isEmpty() ? "—" : s.name, formatFreq(s.freq), s.key(),
                        logos.get(s.key(), s.name), s == current);
                t.setTag(s);
            } else {
                t.setEmpty();
                t.setTag(null);
            }
        }
        // Al cambiar de emisora, ir a la página donde está
        if (current != null && current.freq != lastFavFreq) {
            int idx = l.indexOf(current);
            if (idx >= 0 && idx / PER_PAGE != favPager.getPage()) favPager.setPage(idx / PER_PAGE, true);
        }
        lastFavFreq = current != null ? current.freq : 0;
        refreshDots();
    }

    private void buildFavPages(int pages) {
        favPager.removeAllViews();
        favTiles.clear();
        for (int p = 0; p < pages; p++) {
            LinearLayout page = new LinearLayout(this);
            page.setOrientation(LinearLayout.VERTICAL);
            for (int r = 0; r < 2; r++) {
                LinearLayout row = new LinearLayout(this);
                for (int c = 0; c < 4; c++) {
                    final StationTileView t = new StationTileView(this);
                    favTiles.add(t);
                    t.setOnClickListener(v -> {
                        Object o = t.getTag();
                        if (o instanceof Favorites.Station) radio.tune(((Favorites.Station) o).freq);
                    });
                    t.setOnLongClickListener(v -> {
                        Object o = t.getTag();
                        if (!(o instanceof Favorites.Station)) return false;
                        Favorites.Station s = (Favorites.Station) o;
                        stationMenu(s.freq, s.name, s.pi);
                        return true;
                    });
                    LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, Ui.dp(this, 124), 1f);
                    int m = Ui.dp(this, 4);
                    tl.setMargins(m, m, m, m);
                    row.addView(t, tl);
                }
                page.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            }
            favPager.addView(page);
        }
        if (favPager.getPage() >= pages) favPager.setPage(pages - 1, false);
    }

    private void refreshDots() {
        favDots.removeAllViews();
        int pages = favPager.pages();
        if (pages <= 1) return;
        for (int p = 0; p < pages; p++) {
            final int pg = p;
            boolean on = p == favPager.getPage();
            View dot = new View(this);
            dot.setBackground(Ui.rounded(on ? Ui.ACCENT : Ui.LINE, Ui.dp(this, 4), 0, 0));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(this, on ? 22 : 8), Ui.dp(this, 8));
            lp.setMargins(Ui.dp(this, 4), 0, Ui.dp(this, 4), 0);
            dot.setOnClickListener(v -> favPager.setPage(pg, true));
            favDots.addView(dot, lp);
        }
    }

    // ===================== Interfaz =====================

    private void buildUi() {
        FrameLayout frame = new FrameLayout(this);
        frame.addView(new BackgroundView(this), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        frame.addView(root, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        int pad = Ui.dp(this, 18);
        root.setPadding(pad, Ui.dp(this, 12), pad, Ui.dp(this, 12));

        // --- Barra superior ---
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        TextView title = Ui.text(this, "AVRadio", 22, Ui.TEXT, true);
        title.setLetterSpacing(0.08f);
        LinearLayout byRow = new LinearLayout(this);
        byRow.setGravity(Gravity.CENTER_VERTICAL);
        android.widget.ImageView dl = new android.widget.ImageView(this);
        dl.setImageResource(R.drawable.danlab);
        dl.setAlpha(0.55f);
        byRow.addView(dl, new LinearLayout.LayoutParams(Ui.dp(this, 13), Ui.dp(this, 13)));
        TextView by = Ui.text(this, "  by DanLab", 11, Ui.TEXT_3, false);
        by.setLetterSpacing(0.15f);
        byRow.addView(by);
        brand.addView(title);
        brand.addView(byRow);
        brand.setOnLongClickListener(v -> { showLog(); return true; });
        top.addView(brand, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView list = pill("Emisoras", false);
        list.setOnClickListener(v -> showStationList());
        top.addView(list, chipLp());
        TextView settings = pill("Ajustes", false);
        settings.setOnClickListener(v -> showSettings());
        top.addView(settings);
        root.addView(top);

        updateBanner = pill("Nueva versión disponible · Actualizar", true);
        updateBanner.setVisibility(View.GONE);
        updateBanner.setOnClickListener(v -> startUpdate());
        root.addView(updateBanner, centered(8));

        // --- Zona central: indicadores | carrusel | favorita ---
        FrameLayout hero = new FrameLayout(this);
        bars = new AmbientBarsView(this);
        bars.setEnabledBars(prefs.getBoolean("bars", true));
        hero.addView(bars, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 150), Gravity.BOTTOM));
        LinearLayout heroRow = new LinearLayout(this);
        heroRow.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        left.setGravity(Gravity.CENTER);
        chipAf = pill("AF", false);
        chipTa = pill("TA", false);
        chipSt = pill("ESTÉREO", false);
        chipAf.setOnClickListener(v -> radio.setAf(!afOn));
        left.addView(chipAf, sideLp());
        left.addView(chipTa, sideLp());
        left.addView(chipSt, sideLp());
        heroRow.addView(left, new LinearLayout.LayoutParams(Ui.dp(this, 92), ViewGroup.LayoutParams.WRAP_CONTENT));

        carousel = new CarouselView(this);
        carousel.setListener(new CarouselView.Listener() {
            @Override public void onPick(CarouselView.Item item) { radio.tune(item.freq); }
            @Override public void onLongPress(CarouselView.Item item) { stationMenu(item.freq, item.name, currentPi()); }
        });
        heroRow.addView(carousel, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setGravity(Gravity.CENTER);
        tvStar = Ui.text(this, "☆", 48, Ui.TEXT_2, false);
        tvStar.setGravity(Gravity.CENTER);
        tvStarLabel = Ui.text(this, "Guardar", 12, Ui.TEXT_3, true);
        tvStarLabel.setGravity(Gravity.CENTER);
        tvStarLabel.setLetterSpacing(0.08f);
        right.addView(tvStar);
        right.addView(tvStarLabel);
        right.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 10));
        right.setBackground(Ui.rounded(Ui.CARD, Ui.dp(this, 18), Ui.LINE, Ui.dp(this, 1)));
        right.setOnClickListener(v -> toggleFavorite());
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(Ui.dp(this, 84), ViewGroup.LayoutParams.WRAP_CONTENT);
        rl.leftMargin = Ui.dp(this, 8);
        heroRow.addView(right, rl);

        hero.addView(heroRow, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        // La zona central se adapta al espacio libre, así nada se sale de la pantalla
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        hl.topMargin = Ui.dp(this, 4);
        root.addView(hero, hl);

        tvName = Ui.text(this, "AVRadio", 36, Ui.TEXT, true);
        tvName.setGravity(Gravity.CENTER);
        tvName.setSingleLine(true);
        tvName.setEllipsize(TextUtils.TruncateAt.END);
        root.addView(tvName, centered(2));

        tvFreq = Ui.text(this, "", 19, Ui.ACCENT, false);
        tvFreq.setGravity(Gravity.CENTER);
        tvFreq.setLetterSpacing(0.06f);
        root.addView(tvFreq, centered(6));

        // Tipo de programa y texto RDS: siempre ocupan su sitio, aparezcan o no
        tvPty = Ui.text(this, " ", 12, Ui.WARM, true);
        tvPty.setLetterSpacing(0.2f);
        tvPty.setGravity(Gravity.CENTER);
        tvPty.setVisibility(View.INVISIBLE);
        root.addView(tvPty, centered(6));

        LinearLayout rtRow = new LinearLayout(this);
        rtRow.setGravity(Gravity.CENTER);
        ivCover = new android.widget.ImageView(this);
        ivCover.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
        ivCover.setClipToOutline(true);
        ivCover.setBackground(Ui.rounded(Ui.CARD, Ui.dp(this, 8), Ui.LINE, 1));
        ivCover.setVisibility(View.GONE);
        LinearLayout.LayoutParams cvl = new LinearLayout.LayoutParams(Ui.dp(this, 48), Ui.dp(this, 48));
        cvl.rightMargin = Ui.dp(this, 12);
        rtRow.addView(ivCover, cvl);
        tvRt = Ui.text(this, " ", 15, Ui.TEXT_2, false);
        tvRt.setGravity(Gravity.CENTER);
        tvRt.setSingleLine(true);
        tvRt.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        tvRt.setMarqueeRepeatLimit(-1);
        tvRt.setHorizontalFadingEdgeEnabled(true);
        rtRow.addView(tvRt, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams rrl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 52));
        rrl.topMargin = Ui.dp(this, 4);
        root.addView(rtRow, rrl);

        // --- Dial ---
        scale = new TunerScaleView(this);
        scale.setListener(f -> radio.tune(f));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 80));
        slp.topMargin = Ui.dp(this, 6);
        root.addView(scale, slp);

        // --- Controles ---
        LinearLayout ctr = new LinearLayout(this);
        ctr.setGravity(Gravity.CENTER);
        addCtrl(ctr, ControlButton.SEEK_PREV, true, v -> seek(false));
        addCtrl(ctr, ControlButton.STEP_PREV, false, v -> radio.stepPrev());
        addCtrl(ctr, ControlButton.STEP_NEXT, false, v -> radio.stepNext());
        addCtrl(ctr, ControlButton.SEEK_NEXT, true, v -> seek(true));
        root.addView(ctr, centered(4));

        // --- Favoritas (4 x 2 por página) ---
        tvFavHint = Ui.text(this, "", 12, Ui.TEXT_3, false);
        tvFavHint.setLetterSpacing(0.05f);
        root.addView(tvFavHint, centered(12));
        favPager = new FavPager(this);
        favPager.setListener(p -> refreshDots());
        LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        gl.topMargin = Ui.dp(this, 4);
        root.addView(favPager, gl);
        favDots = new LinearLayout(this);
        favDots.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 14));
        dlp.topMargin = Ui.dp(this, 6);
        root.addView(favDots, dlp);
        buildFavPages(1);

        refreshChips();
        setContentView(frame);
    }

    private void renameDialog(final Favorites.Station st) {
        final android.widget.EditText ed = new android.widget.EditText(this);
        ed.setText(st.name);
        ed.setSingleLine(true);
        ed.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this).setTitle("Nombre de la emisora")
                .setMessage("Déjalo vacío para volver a usar el nombre que manda la emisora.")
                .setView(ed)
                .setPositiveButton("Guardar", (dd, w) -> { favs.rename(st, ed.getText().toString()); refreshAll(); })
                .setNegativeButton("Cancelar", null).show();
    }

    private LinearLayout orderList;

    /** Ordenar, renombrar y quitar favoritas. */
    private void showOrder() {
        LinearLayout box = dialogBox("Tus favoritas", "Usa las flechas para cambiar el orden. El orden también es el de los botones del volante.");
        orderList = new LinearLayout(this);
        orderList.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this);
        sv.addView(orderList);
        box.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 470)));
        final AlertDialog d = new AlertDialog.Builder(this).setView(box).create();
        box.addView(settingRow("Ordenar por frecuencia", () -> { favs.sortByFreq(); fillOrder(); refreshAll(); }));
        box.addView(settingRow("Hecho", d::dismiss));
        fillOrder();
        show(d);
    }

    private void fillOrder() {
        orderList.removeAllViews();
        List<Favorites.Station> l = favs.all();
        for (int i = 0; i < l.size(); i++) {
            final Favorites.Station st = l.get(i);
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.dp(this, 10), Ui.dp(this, 6), Ui.dp(this, 6), Ui.dp(this, 6));
            row.setBackground(Ui.rounded(Ui.CARD_ON, Ui.dp(this, 14), Ui.LINE, 1));
            row.addView(Ui.text(this, String.valueOf(i + 1), 15, Ui.TEXT_2, true),
                    new LinearLayout.LayoutParams(Ui.dp(this, 28), ViewGroup.LayoutParams.WRAP_CONTENT));
            LogoView lv = new LogoView(this, false);
            lv.setStation(st.name.isEmpty() ? "FM" : st.name, st.key());
            lv.setLogo(logos.get(st.key(), st.name));
            row.addView(lv, new LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 40)));
            LinearLayout tx = new LinearLayout(this);
            tx.setOrientation(LinearLayout.VERTICAL);
            tx.setPadding(Ui.dp(this, 10), 0, 0, 0);
            tx.addView(Ui.text(this, st.name.isEmpty() ? "—" : st.name, 16, Ui.TEXT, true));
            tx.addView(Ui.text(this, formatFreq(st.freq) + " MHz", 12, Ui.TEXT_2, false));
            row.addView(tx, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(iconBtn("▲", v -> { favs.move(st, -1); fillOrder(); refreshAll(); }));
            row.addView(iconBtn("▼", v -> { favs.move(st, +1); fillOrder(); refreshAll(); }));
            row.addView(iconBtn("✎", v -> renameDialog(st)));
            row.addView(iconBtn("✕", v -> {
                new AlertDialog.Builder(this).setMessage("¿Quitar " + (st.name.isEmpty() ? "esta emisora" : st.name) + " de favoritas?")
                        .setPositiveButton("Quitar", (dd, w) -> { favs.remove(st); fillOrder(); refreshAll(); })
                        .setNegativeButton("Cancelar", null).show();
            }));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = Ui.dp(this, 6);
            orderList.addView(row, lp);
        }
    }

    private TextView iconBtn(String s, View.OnClickListener l) {
        TextView t = Ui.text(this, s, 20, Ui.TEXT, false);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Ui.rounded(Ui.CARD, Ui.dp(this, 12), Ui.LINE, 1));
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(this, 46), Ui.dp(this, 46));
        lp.leftMargin = Ui.dp(this, 6);
        t.setLayoutParams(lp);
        return t;
    }

    private int pickTheme, pickStyle;

    /** Selector de colores y estilo de fondo, con vista previa. */
    private void showThemes() {
        pickTheme = prefs.getInt("theme", 0);
        pickStyle = Ui.style;
        LinearLayout box = dialogBox("Colores y fondo", "Elige un color ambiente y un estilo de fondo.");
        final BackgroundView prev = new BackgroundView(this);
        prev.preview(pickTheme, pickStyle);
        prev.setClipToOutline(true);
        prev.setBackground(Ui.rounded(Ui.CARD, Ui.dp(this, 16), Ui.LINE, 1));
        box.addView(prev, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 180)));

        final TextView themeName = Ui.text(this, (String) Ui.THEMES[pickTheme][0], 15, Ui.TEXT, true);
        themeName.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 6));
        box.addView(themeName);
        LinearLayout sw = new LinearLayout(this);
        for (int i = 0; i < Ui.THEMES.length; i++) {
            final int t = i;
            View dot = new View(this);
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    new int[]{(Integer) Ui.THEMES[i][5], (Integer) Ui.THEMES[i][1]});
            g.setShape(GradientDrawable.OVAL);
            g.setStroke(Ui.dp(this, 2), Color.argb(90, 255, 255, 255));
            dot.setBackground(g);
            dot.setOnClickListener(v -> {
                pickTheme = t;
                themeName.setText((String) Ui.THEMES[t][0]);
                prev.preview(pickTheme, pickStyle);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(this, 46), Ui.dp(this, 46));
            lp.setMargins(0, 0, Ui.dp(this, 10), 0);
            sw.addView(dot, lp);
        }
        box.addView(sw);

        TextView st = Ui.text(this, "Estilo de fondo", 15, Ui.TEXT, true);
        st.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 6));
        box.addView(st);
        LinearLayout styles = new LinearLayout(this);
        final List<TextView> chips = new ArrayList<>();
        for (int i = 0; i < Ui.STYLES.length; i++) {
            final int k = i;
            final TextView c = pill(Ui.STYLES[i], false);
            chips.add(c);
            c.setOnClickListener(v -> {
                pickStyle = k;
                prev.preview(pickTheme, pickStyle);
                for (int j = 0; j < chips.size(); j++) chips.get(j).setTextColor(j == k ? Ui.ACCENT : Ui.TEXT_2);
            });
            c.setTextColor(i == pickStyle ? Ui.ACCENT : Ui.TEXT_2);
            styles.addView(c, chipLp());
        }
        box.addView(styles);

        final AlertDialog d = new AlertDialog.Builder(this).setView(box).create();
        box.addView(settingRow("Aplicar", () -> {
            prefs.edit().putInt("theme", pickTheme).putInt("bgStyle", pickStyle).apply();
            Ui.loadTheme(this);
            d.dismiss();
            recreate();
        }));
        box.addView(settingRow("Cancelar", d::dismiss));
        show(d);
    }

    private void askOverlay() {
        new AlertDialog.Builder(this).setTitle("Permiso necesario")
                .setMessage("Para que AVRadio pueda abrirse sola al encender el coche, Android necesita que le permitas «mostrarse sobre otras apps».")
                .setPositiveButton("Dar permiso", (dd, w) -> {
                    try {
                        startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + getPackageName())));
                    } catch (Exception ignored) { }
                })
                .setNegativeButton("Ahora no", null).show();
    }

    /** Por si la pantalla no tiene selector de archivos: guarda en Descargas. */
    private void exportToDownloads() {
        try {
            java.io.File dir = getExternalFilesDir(android.os.Environment.DIRECTORY_DOCUMENTS);
            java.io.File f = new java.io.File(dir, "AVRadio_favoritas.json");
            try (java.io.FileOutputStream o = new java.io.FileOutputStream(f)) { o.write(favs.toJson().getBytes("UTF-8")); }
            Toast.makeText(this, "Guardado en " + f.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (Exception e) { Toast.makeText(this, "No se ha podido guardar", Toast.LENGTH_LONG).show(); }
    }

    private void seek(boolean next) {
        if (taOn) Toast.makeText(this, "TA activado: solo se para en emisoras con información de tráfico", Toast.LENGTH_LONG).show();
        if (next) radio.seekNext(); else radio.seekPrev();
    }

    private LinearLayout.LayoutParams sideLp() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, Ui.dp(this, 5), 0, Ui.dp(this, 5));
        return p;
    }

    private void toggleFavorite() {
        if (currentFreq == 0) return;
        String pi = currentPi();
        Favorites.Station f = favs.find(currentFreq, pi);
        if (f != null) {
            favs.remove(f);
            Toast.makeText(this, "Quitada de favoritas", Toast.LENGTH_SHORT).show();
        } else {
            favs.add(currentFreq, currentName(), pi);
            Toast.makeText(this, "Guardada en favoritas", Toast.LENGTH_SHORT).show();
        }
        refreshAll();
    }

    /** Menú de una emisora: guardar/quitar, logo… */
    private void stationMenu(final int freq, final String name, final String pi) {
        final Favorites.Station f = favs.find(freq, pi);
        final String key = f != null ? f.key() : Favorites.keyFor(pi, name);
        LinearLayout box = dialogBox((name.isEmpty() ? "Emisora" : name) + "  ·  " + formatFreq(freq), null);
        final AlertDialog d = new AlertDialog.Builder(this).setView(box).create();
        box.addView(settingRow(f != null ? "Quitar de favoritas" : "Guardar en favoritas", () -> {
            if (f != null) favs.remove(f); else favs.add(freq, name, pi);
            d.dismiss();
            refreshAll();
        }));
        box.addView(settingRow("Elegir logo (imagen de la pantalla)", () -> {
            d.dismiss();
            if (key.isEmpty()) { Toast.makeText(this, "Espera a que salga el nombre de la emisora", Toast.LENGTH_LONG).show(); return; }
            pendingLogoKey = key;
            pendingLogoName = name;
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            startActivityForResult(Intent.createChooser(i, "Elige el logo"), PICK_LOGO);
        }));
        box.addView(settingRow("Buscar el logo otra vez en internet", () -> {
            d.dismiss();
            if (!key.isEmpty()) {
                logos.retry(key, name);
                Toast.makeText(this, "Buscando logo…", Toast.LENGTH_SHORT).show();
            }
        }));
        if (f != null) {
            box.addView(settingRow("Cambiar nombre", () -> { d.dismiss(); renameDialog(f); }));
            box.addView(settingRow("Ordenar favoritas", () -> { d.dismiss(); showOrder(); }));
        }
        box.addView(settingRow("Sintonizar", () -> { d.dismiss(); radio.tune(freq); }));
        show(d);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        if (req == EXPORT_FAVS) {
            try (java.io.OutputStream o = getContentResolver().openOutputStream(data.getData())) {
                o.write(favs.toJson().getBytes("UTF-8"));
                Toast.makeText(this, "Favoritas exportadas", Toast.LENGTH_SHORT).show();
            } catch (Exception e) { Toast.makeText(this, "No se ha podido guardar", Toast.LENGTH_LONG).show(); }
            return;
        }
        if (req == IMPORT_FAVS) {
            try (InputStream in = getContentResolver().openInputStream(data.getData())) {
                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                int added = favs.importJson(bo.toString("UTF-8"));
                refreshAll();
                Toast.makeText(this, "Importadas " + added + " emisoras nuevas", Toast.LENGTH_LONG).show();
            } catch (Exception e) { Toast.makeText(this, "Ese archivo no es una copia de AVRadio", Toast.LENGTH_LONG).show(); }
            return;
        }
        if (req != PICK_LOGO) return;
        try {
            Uri u = data.getData();
            InputStream in = getContentResolver().openInputStream(u);
            Bitmap b = BitmapFactory.decodeStream(in);
            if (in != null) in.close();
            if (b != null) {
                logos.setManual(pendingLogoKey, b);
                Toast.makeText(this, "Logo guardado", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "No se ha podido leer la imagen", Toast.LENGTH_LONG).show();
        }
    }

    // --- Lista de emisoras disponibles ---

    private void showStationList() {
        LinearLayout box = dialogBox("Emisoras disponibles",
                "Las que ha encontrado el sintonizador. Toca para escuchar, ☆ para guardar.");
        stationListBox = new LinearLayout(this);
        stationListBox.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this);
        sv.addView(stationListBox);
        box.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 460)));
        stationDialog = new AlertDialog.Builder(this).setView(box).create();
        box.addView(settingRow("Buscar todas las emisoras de esta zona", () -> {
            new AlertDialog.Builder(this)
                    .setTitle("Buscar emisoras")
                    .setMessage("El sintonizador recorrerá todo el dial (tarda unos segundos). "
                            + "Esto sustituye las presintonías de la radio original, pero tus favoritas de AVRadio no se tocan.")
                    .setPositiveButton("Buscar", (dd, w) -> {
                        scanning = true;
                        mcu.clear();
                        refreshStationList();
                        radio.autoStore();
                        Toast.makeText(this, "Buscando emisoras…", Toast.LENGTH_LONG).show();
                    })
                    .setNegativeButton("Cancelar", null).show();
        }));
        stationDialog.setOnDismissListener(di -> { stationListBox = null; stationDialog = null; });
        refreshStationList();
        show(stationDialog);
    }

    private void refreshStationList() {
        if (stationListBox == null) return;
        stationListBox.removeAllViews();
        TreeMap<Integer, Preset> byFreq = new TreeMap<>();
        for (Preset p : mcu.values()) if (p.freq > 0) byFreq.put(p.freq, p);
        if (byFreq.isEmpty()) {
            TextView t = Ui.text(this, scanning ? "Buscando…" : "Todavía no hay emisoras. Pulsa «Buscar todas las emisoras».", 15, Ui.TEXT_2, false);
            t.setPadding(0, Ui.dp(this, 16), 0, Ui.dp(this, 16));
            stationListBox.addView(t);
            return;
        }
        for (final Preset p : byFreq.values()) {
            final Favorites.Station f = favs.find(p.freq, p.pi);
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8));
            row.setBackground(Ui.rounded(p.freq == currentFreq ? Ui.CARD_ON : Ui.CARD, Ui.dp(this, 14), Ui.LINE, 1));
            LogoView lv = new LogoView(this, false);
            String key = Favorites.keyFor(p.pi, p.ps);
            lv.setStation(p.ps.isEmpty() ? formatFreq(p.freq) : p.ps, key);
            lv.setLogo(p.ps.isEmpty() ? null : logos.get(key, p.ps));
            row.addView(lv, new LinearLayout.LayoutParams(Ui.dp(this, 42), Ui.dp(this, 42)));
            LinearLayout txt = new LinearLayout(this);
            txt.setOrientation(LinearLayout.VERTICAL);
            txt.setPadding(Ui.dp(this, 12), 0, 0, 0);
            txt.addView(Ui.text(this, p.ps.isEmpty() ? "Sin nombre" : p.ps, 17, Ui.TEXT, true));
            txt.addView(Ui.text(this, formatFreq(p.freq) + " MHz" + (p.pi.isEmpty() ? "" : "   ·   PI " + p.pi), 12, Ui.TEXT_2, false));
            row.addView(txt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView star = Ui.text(this, f != null ? "★" : "☆", 26, f != null ? Ui.WARM : Ui.TEXT_2, false);
            star.setPadding(Ui.dp(this, 14), Ui.dp(this, 4), Ui.dp(this, 6), Ui.dp(this, 4));
            star.setOnClickListener(v -> {
                if (f != null) favs.remove(f); else favs.add(p.freq, p.ps, p.pi);
                refreshAll();
                refreshStationList();
            });
            row.addView(star);
            row.setOnClickListener(v -> radio.tune(p.freq));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = Ui.dp(this, 6);
            stationListBox.addView(row, lp);
        }
    }

    // --- Ajustes ---

    private void showSettings() {
        LinearLayout box = dialogBox("AVRadio", "Versión " + BuildConfig.VERSION_NAME + "  ·  Creado por DanLab");
        final AlertDialog d = new AlertDialog.Builder(this).setView(box).create();
        box.addView(settingRow("Colores y fondo", () -> { d.dismiss(); showThemes(); }));
        box.addView(settingRow("Ordenar y renombrar favoritas", () -> { d.dismiss(); showOrder(); }));
        box.addView(settingRow("Buscar actualización", () -> { d.dismiss(); checkUpdate(true); }));
        box.addView(settingRow(afOn ? "Desactivar AF (frecuencias alternativas)" : "Activar AF (frecuencias alternativas)",
                () -> { radio.setAf(!afOn); d.dismiss(); }));
        box.addView(settingRow(taOn ? "Desactivar TA (avisos de tráfico)" : "Activar TA (avisos de tráfico)", () -> {
            d.dismiss();
            if (taOn) { radio.setTa(false); return; }
            new AlertDialog.Builder(this).setTitle("Avisos de tráfico (TA)")
                    .setMessage("Con TA activado, la búsqueda solo se detiene en emisoras que emiten información de tráfico y se salta las demás.")
                    .setPositiveButton("Activar", (dd, w) -> radio.setTa(true))
                    .setNegativeButton("Cancelar", null).show();
        }));
        final android.content.SharedPreferences sp = prefs;
        final boolean barsOn = sp.getBoolean("bars", true);
        box.addView(settingRow(barsOn ? "Quitar barras animadas de fondo" : "Poner barras animadas de fondo", () -> {
            sp.edit().putBoolean("bars", !barsOn).apply();
            bars.setEnabledBars(!barsOn);
            if (!barsOn) bars.setRunning(true);
            d.dismiss();
        }));
        final boolean auto = sp.getBoolean("autostart", true);
        box.addView(settingRow(auto ? "Abrir AVRadio al encender el coche: SÍ" : "Abrir AVRadio al encender el coche: NO", () -> {
            sp.edit().putBoolean("autostart", !auto).apply();
            d.dismiss();
            if (!auto && !RadioService.canDrawOverlays(this)) askOverlay();
        }));
        long acc = sp.getLong("lastAccOn", 0), boot = sp.getLong("lastBoot", 0);
        SimpleDateFormat df = new SimpleDateFormat("dd/MM HH:mm", Locale.ROOT);
        TextView diag = Ui.text(this, "Diagnóstico · último encendido detectado: "
                + (acc > 0 ? df.format(new Date(acc)) : "nunca") + "  ·  último arranque: "
                + (boot > 0 ? df.format(new Date(boot)) : "nunca")
                + "  ·  permiso «sobre otras apps»: " + (RadioService.canDrawOverlays(this) ? "SÍ" : "NO"), 11, Ui.TEXT_3, false);
        diag.setPadding(Ui.dp(this, 4), Ui.dp(this, 6), Ui.dp(this, 4), Ui.dp(this, 2));
        diag.setOnClickListener(v -> { if (!RadioService.canDrawOverlays(this)) { d.dismiss(); askOverlay(); } });
        box.addView(diag);
        final boolean pop = sp.getBoolean("popup", true);
        box.addView(settingRow(pop ? "Aviso de emisora sobre otras apps: SÍ" : "Aviso de emisora sobre otras apps: NO", () -> {
            sp.edit().putBoolean("popup", !pop).apply();
            d.dismiss();
        }));
        final boolean cov = sp.getBoolean("covers", true);
        box.addView(settingRow(cov ? "Carátulas de las canciones: SÍ" : "Carátulas de las canciones: NO", () -> {
            sp.edit().putBoolean("covers", !cov).apply();
            if (cov) ivCover.setVisibility(View.GONE);
            d.dismiss();
        }));
        box.addView(settingRow("Copia de seguridad: exportar favoritas", () -> {
            d.dismiss();
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/json");
            i.putExtra(Intent.EXTRA_TITLE, "AVRadio_favoritas.json");
            try { startActivityForResult(i, EXPORT_FAVS); }
            catch (Exception e) { exportToDownloads(); }
        }));
        box.addView(settingRow("Copia de seguridad: importar favoritas", () -> {
            d.dismiss();
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(Intent.createChooser(i, "Elige la copia de AVRadio"), IMPORT_FAVS);
        }));
        final boolean test = Updater.testChannel(this);
        box.addView(settingRow(test ? "Actualizaciones: canal de PRUEBAS" : "Actualizaciones: canal ESTABLE", () -> {
            sp.edit().putBoolean("testChannel", !test).apply();
            d.dismiss();
            Toast.makeText(this, !test ? "Recibirás todas las versiones de prueba" : "Solo recibirás versiones estables", Toast.LENGTH_LONG).show();
            checkUpdate(false);
        }));
        box.addView(settingRow("Volver a pedir datos al sintonizador", () -> { radio.requestAll(); d.dismiss(); }));
        box.addView(settingRow("Ver registro técnico", () -> { d.dismiss(); showLog(); }));
        show(d);
    }

    private LinearLayout dialogBox(String title, String sub) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 20);
        box.setPadding(p, p, p, p);
        box.setBackground(Ui.rounded(Ui.CARD, Ui.dp(this, 20), Ui.LINE, 1));
        box.addView(Ui.text(this, title, 22, Ui.TEXT, true));
        if (sub != null) {
            TextView v = Ui.text(this, sub, 13, Ui.TEXT_2, false);
            v.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 10));
            box.addView(v);
        }
        return box;
    }

    private void show(AlertDialog d) {
        d.show();
        if (d.getWindow() != null) d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
    }

    private TextView settingRow(String s, Runnable r) {
        TextView t = Ui.text(this, s, 16, Ui.TEXT, false);
        t.setPadding(Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14));
        t.setBackground(Ui.rounded(Ui.CARD_ON, Ui.dp(this, 14), Ui.LINE, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 8);
        t.setLayoutParams(lp);
        t.setOnClickListener(v -> r.run());
        return t;
    }

    private void addCtrl(LinearLayout parent, int type, boolean big, View.OnClickListener l) {
        ControlButton b = new ControlButton(this, type, big);
        b.setOnClickListener(l);
        int s = Ui.dp(this, big ? 80 : 64);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(s, s);
        p.setMargins(Ui.dp(this, 10), 0, Ui.dp(this, 10), 0);
        p.gravity = Gravity.CENTER_VERTICAL;
        parent.addView(b, p);
    }

    private LinearLayout.LayoutParams centered(int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = Ui.dp(this, topDp);
        p.gravity = Gravity.CENTER_HORIZONTAL;
        return p;
    }

    private LinearLayout.LayoutParams chipLp() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(Ui.dp(this, 5), 0, Ui.dp(this, 5), 0);
        return p;
    }

    private TextView pill(String s, boolean accent) {
        TextView t = Ui.text(this, s, 13, accent ? Color.WHITE : Ui.TEXT_2, true);
        t.setLetterSpacing(0.06f);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Ui.dp(this, 14), Ui.dp(this, 8), Ui.dp(this, 14), Ui.dp(this, 8));
        if (accent) {
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{Ui.ACCENT_2, Ui.ACCENT});
            g.setCornerRadius(Ui.dp(this, 18));
            t.setBackground(g);
        } else {
            t.setBackground(Ui.rounded(Ui.CARD, Ui.dp(this, 18), Ui.LINE, Ui.dp(this, 1)));
        }
        return t;
    }

    private void chip(TextView t, String s, boolean on, int onColor) {
        t.setText(s);
        t.setTextColor(on ? onColor : Ui.TEXT_3);
        t.setBackground(Ui.rounded(Ui.CARD, Ui.dp(this, 18),
                on ? Color.argb(140, Color.red(onColor), Color.green(onColor), Color.blue(onColor)) : Ui.LINE,
                Ui.dp(this, 1)));
    }

    // --- Actualización y registro ---

    private void checkUpdate(final boolean manual) {
        if (manual) Toast.makeText(this, "Buscando actualización…", Toast.LENGTH_SHORT).show();
        updater.check((remote, error) -> {
            if (remote > Updater.localVersion()) {
                updateBanner.setVisibility(View.VISIBLE);
                if (manual) startUpdate();
            } else if (manual) {
                Toast.makeText(this, error != null ? error : "Ya tienes la última versión", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void startUpdate() {
        Toast.makeText(this, "Descargando actualización…", Toast.LENGTH_LONG).show();
        updater.downloadAndInstall();
    }

    private void showLog() {
        ScrollView sv = new ScrollView(this);
        TextView t = Ui.text(this, log.toString(), 12, Ui.TEXT_2, false);
        t.setTypeface(Typeface.MONOSPACE);
        int p = Ui.dp(this, 16);
        t.setPadding(p, p, p, p);
        sv.addView(t);
        new AlertDialog.Builder(this).setTitle("Registro técnico").setView(sv)
                .setPositiveButton("Cerrar", null).show();
    }

    private void addLog(String line) {
        String t = new SimpleDateFormat("HH:mm:ss", Locale.ROOT).format(new Date());
        log.insert(0, t + "  " + line + "\n");
        if (++logLines > 300) {
            int cut = log.lastIndexOf("\n", log.length() - 2);
            if (cut > 0) log.setLength(cut + 1);
            logLines--;
        }
    }

    private static String hex(int pi) { return String.format(Locale.ROOT, "%04X", pi); }

    private static String formatFreq(int f) { return String.format(Locale.ROOT, "%.1f", f / 100.0); }
}
