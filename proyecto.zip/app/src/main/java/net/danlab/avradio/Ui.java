package net.danlab.avradio;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.widget.TextView;

/** Colores y utilidades de diseño de AVRadio. */
final class Ui {
    private Ui() { }

    static final int BG_TOP    = Color.rgb(10, 16, 30);
    static final int BG_BOTTOM = Color.rgb(2, 3, 6);
    static final int CARD      = Color.argb(255, 20, 27, 42);
    static final int CARD_ON   = Color.argb(255, 26, 40, 62);
    static final int LINE      = Color.argb(40, 255, 255, 255);
    static final int TEXT      = Color.rgb(240, 244, 250);
    static final int TEXT_2    = Color.rgb(150, 160, 178);
    static final int TEXT_3    = Color.rgb(95, 104, 122);
    static final int ACCENT    = Color.rgb(64, 196, 255);
    static final int ACCENT_2  = Color.rgb(124, 92, 255);
    static final int OK        = Color.rgb(80, 220, 150);
    static final int WARM      = Color.rgb(255, 190, 110);

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView tv = new TextView(c);
        tv.setText(s);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        tv.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif-light", Typeface.NORMAL));
        tv.setIncludeFontPadding(false);
        return tv;
    }

    static GradientDrawable rounded(int fill, float radiusPx, int strokeColor, int strokePx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(radiusPx);
        if (strokePx > 0) g.setStroke(strokePx, strokeColor);
        return g;
    }

    /** Color estable para cada emisora según su PI o nombre. */
    static int stationColor(String key) {
        if (key == null || key.isEmpty()) return ACCENT;
        int h = Math.abs(key.hashCode()) % 360;
        return Color.HSVToColor(new float[]{h, 0.65f, 0.95f});
    }

    /** Iniciales para el círculo de la emisora: "ROCK FM" -> "RF", "iCat" -> "IC". */
    static String initials(String ps) {
        if (ps == null) return "";
        String s = ps.trim();
        if (s.isEmpty()) return "";
        String[] w = s.split("\\s+");
        if (w.length >= 2) {
            return (first(w[0]) + first(w[1])).toUpperCase();
        }
        return s.length() <= 3 ? s.toUpperCase() : s.substring(0, 2).toUpperCase();
    }

    private static String first(String w) {
        for (int i = 0; i < w.length(); i++) {
            if (Character.isLetterOrDigit(w.charAt(i))) return String.valueOf(w.charAt(i));
        }
        return "";
    }
}
