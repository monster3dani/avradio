package net.danlab.avradio;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.widget.TextView;

/** Colores y utilidades de diseño de AVRadio. */
final class Ui {
    private Ui() { }

    static int BG_TOP    = Color.rgb(10, 16, 30);
    static int BG_BOTTOM = Color.rgb(2, 3, 6);
    static int CARD      = Color.argb(255, 20, 27, 42);
    static int CARD_ON   = Color.argb(255, 26, 40, 62);
    static final int LINE      = Color.argb(40, 255, 255, 255);
    static final int TEXT      = Color.rgb(240, 244, 250);
    static final int TEXT_2    = Color.rgb(150, 160, 178);
    static final int TEXT_3    = Color.rgb(95, 104, 122);
    static int ACCENT    = Color.rgb(64, 196, 255);
    static int ACCENT_2  = Color.rgb(124, 92, 255);
    static final int OK        = Color.rgb(80, 220, 150);
    static final int WARM      = Color.rgb(255, 190, 110);

    /** Temas: nombre, fondo arriba, fondo abajo, tarjeta, tarjeta activa, acento, acento 2 */
    static final Object[][] THEMES = {
            {"Azul noche", rgb(10, 16, 30), rgb(2, 3, 6), rgb(20, 27, 42), rgb(26, 40, 62), rgb(64, 196, 255), rgb(124, 92, 255)},
            {"DanLab", rgb(6, 30, 34), rgb(2, 8, 9), rgb(14, 32, 36), rgb(18, 50, 56), rgb(40, 196, 196), rgb(11, 95, 106)},
            {"Rojo deportivo", rgb(34, 8, 10), rgb(6, 2, 3), rgb(36, 18, 20), rgb(58, 24, 26), rgb(255, 72, 72), rgb(255, 140, 60)},
            {"Esmeralda", rgb(6, 28, 18), rgb(2, 6, 4), rgb(16, 32, 26), rgb(20, 50, 38), rgb(60, 220, 140), rgb(40, 160, 200)},
            {"Ámbar", rgb(32, 20, 6), rgb(6, 4, 2), rgb(36, 28, 18), rgb(56, 42, 22), rgb(255, 180, 60), rgb(255, 110, 60)},
            {"Violeta", rgb(22, 10, 34), rgb(5, 2, 8), rgb(30, 22, 42), rgb(46, 30, 66), rgb(190, 110, 255), rgb(255, 90, 180)},
            {"Grafito", rgb(26, 28, 32), rgb(6, 6, 8), rgb(32, 34, 40), rgb(48, 52, 60), rgb(220, 224, 232), rgb(130, 140, 160)},
    };
    static final String[] STYLES = {"Degradado", "Aurora", "Ondas", "Líneas"};
    static int style = 0;

    private static int rgb(int r, int g, int b) { return Color.rgb(r, g, b); }

    /** Carga el tema guardado (se llama al arrancar la app). */
    static void loadTheme(Context c) {
        android.content.SharedPreferences p = c.getSharedPreferences("avradio", Context.MODE_PRIVATE);
        int t = Math.max(0, Math.min(THEMES.length - 1, p.getInt("theme", 0)));
        Object[] th = THEMES[t];
        BG_TOP = (Integer) th[1];
        BG_BOTTOM = (Integer) th[2];
        CARD = (Integer) th[3];
        CARD_ON = (Integer) th[4];
        ACCENT = (Integer) th[5];
        ACCENT_2 = (Integer) th[6];
        style = Math.max(0, Math.min(STYLES.length - 1, p.getInt("bgStyle", 1)));
    }

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView tv = new TextView(c);
        tv.setText(s);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        tv.setTypeface(Typeface.create(bold ? "sans-serif-medium" : "sans-serif-light", Typeface.NORMAL));
        tv.setIncludeFontPadding(false);
        return tv;
    }

    static GradientDrawable rounded(int fill, float radiusPx, int strokeColor, int strokePx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(radiusPx);
        if (strokePx > 0) g.setStroke(strokePx, strokeColor);
        return g;
    }

    /** Color estable para cada emisora según su PI o nombre. */
    static int stationColor(String key) {
        if (key == null || key.isEmpty()) return ACCENT;
        int h = Math.abs(key.hashCode()) % 360;
        return Color.HSVToColor(new float[]{h, 0.65f, 0.95f});
    }

    /** Iniciales para el círculo de la emisora: "ROCK FM" -> "RF", "iCat" -> "IC". */
    static String initials(String ps) {
        if (ps == null) return "";
        String s = ps.trim();
        if (s.isEmpty()) return "";
        String[] w = s.split("\\s+");
        if (w.length >= 2) {
            return (first(w[0]) + first(w[1])).toUpperCase();
        }
        return s.length() <= 3 ? s.toUpperCase() : s.substring(0, 2).toUpperCase();
    }

    private static String first(String w) {
        for (int i = 0; i < w.length(); i++) {
            if (Character.isLetterOrDigit(w.charAt(i))) return String.valueOf(w.charAt(i));
        }
        return "";
    }
}
