package net.danlab.avradio;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.widget.RemoteViews;

import java.util.Locale;

/** Widget para la pantalla de inicio: logo, emisora y botones. */
public class AvWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        RadioService.start(c);
        RadioHub hub = RadioHub.get(c);
        int f = hub.freq != 0 ? hub.freq : c.getSharedPreferences("avradio", Context.MODE_PRIVATE).getInt("lastFreq", 0);
        String name = hub.displayName();
        String fs = f == 0 ? "" : String.format(Locale.ROOT, "%.1f MHz", f / 100.0);
        push(c, m, ids, name.isEmpty() ? "AVRadio" : name, fs, null);
    }

    public static void updateAll(Context c, String title, String freq, Bitmap logo, String key, String name) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, AvWidget.class));
        if (ids == null || ids.length == 0) return;
        push(c, m, ids, title, freq, logo);
    }

    private static void push(Context c, AppWidgetManager m, int[] ids, String title, String freq, Bitmap logo) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget);
        v.setTextViewText(R.id.w_name, title);
        v.setTextViewText(R.id.w_freq, freq);
        if (logo != null) v.setImageViewBitmap(R.id.w_logo, logo);
        else v.setImageViewResource(R.id.w_logo, R.mipmap.ic_launcher);
        v.setOnClickPendingIntent(R.id.w_root, PendingIntent.getActivity(c, 10,
                new Intent(c, MainActivity.class), PendingIntent.FLAG_UPDATE_CURRENT));
        v.setOnClickPendingIntent(R.id.w_prev, PendingIntent.getForegroundService(c, 11,
                new Intent(c, RadioService.class).setAction(RadioService.ACTION_PREV), PendingIntent.FLAG_UPDATE_CURRENT));
        v.setOnClickPendingIntent(R.id.w_next, PendingIntent.getForegroundService(c, 12,
                new Intent(c, RadioService.class).setAction(RadioService.ACTION_NEXT), PendingIntent.FLAG_UPDATE_CURRENT));
        m.updateAppWidget(ids, v);
    }
}
