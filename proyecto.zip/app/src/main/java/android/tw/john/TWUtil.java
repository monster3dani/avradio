package android.tw.john;

import android.os.Handler;

/**
 * STUB: solo sirve para compilar. En la pantalla TS10 se usa la clase real
 * que viene dentro de /system/framework/framework.jar.
 */
public class TWUtil {
    public TWUtil() { throw new RuntimeException("stub"); }
    public TWUtil(int clazz) { throw new RuntimeException("stub"); }
    public int open(short[] id, int flag) { throw new RuntimeException("stub"); }
    public int open(short[] id) { throw new RuntimeException("stub"); }
    public void close() { throw new RuntimeException("stub"); }
    public void start() { throw new RuntimeException("stub"); }
    public void stop() { throw new RuntimeException("stub"); }
    public int write(int what) { throw new RuntimeException("stub"); }
    public int write(int what, int arg1) { throw new RuntimeException("stub"); }
    public int write(int what, int arg1, int arg2) { throw new RuntimeException("stub"); }
    public int write(int what, int arg1, int arg2, Object obj) { throw new RuntimeException("stub"); }
    public void addHandler(String tag, Handler handler) { throw new RuntimeException("stub"); }
    public void removeHandler(String tag) { throw new RuntimeException("stub"); }
}
